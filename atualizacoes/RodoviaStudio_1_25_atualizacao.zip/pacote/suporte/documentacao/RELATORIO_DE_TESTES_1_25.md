# Validação da integração QuickMapServices — 1.25

Ambiente Linux, Python 3.12 e Chromium do sistema/Playwright.

**63 testes passaram** em 60,55 s. Bateria selecionada: `test_v125.py`, `test_v119.py`, `test_v111.py`, `test_v19.py`, `test_workflow.py` e `test_v124.py`. Não foi repetida toda a bateria da versão 1.24; suas duas falhas preexistentes de GDAL/arquivo de compilação Windows não foram tratadas nesta alteração.

Os 12 casos novos (incluindo parametrização) verificam:

- Contrato da API oficial QMS: pesquisa por tipo/CRS/nome e resolução de ID.
- Preferência por origin_url, inversão de Y (TMS) e quadkeys.
- Recusa de formatos, projeções, parâmetros e faixas de zoom incompatíveis.
- Separação dos caches por serviço e uso offline do ladrilho já salvo.
- Persistência da fonte e preservação da configuração quando o catálogo falha.
- Mesmo provedor no endpoint de imagens do editor, na preparação da cena, no detalhe e na geração real de um MP4 H.264 de 30 quadros, validado por decodificação completa.
- Navegador: busca por Google Satellite em catálogo simulado, seleção, aplicação, gravação e reabertura da mesma fonte.

Os testes usam respostas simuladas do catálogo/provedor. O nome Google Satellite no teste é somente uma fixture; seu ID/endereço não é oferecido como serviço real.

A regressão cobriu fontes anteriores, georreferenciamento, editor, análise, prévia e MP4. Python compilado, JavaScript verificado e dependências consistentes. Serviço da máquina reiniciado: versão 1.25.0, esquema da API com QMS e interface com os novos controles, todos conferidos por HTTP local.

A consulta real ao catálogo retornou erro 403 do proxy desta nuvem. Não houve validação de imagem Google externa. O domínio qms.nextgis.com foi acrescentado ao rascunho de configuração de rede; o domínio do provedor escolhido também precisa estar acessível. O código oficial do plugin foi consultado no GitHub para confirmar protocolo e campos, sem instalar ou copiar o plugin QGIS.

O pacote de atualização é verificado separadamente: aplicação sobre instalação temporária 1.24, backup, preservação de projeto e reaplicação sem mudanças. O Windows real não foi executado.
