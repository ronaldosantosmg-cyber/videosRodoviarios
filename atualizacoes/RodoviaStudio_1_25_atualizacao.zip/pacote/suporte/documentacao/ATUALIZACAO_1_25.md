# Rodovia Studio 1.25 — QuickMapServices

## Atualizar

Feche o Rodovia Studio, coloque `RodoviaStudio_1_25_atualizacao.zip` na pasta `atualizacoes` e execute `ATUALIZAR RODOVIA STUDIO.cmd`. O pacote é cumulativo: inclui as alterações da 1.24 e pode atualizar uma instalação existente da 1.23/1.24. O atualizador mantém backup dos arquivos substituídos. O iniciador Windows não precisou ser modificado.

## Escolher a mesma base utilizada no QGIS

1. Abra seu projeto e a seção **Configuração → Base de imagem: QuickMapServices, Esri e outros serviços**.
2. Em **Fonte**, escolha **QuickMapServices — escolher serviço**.
3. Pesquise pelo nome, por exemplo **Google Satellite**, **Esri**, **Bing** ou **OpenStreetMap**.
4. Escolha o serviço e clique **Aplicar fonte**. Como alternativa à busca, informe o ID da página desse serviço no catálogo QMS.
5. Confira a fonte exibida em **Fonte em uso** e gere novamente a prévia ou o vídeo.

Para corresponder ao QGIS, escolha o mesmo serviço/ID do QuickMapServices. Nomes parecidos podem apontar para servidores diferentes. O aplicativo preserva a atribuição do provedor. O mosaico é reprojetado para o CRS do projeto; o realce visual e a resolução do vídeo podem diferir da tela do QGIS.

## O que foi integrado

- Busca e seleção pelo catálogo oficial em `qms.nextgis.com`, usando a API v1 também usada pelo plugin QGIS.
- Bases de imagem XYZ/TMS em EPSG:3857, incluindo serviços Google quando publicados no catálogo com formato compatível e disponíveis no provedor.
- Padrões de URL `{z}/{x}/{y}`, TMS com Y invertido, `{s}` e quadkeys `{q}`. O `origin_url` é preferido quando informado pelo catálogo, seguindo a escolha do plugin QGIS.
- A mesma definição de fonte é usada pelo editor, pelo mosaico da prévia/MP4 e pelos ladrilhos de aproximação.
- Identificador, nome, endereço, zooms e crédito ficam salvos no projeto. Reabrir e usar o projeto não depende de consultar novamente o catálogo.
- Cache separado por ID/endereço do serviço, evitando misturar Google, Esri ou outros provedores. Os ladrilhos já guardados continuam utilizáveis sem internet.
- Falhas da fonte QMS não provocam substituição silenciosa por Esri.
- Os controles Esri, Wayback, XYZ e WMS continuam disponíveis. Uma imagem local configurada para sobreposição mantém sua prioridade.

QuickMapServices é o catálogo de serviços utilizado pelo plugin QGIS. Esta integração consulta esse catálogo e utiliza os serviços de imagem; não instala QGIS nem executa o plugin dentro do Rodovia Studio. Camadas vetoriais WFS/GeoJSON e serviços de imagem com projeção/formato incompatíveis não aparecem na busca de bases. WMS pode continuar sendo configurado pelo controle WMS existente.

A presença de Google ou outro provedor no catálogo não garante acesso permanente, data de captura, qualidade ou permissão de uso de suas imagens. Crédito e condições de uso continuam sendo os do provedor escolhido. Nenhuma chave ou credencial foi criada.

## Rede e validação

É necessário alcançar `qms.nextgis.com` para buscar/aplicar um serviço pela primeira vez e o domínio do provedor escolhido para baixar imagens. Na nuvem desta conversa, a consulta ao catálogo retornou bloqueio de proxy (403). Foi salvo o acréscimo de `qms.nextgis.com` à lista de rede, preservando os demais presets. Essa configuração precisa ser revisada/salva e o ambiente publicado para ativar a versão preparada; uma configuração salva como rascunho não comprova conectividade.

Os testes usam respostas simuladas de catálogo e provedor e exercitam a seleção no navegador, a persistência, os caches e um MP4 real. Não equivalem a um download validado de Google Satellite ou de outro provedor externo. No PC, a conexão depende da rede local. O Windows não foi executado neste ambiente Linux.

## Referência técnica consultada

Repositório oficial: https://github.com/nextgis/quickmapservices
Commit consultado: e73c0f559c3d2ce8b6d90857b966571f2d6b589e
Arquivos: `qms_external_api_python/api/api_v1.py` e `data_source_serializer.py`.

Esquema da configuração: 23. Configurações anteriores são migradas automaticamente; aplicativos anteriores não reconhecem a nova seleção QMS.
