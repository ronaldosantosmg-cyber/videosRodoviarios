param([switch]$PrepararApenas)
# -PrepararApenas: so prepara Python, bibliotecas e FFmpeg (usado pelo Rodovia Studio.exe) e nao abre o aplicativo.
$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$runtime = Join-Path $PSScriptRoot 'runtime'
$py = Join-Path $runtime 'python.exe'
$logs = Join-Path (Split-Path $PSScriptRoot -Parent) 'logs'
if ((Split-Path $PSScriptRoot -Leaf) -ne 'sistema') { $logs = $PSScriptRoot }
New-Item -ItemType Directory -Force $logs | Out-Null
$log = Join-Path $logs 'instalacao.log'
try {
    if (-not (Test-Path $py)) {
        Write-Host 'Preparando Python portatil na pasta do aplicativo. Nao requer administrador.'
        New-Item -ItemType Directory -Force $runtime | Out-Null
        $zip = Join-Path $runtime 'python.zip'
        Invoke-WebRequest 'https://www.python.org/ftp/python/3.12.10/python-3.12.10-embed-amd64.zip' -OutFile $zip -UseBasicParsing
        Expand-Archive $zip -DestinationPath $runtime -Force
        Remove-Item $zip
        $pth = Join-Path $runtime 'python312._pth'
        @('python312.zip','.','Lib\site-packages','..','import site') | Set-Content $pth -Encoding ASCII
    }
    if (-not (Test-Path (Join-Path $runtime 'Lib\site-packages\pip\__init__.py'))) {
        $getpip = Join-Path $runtime 'get-pip.py'
        Invoke-WebRequest 'https://bootstrap.pypa.io/get-pip.py' -OutFile $getpip -UseBasicParsing
        & $py $getpip --no-warn-script-location 2>&1 | Tee-Object -FilePath $log -Append
        if ($LASTEXITCODE -ne 0) { throw 'Falha ao preparar pip. Confira a internet e instalacao.log.' }
        Remove-Item $getpip -ErrorAction SilentlyContinue
    }
    $req = Join-Path $PSScriptRoot 'requirements.txt'
    $fingerprint = (Get-FileHash $req -Algorithm SHA256).Hash
    $stamp = Join-Path $runtime 'dependencias.ok'
    if (-not (Test-Path $stamp) -or (Get-Content $stamp -Raw).Trim() -ne $fingerprint) {
        Write-Host 'Baixando dependencias e FFmpeg. Aguarde a primeira preparacao.'
        $wheels = Join-Path $PSScriptRoot 'pacotes'
        if (Test-Path $wheels) {
            # Instalacao sem internet a partir de pacotes .whl copiados para a pasta 'pacotes'.
            & $py -m pip install --no-index --find-links $wheels --disable-pip-version-check --no-warn-script-location -r $req 2>&1 | Tee-Object -FilePath $log -Append
        } else {
            & $py -m pip install --no-cache-dir --disable-pip-version-check --no-warn-script-location -r $req 2>&1 | Tee-Object -FilePath $log -Append
        }
        if ($LASTEXITCODE -ne 0) { throw 'Falha nas dependencias. Confira instalacao.log. Execute INICIAR.cmd novamente apos corrigir a conexao.' }
        $fingerprint | Set-Content $stamp -Encoding ASCII
    }
    # Atalho "Rodovia Studio" na Area de Trabalho (uma vez; falhas sao ignoradas).
    $flag = Join-Path $logs 'atalho.ok'
    $main = Join-Path (Split-Path (Split-Path $PSScriptRoot -Parent) -Parent) 'ABRIR RODOVIA STUDIO.cmd'
    if (-not $PrepararApenas -and -not (Test-Path $flag) -and (Test-Path $main)) {
        try {
            $desk = [Environment]::GetFolderPath('Desktop')
            $ws = New-Object -ComObject WScript.Shell
            $lnk = $ws.CreateShortcut((Join-Path $desk 'Rodovia Studio.lnk'))
            $lnk.TargetPath = $main
            $lnk.WorkingDirectory = (Split-Path $main -Parent)
            $lnk.IconLocation = (Join-Path $PSScriptRoot 'rodovia.ico')
            $lnk.Description = 'Rodovia Studio - apresentacoes rodoviarias em video'
            $lnk.Save()
            'ok' | Set-Content $flag -Encoding ASCII
            Write-Host 'Atalho "Rodovia Studio" criado na Area de Trabalho.'
        } catch { 'falhou' | Set-Content $flag -Encoding ASCII }
    }
    & $py (Join-Path $PSScriptRoot 'diagnostico.py')
    if ($LASTEXITCODE -ne 0) { throw 'O diagnostico encontrou dependencias ausentes.' }
    if ($PrepararApenas) { Write-Host 'Preparacao concluida.'; exit 0 }
    & $py (Join-Path $PSScriptRoot 'run.py')
    if ($LASTEXITCODE -ne 0) { throw 'O aplicativo encerrou com erro.' }
} catch {
    $_ | Out-String | Tee-Object -FilePath $log -Append | Write-Host
    Write-Host 'Se a empresa bloquear downloads ou PowerShell, sera necessario liberar esses acessos.'
    exit 1
}
