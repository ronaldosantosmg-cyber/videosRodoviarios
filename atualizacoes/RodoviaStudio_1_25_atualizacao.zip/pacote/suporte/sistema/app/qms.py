"""QuickMapServices catalog adapter. A selected service is frozen into project settings."""
import json,re,urllib.parse,urllib.request
from .models import WebImagery

API='https://qms.nextgis.com/api/v1/geoservices/'

def request_json(url):
    req=urllib.request.Request(url,headers={'User-Agent':'RodoviaStudio/1.25','Accept':'application/json'})
    with urllib.request.urlopen(req,timeout=20) as r:
        raw=r.read(2_000_001)
    if len(raw)>2_000_000:raise ValueError('Resposta do catálogo QMS excede o limite.')
    return json.loads(raw)

def definition(data):
    if data.get('type')!='tms' or str(data.get('epsg'))!='3857':
        raise ValueError('Selecione um serviço de ladrilhos QMS em EPSG:3857. Outros serviços podem ser configurados pela opção WMS/XYZ.')
    # QGIS QMS also prefers origin_url when the catalog supplies it.
    url=str(data.get('origin_url') or data.get('url') or '').strip().replace('{zoom}','{z}')
    if not url.startswith(('https://','http://')):raise ValueError('Serviço QMS sem endereço HTTP/HTTPS válido.')
    # QMS uses y_origin_top=false for bottom-origin TMS grids.
    if str(data.get('y_origin_top')).lower() in ('false','0'):url=url.replace('{y}','{-y}')
    fields=set(re.findall(r'\{([^{}]+)\}',url))
    if fields-{'z','x','y','-y','s','q'}:raise ValueError('Este serviço QMS usa parâmetros especiais. Configure seu endereço pela opção XYZ.')
    if not ('q' in fields or {'z','x'}.issubset(fields) and bool({'y','-y'}&fields)):
        raise ValueError('Serviço QMS sem coordenadas de ladrilho reconhecidas.')
    maximum=int(data.get('z_max') if data.get('z_max') is not None else 19)
    minimum=int(data.get('z_min') or 0)
    if maximum<10 or minimum>maximum or minimum<0 or maximum>23:
        raise ValueError('Faixa de zoom deste serviço não é suportada (máximo entre 10 e 23).')
    return WebImagery(source='qms',qms_id=int(data['id']),qms_name=str(data.get('name') or 'QuickMapServices')[:160],url=url,
        attribution=str(data.get('copyright_text') or data.get('name') or 'Fonte QuickMapServices')[:200],min_zoom=minimum,max_zoom=maximum)

def search(query,fetch=None):
    query=str(query).strip()
    if not query or len(query)>120:raise ValueError('Informe um nome de serviço com até 120 caracteres.')
    fetch=fetch or request_json
    data=fetch(API+'?'+urllib.parse.urlencode({'search':query,'type':'tms','epsg':3857,'limit':30}))
    rows=data.get('results',[]) if isinstance(data,dict) else data
    out=[]
    for row in rows:
        if not isinstance(row,dict) or row.get('type')!='tms' or str(row.get('epsg'))!='3857':continue
        out.append({'id':int(row['id']),'name':str(row.get('name',''))[:160],'attribution':str(row.get('copyright_text') or '')[:200]})
    return out[:30]

def service(service_id,fetch=None):
    if not 1<=service_id<=100_000_000:raise ValueError('Identificador QMS inválido.')
    data=(fetch or request_json)(API+str(service_id)+'/')
    if int(data.get('id',0))!=service_id:raise ValueError('Resposta do QMS não corresponde ao serviço solicitado.')
    return definition(data)
