import json, re, unicodedata, zipfile, xml.etree.ElementTree as ET
from collections import Counter
from pathlib import Path
import numpy as np
import ezdxf
from ezdxf.path import make_path, from_hatch
from pyproj import CRS, Transformer
from shapely.geometry import Polygon, LineString
from shapely.ops import unary_union
from shapely import make_valid

ROLES=['axis','pavement','existing_pavement','shoulder','median','barrier','oae','cut','fill','domain','edge_line','water','earthwork','sign_h','sign_v']
COLORS={'sign_h':'#ffffff','sign_v':'#ff5d5d','edge_line':'#f4f2e2','water':'#2a80b9','existing_pavement':'#a4a8a9','pavement':'#454c4e','shoulder':'#858983','median':'#7f9b6e','barrier':'#e0ddd2','oae':'#b9bcb7','cut':'#df6262','fill':'#53bb77','domain':'#ffd56b'}
def norm(s):
    return ''.join(c for c in unicodedata.normalize('NFKD',s.upper()) if not unicodedata.combining(c))
def guess(layer):
    """Sugestão pelo perfil padrão (layer_profiles.BUILTIN); o mapeamento final é sempre do projeto."""
    from .layer_profiles import BUILTIN,role_for
    return role_for(layer,BUILTIN['rules'])

def read_dxf(path,warnings=None):
    """Recover structural DXF errors using ezdxf's supported auditor; never rewrite input."""
    try:return ezdxf.readfile(path)
    except ezdxf.DXFStructureError:
        from ezdxf import recover
        doc,auditor=recover.readfile(path)
        if warnings is not None:warnings.append(f'DXF recuperado: {len(auditor.fixes)} reparo(s), {len(auditor.errors)} erro(s) restante(s). Confira o desenho.')
        return doc

def walk(es, depth=0, parent_layer=None, prefix=''):
    if depth>16: return
    for index,e in enumerate(es):
        eid=prefix+(e.dxf.get('handle') or str(index))
        if e.dxftype()=='INSERT':
            inserts=e.multi_insert() if e.mcount>1 else [e]
            for row,insert in enumerate(inserts):
                yield from walk(insert.virtual_entities(),depth+1,e.dxf.layer if e.dxf.layer!='0' else parent_layer,eid+f'/{row}/')
        else:
            if e.dxf.layer=='0' and parent_layer:
                e=e.copy();e.dxf.layer=parent_layer
            e._studio_id=eid
            yield e

def read_kmz(path,crs):
    if not path or not Path(path).exists(): return [],[]
    z=zipfile.ZipFile(path)
    names=[n for n in z.namelist() if n.lower().endswith('.kml')]
    if not names: raise ValueError('KMZ sem documento KML.')
    if sum(i.file_size for i in z.infolist())>100*1024*1024: raise ValueError('KMZ descompactado excede 100 MB.')
    tr=Transformer.from_crs(4326,crs,always_xy=True);lines=[];pois=[]
    for name in names:
        root=ET.fromstring(z.read(name));ns={'k':'http://www.opengis.net/kml/2.2'}
        for pm in root.findall('.//k:Placemark',ns):
            title=pm.findtext('k:name',default='Referência KMZ',namespaces=ns)
            for co in pm.findall('.//k:coordinates',ns):
                rows=[tuple(map(float,v.split(',')[:2])) for v in (co.text or '').split()]
                if not rows: continue
                lon,lat=np.array(rows).T;x,y=tr.transform(lon,lat);p=np.column_stack([x,y])
                if len(p)==1: pois.append({'id':f'kmz-{len(pois)}','title':title[:100],'subtitle':'Referência do KMZ','kind':'outro','x':float(x[0]),'y':float(y[0])})
                else: lines.append(p)
    return lines,pois

def convert(e,layer,role,units,entities,warnings,extra=None):
    """Converte uma entidade DXF em polilinhas/polígonos (metros, coordenadas do desenho)."""
    extra={'entity_id':getattr(e,'_studio_id',e.dxf.get('handle','')),**(extra or {})}
    try:
        paths=list(from_hatch(e)) if e.dxftype()=='HATCH' else [make_path(e)]
        ps=[]
        for p in paths:
            pts=np.array([(v.x,v.y) for v in p.flattening(.12/units,segments=8)])*units
            if len(pts)>=2 and np.isfinite(pts).all():
                pts=pts[np.r_[True,np.linalg.norm(np.diff(pts,axis=0),axis=1)>1e-9]]
                if len(pts)>=2:ps.append(pts)
        if e.dxftype()=='HATCH' and ps:
            # Even/odd fill respects islands rather than filling every loop independently.
            shape=Polygon()
            for p in ps:
                if len(p)>=3: shape=shape.symmetric_difference(make_valid(Polygon(p)))
            geoms=list(shape.geoms) if hasattr(shape,'geoms') else [shape]
            for poly in geoms:
                if poly.geom_type!='Polygon': continue
                entities.append({'layer':layer,'role':role,'closed':True,'points':np.array(poly.exterior.coords),'holes':[np.array(h.coords) for h in poly.interiors],**extra})
        else:
            for pts in ps:
                closed=bool(e.dxf.get('flags',0)&1) if e.dxftype() in ['LWPOLYLINE','POLYLINE'] else np.linalg.norm(pts[0]-pts[-1])<.05
                entities.append({'layer':layer,'role':role,'closed':bool(closed and len(pts)>=3),'points':pts,'holes':[],**extra})
    except (ValueError,TypeError,ezdxf.DXFError,NotImplementedError):
        warnings.append(f'Entidade não convertida: {layer} / {e.dxftype()}')

NO_GEOMETRY={'TEXT','MTEXT','ATTRIB','ATTDEF','DIMENSION','IMAGE','VIEWPORT','POINT','LEADER','MULTILEADER','MLEADER'}

def overlay_layers(path):
    """Camadas de um DXF adicional, com contagem e classe sugerida."""
    doc=read_dxf(path);counts=Counter(e.dxf.layer for e in walk(doc.modelspace()))
    return [{'name':l,'count':n,'suggested_role':guess(l)} for l,n in sorted(counts.items())]

def read_overlays(directory,settings,warnings):
    """DXF adicionais sobrepostos: mesma leitura do DXF principal, com offset e CRS próprios."""
    from .alignment import fit,apply
    out=[]
    target=CRS.from_user_input(settings.crs)
    for order,ov in enumerate(sorted(settings.overlays,key=lambda o:o.order)):
        if not ov.enabled:continue
        path=Path(directory)/'camadas'/(ov.id+'.dxf')
        if not path.exists():warnings.append(f'Camada {ov.name}: arquivo ausente.');continue
        doc=read_dxf(path,warnings);ents=[]
        for e in walk(doc.modelspace()):
            if e.dxftype() in NO_GEOMETRY:continue
            role=ov.roles.get(e.dxf.layer,'')
            if role=='ignore':continue
            if role and role not in ROLES:role=''
            eid='overlay:'+ov.id+':'+getattr(e,'_studio_id','')
            if eid in settings.excluded_entities:continue
            convert(e,e.dxf.layer,role or 'overlay',settings.units_to_m,ents,warnings,{'entity_id':eid,'overlay':ov.id,'overlay_order':order,'style':{'color':ov.color,'opacity':ov.opacity,'width_m':ov.line_width_m,'fill':ov.fill}})
        if ov.crs and CRS.from_user_input(ov.crs)!=target:
            tr=Transformer.from_crs(CRS.from_user_input(ov.crs),target,always_xy=True)
            for e in ents:
                e['points']=np.column_stack(tr.transform(e['points'][:,0],e['points'][:,1]));e['holes']=[np.column_stack(tr.transform(h[:,0],h[:,1])) for h in e['holes']]
        if ov.alignment.applied and ov.alignment.pairs:
            params=fit(ov.alignment.pairs,ov.alignment.mode)
            for e in ents:e['points']=apply(e['points'],params);e['holes']=[apply(h,params) for h in e['holes']]
        out.extend(ents)
    return out

def sign_code(name,text=''):
    """Código da placa pelo nome do bloco/texto (R-1, R-2, R-19, A, OBRAS, I)."""
    n=norm(name or '');t=norm(text or '')
    if re.search(r'R-?1(?!\d)',n) or 'PARE' in n or t=='PARE':return 'R-1',''
    if re.search(r'R-?2(?!\d)',n) or 'PREFER' in n:return 'R-2',''
    if re.search(r'R-?19',n) or 'VEL' in n:
        m=re.search(r'\d{2,3}',t) or re.search(r'(?<!R-)(?<!R)\b\d{2,3}\b',n);return 'R-19',m.group(0) if m else ''
    if 'OBRA' in n:return 'OBRAS',''
    if re.match(r'A-?\d',n):return 'A',''
    return 'I',(text or name or '')[:40]

def split_layers(ents,doc,mode='auto'):
    """1.18: camadas a separar em grupos (cor + tipo de entidade). 'auto': a camada 0, ou uma camada com 60% ou
    mais das entidades, quando ela mistura grupos (desenho com tudo numa camada só)."""
    if mode=='off' or not ents:return set()
    by=Counter(e.dxf.layer for e in ents);groups={}
    for e in ents:groups.setdefault(e.dxf.layer,set()).add((_aci(e,doc),e.dxftype()))
    total=sum(by.values());out=set()
    for l,n in by.items():
        if len(groups[l])<2:continue
        if mode=='all' or (n>=20 and (l=='0' or n>=.6*total)):out.add(l)
    return out

def _aci(e,doc):
    c=e.dxf.get('color',256)
    if c==256:
        try:c=doc.layers.get(e.dxf.layer).color
        except Exception:c=7
    return abs(int(c))

def eff_layer(e,split,doc):
    """Nome usado no mapeamento: o da camada, ou 'camada · cor N · TIPO' quando a camada é separada."""
    l=e.dxf.layer
    if l not in split:return l
    c=e.dxf.get('color',256);cor='bloco' if c==0 else str(_aci(e,doc))
    lt=str(e.dxf.get('linetype','BYLAYER') or 'BYLAYER')
    return f'{l} · cor {cor} · {e.dxftype()}'+('' if lt.upper() in ('BYLAYER','CONTINUOUS','BYBLOCK') else ' · '+lt)

def check_roles(entities):
    """1.18: avisos de mapeamento suspeito (proteção contra camada errada)."""
    out=[];by={}
    for e in entities:by.setdefault((e['role'],e['layer']),[]).append(e)
    for (role,layer),es in by.items():
        if role in ('pavement','existing_pavement','shoulder','median','oae') and not any(x['closed'] for x in es):
            out.append(f'Camada “{layer}” está como {role} mas não tem áreas fechadas (hachura ou polilinha fechada): não será preenchida. Confira o tipo.')
        if role=='axis' and len(es)>40:
            out.append(f'Camada “{layer}” está como eixo e tem {len(es)} entidades: confira se ela contém só o eixo (use “Ver”).')
        if role=='sign_h':
            big=[x for x in es if x['closed'] and len(x['points'])>=3 and Polygon(x['points']).area>500]
            if big:out.append(f'Camada “{layer}” (sinalização horizontal) tem {len(big)} área(s) grande(s) demais para pintura (>500 m²): elas foram ignoradas. Confira se não é pavimento.')
    return out

def read_signs(doc,layers,units,split=frozenset()):
    """Placas verticais do DXF: blocos (INSERT), pontos, círculos e textos nas camadas do tipo 'Sinalização vertical'."""
    out=[]
    for e in doc.modelspace():
        if eff_layer(e,split,doc) not in layers:continue
        k=e.dxftype();txt='';name='';rot=None
        try:
            if k=='INSERT':
                p=e.dxf.insert;name=e.dxf.name;rot=float(e.dxf.get('rotation',0.))
                txt=' '.join(a.dxf.text for a in e.attribs if a.dxf.get('text'))
            elif k=='POINT':p=e.dxf.location
            elif k=='CIRCLE':p=e.dxf.center
            elif k in ('TEXT','MTEXT'):
                p=e.dxf.insert;txt=e.plain_text() if k=='MTEXT' else e.dxf.text;rot=float(e.dxf.get('rotation',0.))
            else:continue
        except (AttributeError,ezdxf.DXFError):continue
        code,text=sign_code(name,txt)
        out.append({'entity_id':e.dxf.get('handle',''),'layer':eff_layer(e,split,doc),'role':'sign_v','closed':False,'points':np.array([[p[0]*units,p[1]*units]]),'holes':[],'code':code,'text':text,'rotation':rot})
    return out

def analyze(directory,settings,preview=None):
    directory=Path(directory);dxf=directory/'input.dxf';kmz=directory/'input.kmz'
    crs=CRS.from_user_input(settings.crs)
    if not crs.is_projected: raise ValueError('Informe um sistema projetado em metros, como SIRGAS/UTM.')
    entities=[];counts=Counter();warnings=[];insunits=None;sign_layers=set();sign_texts=0
    if dxf.exists():
        doc=read_dxf(dxf,warnings);insunits=int(doc.header.get('$INSUNITS',0))
        ents=list(walk(doc.modelspace()))
        split=split_layers(ents,doc,getattr(settings,'layer_split','auto'))
        if split:warnings.append('Camada(s) '+', '.join(sorted(split))[:200]+' separada(s) por cor e tipo de entidade (tudo estava numa camada só). Indique o tipo de cada grupo na lista de camadas.')
        mapped={v:r for r,ls in settings.layers.items() for v in ls}
        ignored=set(settings.ignored_layers);excluded=set(settings.excluded_entities)
        for e in ents:
            layer=eff_layer(e,split,doc);counts[layer]+=1;role=mapped.get(layer);guessed=False
            if layer in ignored or getattr(e,'_studio_id','') in excluded:continue
            if role is None:role=guess(layer) if not settings.layers else None;guessed=role is not None
            if not role and e.dxftype()=='HATCH' and 'HATCH_MATERIAL' in norm(layer) and getattr(settings,'auto_earthworks',True):role='earth_pending'
            if role=='earthwork':role='earth_pending'
            if role=='pavement' and guessed and 'EXIST' in norm(layer):role='existing_pavement'
            if not role:
                if preview is not None and e.dxftype() not in NO_GEOMETRY:convert(e,layer,'unmapped',settings.units_to_m,preview,[])
                continue
            if role=='sign_v':sign_layers.add(layer);continue
            if role=='sign_h' and e.dxftype() in ('TEXT','MTEXT'):sign_texts+=1;continue
            convert(e,layer,role,settings.units_to_m,entities,warnings)
        if sign_layers:entities.extend(read_signs(doc,sign_layers,settings.units_to_m,split))
        entities=[e for e in entities if e.get('entity_id') not in excluded and e['layer'] not in ignored]
        warnings.extend(check_roles(entities))
        if sign_texts:warnings.append(f'{sign_texts} texto(s) na sinalização horizontal do DXF não são desenhados: converta-os em polilinha/hachura no CAD.')
    # Ajuste DXF x imagem (pares de controle): aplicado só em memória, o DXF não é alterado.
    from .alignment import active,apply
    alignment=active(settings)
    if alignment:
        for e in entities+(preview if preview is not None else []):
            e['points']=apply(e['points'],alignment);e['holes']=[apply(h,alignment) for h in e.get('holes',[])]
    if getattr(settings,'accesses',None):
        from .access import items as access_items
        axes0=[v for v in entities if v['role']=='axis' and len(v['points'])>=2]
        if axes0:
            ax0=max(axes0,key=lambda e:LineString(e['points']).length)['points']
            entities.extend(access_items(settings,entities,ax0,warnings))
    from .pavement import tag_materials
    tag_materials(entities,settings)
    if getattr(settings,'pavement_areas',None) or getattr(settings,'shoulder_marks',None):
        from .surface_marks import items as surface_items
        entities=surface_items(settings,entities,warnings)
    if settings.overlays:entities.extend(read_overlays(directory,settings,warnings))
    # Native earthwork material hatches inherit the nearest typed cut/fill offset.
    from scipy.spatial import cKDTree
    samples={r:np.concatenate([e['points'] for e in entities if e['role']==r]) for r in ['cut','fill'] if any(e['role']==r for e in entities)}
    trees={r:cKDTree(p) for r,p in samples.items()}
    for e in entities:
        if e['role']=='earth_pending':
            if trees:e['role']=min(trees,key=lambda r:float(np.median(trees[r].query(e['points'][::max(1,len(e['points'])//40)])[0])))
    entities=[e for e in entities if e['role']!='earth_pending']
    kml_lines,kml_pois=read_kmz(kmz if kmz.exists() else None,crs)
    axes=[v for v in entities if v['role']=='axis' and len(v['points'])>=2]
    if not axes and kml_lines:
        axes=[{'layer':'KMZ','role':'axis','closed':False,'points':max(kml_lines,key=lambda p:LineString(p).length),'holes':[]}];entities+=axes
        warnings.append('Eixo obtido do KMZ. Pavimento só será desenhado se houver geometria no DXF.')
    ca=getattr(settings,'custom_axis',None)
    if not axes and ca is not None and ca.enabled and len(ca.points)>=2:
        axes=[{'layer':'Alinhamento do editor','role':'axis','closed':False,'points':custom_axis_points(ca),'holes':[]}]
        entities+=axes
    if not axes: raise ValueError('Nenhum eixo encontrado. Associe uma camada ao papel eixo, desenhe um alinhamento ou envie KMZ com linha.')
    axes.sort(key=lambda e:LineString(e['points']).length,reverse=True);axis=axes[0]['points'].copy()
    ca=getattr(settings,'custom_axis',None)
    if ca is not None and ca.enabled and len(ca.points)>=2:
        # 1.22: alinhamento clicado no editor vira o eixo de referência (estaqueamento, câmera, sentido).
        axis=custom_axis_points(ca);warnings.append(f'Eixo de referência: “{ca.name}” ({len(ca.points)} pontos clicados no editor, {LineString(axis).length:.1f} m).')
    if settings.reverse_axis: axis=axis[::-1].copy()
    ds=np.r_[0,np.cumsum(np.linalg.norm(np.diff(axis,axis=0),axis=1))]
    if ds[-1]<10: raise ValueError(f'Eixo com extensão insuficiente ({ds[-1]:.1f} m; mínimo 10 m). Confira a camada do eixo e o fator de unidade.')
    allpts=np.concatenate([e['points'] for e in entities if e['role'] in ['axis','pavement','domain','shoulder']] or [e['points'] for e in entities])
    lo=allpts.min(0);hi=allpts.max(0)
    if np.max(hi-lo)>300000: raise ValueError('Extensão espacial superior a 300 km. Revise camadas, unidades ou coordenadas.')
    georef=None
    if kml_lines:
        kmline=LineString(max(kml_lines,key=lambda p:LineString(p).length));mismatch=float(np.median([kmline.distance(__import__('shapely').geometry.Point(*p)) for p in axis[::max(1,len(axis)//100)]]))
        if mismatch>100: warnings.append(f'DXF/KMZ separados por cerca de {mismatch:.0f} m: confira o sistema de coordenadas.')
        georef=georef_check(axis,ds,kml_lines)
        if georef and 10<georef['median_m']<=100:warnings.append(f"Eixo do DXF e linha do KMZ com desvio mediano de {georef['median_m']:.1f} m (máx. {georef['max_m']:.1f} m em {georef['points']} pontos): confira CRS, unidades e alinhamento.")
    if insunits not in [0,6,None]: warnings.append(f'Unidade DXF INSUNITS={insunits}; fator aplicado: {settings.units_to_m}. Confira na prévia.')
    inferred={r:[] for r in ROLES}
    for l in counts:
        r=guess(l)
        if r: inferred[r].append(l)
    report={'layers':[{'name':l,'count':n,'suggested_role':guess(l)} for l,n in sorted(counts.items())], 'suggested_mapping':inferred,'geometric_length_m':float(ds[-1]),'bounds':[lo.tolist(),hi.tolist()],'warnings':list(dict.fromkeys(warnings))[:100],'kmz_pois':kml_pois,'alignment':alignment,'overlays':[{'id':o.id,'entities':sum(1 for e in entities if e.get('overlay')==o.id)} for o in settings.overlays],'georef_check':georef,'routes':[{'id':str(i),'layer':a['layer'],'length_m':round(LineString(a['points']).length,2),'closed':a['closed']} for i,a in enumerate(axes)],'crs':settings.crs}
    return entities,axis,ds,axes,report


def custom_axis_points(ca,step=1.):
    """Polilinha dos pontos clicados; com 'smooth', curva suave (spline) que passa exatamente pelos pontos."""
    P=np.array([[p.x,p.y] for p in ca.points],float)
    keep=np.r_[True,np.linalg.norm(np.diff(P,axis=0),axis=1)>1e-3];P=P[keep]
    if len(P)<2:raise ValueError('Alinhamento do editor: marque pelo menos dois pontos distintos.')
    if ca.smooth and len(P)>=3:
        from scipy.interpolate import CubicSpline
        d=np.r_[0,np.cumsum(np.linalg.norm(np.diff(P,axis=0),axis=1))]
        cs=CubicSpline(d,P,bc_type='natural');ss=np.linspace(0,d[-1],max(2,int(d[-1]/step)+1));ss=np.unique(np.r_[ss,d])
        return cs(ss)
    return P

def georef_check(axis,ds,kml_lines,n=25):
    """1.20: confere geometricamente o eixo do DXF contra as linhas do KMZ em pontos distribuídos pelo segmento.
    Retorna desvios (m) e a estaca de cada ponto; só pontos onde há linha KMZ por perto entram na estatística."""
    from shapely.geometry import Point as _P,MultiLineString
    lines=MultiLineString([LineString(p) for p in kml_lines if len(p)>=2])
    if lines.is_empty:return None
    ss=np.linspace(0,ds[-1],n);pts=np.column_stack([np.interp(ss,ds,axis[:,0]),np.interp(ss,ds,axis[:,1])])
    d=np.array([lines.distance(_P(*q)) for q in pts])
    ok=d<500
    if ok.sum()<3:return {'points':int(ok.sum()),'median_m':float(np.median(d)),'p95_m':float(np.percentile(d,95)),'max_m':float(d.max()),'samples':[]}
    dd=d[ok]
    return {'points':int(ok.sum()),'median_m':round(float(np.median(dd)),2),'p95_m':round(float(np.percentile(dd,95)),2),'max_m':round(float(dd.max()),2),
            'samples':[{'s_m':round(float(a),1),'dev_m':round(float(b),2)} for a,b in zip(ss[ok],dd)],'transform':'nenhuma (coordenadas do DXF no CRS do projeto; KMZ convertido de WGS84)'}

def write_layer_preview(directory,entities,unmapped,limit=40000):
    """1.14: geometria simplificada de TODAS as camadas (mapeadas ou não) para conferir no editor qual é qual."""
    import json as _json
    by={}
    for e in list(entities)+list(unmapped or []):
        if e.get('overlay'):continue
        p=np.asarray(e['points'])
        if len(p)<2:continue
        g=LineString(p).simplify(.3)
        q=np.round(np.asarray(g.coords),2).tolist()
        d=by.setdefault(e['layer'],{'role':e['role'] if e['role']!='unmapped' else None,'p':[],'n':0})
        if d['n']+len(q)>limit:continue
        d['p'].append(q);d.setdefault('ids',[]).append(e.get('entity_id',''));d['n']+=len(q)
    f=Path(directory)/'camadas_previa.json';tmp=f.with_suffix('.tmp');tmp.write_text(_json.dumps(by,separators=(',',':')),encoding='utf-8');tmp.replace(f)
    return {k:v['n'] for k,v in by.items()}
