import os,json,sqlite3,uuid,threading,time
from pathlib import Path
def default_root():
    # Instalação organizada (1.8): <raiz>/suporte/sistema/app -> projetos em <raiz>/projetos.
    base=Path(__file__).resolve().parents[1]
    if base.name=='sistema' and base.parent.name=='suporte':return base.parents[1]/'projetos'
    return base/'dados'
ROOT=Path(os.environ.get('RODOVIA_DATA') or default_root()).resolve();ROOT.mkdir(parents=True,exist_ok=True)
DB=ROOT/'studio.sqlite3'
def connect():
    c=sqlite3.connect(DB,timeout=30);c.row_factory=sqlite3.Row;return c

def init():
    with connect() as c:
        c.executescript('CREATE TABLE IF NOT EXISTS projects(id TEXT PRIMARY KEY,name TEXT,created TEXT DEFAULT CURRENT_TIMESTAMP); CREATE TABLE IF NOT EXISTS jobs(id TEXT PRIMARY KEY,project TEXT,kind TEXT,state TEXT,progress REAL DEFAULT 0,message TEXT,error TEXT,created TEXT DEFAULT CURRENT_TIMESTAMP);')
init()
def directory(pid):
    if len(pid)!=32 or any(x not in '0123456789abcdef' for x in pid):raise ValueError('Identificador inválido.')
    p=ROOT/pid
    if not p.is_dir():raise FileNotFoundError('Projeto não encontrado.')
    return p

def replace(src,dst,attempts=25):
    # OneDrive, antivírus ou um player com o arquivo aberto bloqueiam a troca por instantes no Windows.
    for k in range(attempts):
        try:return Path(src).replace(dst)
        except PermissionError:
            if k==attempts-1:raise PermissionError(f'Arquivo em uso: {Path(dst).name}. Feche-o (player, OneDrive) e tente novamente.')
            time.sleep(.2)
def write_json(file,data):
    file=Path(file);tmp=file.with_suffix('.tmp');tmp.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8');replace(tmp,file)
def update(job,**fields):
    if not fields:return
    with connect() as c:c.execute('UPDATE jobs SET '+','.join(k+'=?' for k in fields)+' WHERE id=?',list(fields.values())+[job])
def job(jid):
    with connect() as c:r=c.execute('SELECT * FROM jobs WHERE id=?',(jid,)).fetchone()
    if not r:raise FileNotFoundError('Tarefa não encontrada.')
    return dict(r)
