import asyncio,json,os,sys,uuid,shutil,subprocess,threading,time,zipfile,re
from xml.etree.ElementTree import ParseError as ET_ERRORS
from pathlib import Path
from contextlib import asynccontextmanager
from fastapi import FastAPI,UploadFile,File,HTTPException,Request
from pydantic import BaseModel as _BM,ConfigDict,Field
from fastapi.responses import HTMLResponse,FileResponse,JSONResponse
from starlette.middleware.trustedhost import TrustedHostMiddleware
from . import store
from .models import Settings
from .render import ASSETS
BASE=Path(__file__).resolve().parents[1]
stop=threading.Event();dispatch_lock=threading.Lock()
def dispatcher():
    while not stop.is_set():
        with store.connect() as c:r=c.execute("SELECT * FROM jobs WHERE state='queued' ORDER BY created,rowid LIMIT 1").fetchone()
        if not r:stop.wait(.4);continue
        j=dict(r)
        with dispatch_lock:
            if store.job(j['id'])['state']!='queued':continue
            store.update(j['id'],state='running',message='Iniciando')
        # Erros que derrubam o processo (memória, DLL, importação) ficam em worker.log do projeto.
        try:wlog=open(store.ROOT/j['project']/'worker.log','ab')
        except OSError:wlog=subprocess.DEVNULL
        try:proc=subprocess.Popen([sys.executable,'-m','app.worker',j['id']],cwd=BASE,stdout=wlog,stderr=wlog)
        finally:
            if wlog is not subprocess.DEVNULL:wlog.close()
        while proc.poll() is None:
            if stop.wait(.2):proc.terminate();proc.wait();break
        state=store.job(j['id'])['state']
        if state in ['running','cancel_requested']:store.update(j['id'],state='interrupted',message='Processo interrompido. Consulte o log e gere novamente.')
@asynccontextmanager
async def lifespan(app):
    stop.clear()
    with store.connect() as c:c.execute("UPDATE jobs SET state='interrupted',message='Aplicação reiniciada. Inicie a tarefa novamente.' WHERE state IN ('running','cancel_requested')")
    thread=threading.Thread(target=dispatcher,daemon=True);thread.start();yield;stop.set();thread.join(timeout=5)
VERSION=json.loads((BASE/'VERSAO.json').read_text(encoding='utf-8')).get('version','1.3.0') if (BASE/'VERSAO.json').exists() else '1.3.0'
app=FastAPI(title='Rodovia Studio',version=VERSION,lifespan=lifespan)
app.add_middleware(TrustedHostMiddleware,allowed_hosts=['127.0.0.1','localhost','testserver'])
@app.middleware('http')
async def local_only(request:Request,call_next):
    origin=request.headers.get('origin','')
    if request.method not in ['GET','HEAD','OPTIONS'] and origin:
        from urllib.parse import urlsplit
        if urlsplit(origin).hostname not in ['localhost','127.0.0.1','testserver']:return JSONResponse({'detail':'Origem não autorizada.'},403)
    return await call_next(request)
@app.exception_handler(ValueError)
async def value_error(request,e):return JSONResponse({'detail':str(e)},422)
@app.exception_handler(FileNotFoundError)
async def not_found(request,e):return JSONResponse({'detail':str(e)},404)
def idle(pid):
    store.directory(pid)
    with store.connect() as c:r=c.execute("SELECT id FROM jobs WHERE project=? AND state IN ('queued','running','cancel_requested')",(pid,)).fetchone()
    if r:raise HTTPException(409,'Aguarde a tarefa atual terminar ou cancele-a.')
def enqueue(pid,kind):
    store.directory(pid);jid=uuid.uuid4().hex
    with store.connect() as c:
        c.execute('BEGIN IMMEDIATE')
        busy=c.execute("SELECT id FROM jobs WHERE project=? AND state IN ('queued','running','cancel_requested')",(pid,)).fetchone()
        if busy:raise HTTPException(409,'Aguarde a tarefa atual terminar ou cancele-a.')
        c.execute('INSERT INTO jobs(id,project,kind,state,message) VALUES(?,?,?,?,?)',(jid,pid,kind,'queued','Na fila'))
    return {'id':jid,'state':'queued'}
@app.get('/',response_class=HTMLResponse)
def index():return (BASE/'app/index.html').read_text(encoding='utf-8')
@app.get('/ajuda',response_class=HTMLResponse)
def ajuda():return (BASE/'app/ajuda.html').read_text(encoding='utf-8')
@app.get('/app.js')
def app_js():
    return FileResponse(BASE/'app/app.js',media_type='application/javascript',headers={'Cache-Control':'no-store'})
@app.get('/api/health')
def health():
    import imageio_ffmpeg
    return {'status':'ok','version':VERSION,'ffmpeg':Path(imageio_ffmpeg.get_ffmpeg_exe()).is_file(),'data':str(store.ROOT)}
@app.get('/api/projects')
def projects():
    with store.connect() as c:return [dict(r) for r in c.execute('SELECT * FROM projects ORDER BY created DESC,rowid DESC')]
@app.post('/api/projects',status_code=201)
def create(s:Settings):
    pid=uuid.uuid4().hex;d=store.ROOT/pid;d.mkdir();store.write_json(d/'config.json',s.model_dump())
    with store.connect() as c:c.execute('INSERT INTO projects(id,name) VALUES(?,?)',(pid,s.name))
    return {'id':pid,'config':s.model_dump()}
# ---------------- 1.19: limpar trabalho / retirar projeto ----------------
class ResetBody(_BM):
    groups:list[str]=['obras','sinalizacao']
    outputs:bool=False

@app.get('/api/reset_groups')
def reset_groups():
    from .workreset import GROUPS,DEFAULT
    return {'groups':[{'id':k,'label':v[0],'keys':v[1],'default':k in DEFAULT} for k,v in GROUPS.items()]}

@app.post('/api/projects/{pid}/reset_work')
def reset_work(pid,body:ResetBody):
    """Limpa as marcações escolhidas e mantém as características do segmento (com cópia da configuração)."""
    from .workreset import reset
    idle(pid);d,s=_config(pid)
    try:new,info=reset(d,s,body.groups,body.outputs)
    except ValueError as e:raise HTTPException(422,str(e))
    _save_config(pid,new);return {'config':new.model_dump(),**info}

@app.post('/api/projects/{pid}/reset_work/undo')
def reset_work_undo(pid):
    from .workreset import undo
    idle(pid);d=store.directory(pid)
    try:s,name=undo(d)
    except ValueError as e:raise HTTPException(409,str(e))
    _save_config(pid,s);return {'config':s.model_dump(),'restored':name}

class SaveAsBody(_BM):
    name:str=Field(min_length=1,max_length=100)

@app.post('/api/projects/{pid}/save_as',status_code=201)
def project_save_as(pid,body:SaveAsBody):
    """1.22: “Salvar como”: cópia do projeto (configuração, DXF/KMZ, imagens locais, camadas e elevação), sem caches."""
    d,s=_config(pid);new=uuid.uuid4().hex;nd=store.ROOT/new;nd.mkdir()
    try:
        for item in d.iterdir():
            if item.name.startswith(('cache','config_antes','config_restaurado')) or item.suffix in ('.mp4','.tmp') or item.name in ('preview.png','video.json','encoder.json','ffmpeg.log'):continue
            if item.is_dir():
                if item.name in ('imagem_local','camadas','elevacao','hidrografia'):shutil.copytree(item,nd/item.name)
                continue
            shutil.copy2(item,nd/item.name)
        s.name=body.name;store.write_json(nd/'config.json',s.model_dump())
    except Exception:
        shutil.rmtree(nd,ignore_errors=True);raise
    with store.connect() as c:c.execute('INSERT INTO projects(id,name) VALUES(?,?)',(new,body.name))
    return {'id':new,'name':body.name}

@app.delete('/api/projects/{pid}')
def project_trash(pid):
    """Retira o projeto da lista: a pasta vai para _lixeira (pode ser recuperada manualmente)."""
    from .workreset import trash
    idle(pid);store.directory(pid)
    dst=trash(store.ROOT,pid)
    with store.connect() as c:c.execute('DELETE FROM projects WHERE id=?',(pid,))
    return {'trash':dst.name}

@app.post('/api/example',status_code=201)
def example():
    s=Settings.model_validate(json.loads((ASSETS/'th57/config.json').read_text(encoding='utf-8')));r=create(s);d=store.directory(r['id']);shutil.copyfile(ASSETS/'th57/projeto.dxf',d/'input.dxf');return r
@app.get('/api/projects/{pid}')
def get_project(pid):
    d=store.directory(pid);r={'id':pid,'config':Settings.model_validate_json((d/'config.json').read_text(encoding='utf-8')).model_dump(),'files':{'dxf':(d/'input.dxf').exists(),'kmz':(d/'input.kmz').exists()}}
    if (d/'analysis.json').exists():r['analysis']=json.loads((d/'analysis.json').read_text(encoding='utf-8'))
    if (d/'video.json').exists():r['render_info']=json.loads((d/'video.json').read_text(encoding='utf-8'))
    if (d/'preview.json').exists():r['preview']=json.loads((d/'preview.json').read_text(encoding='utf-8'))
    r['editor_ready']=(d/'editor.json').exists()
    return r

@app.get('/api/projects/{pid}/dxf_layers')
def dxf_layers(pid):
    from .geometry import read_dxf,walk,split_layers,eff_layer,guess
    from collections import Counter
    d=store.directory(pid);path=d/'input.dxf'
    if not path.exists():return {'layers':[],'warnings':[]}
    s=Settings.model_validate_json((d/'config.json').read_text(encoding='utf-8'))
    warnings=[];doc=read_dxf(path,warnings);ents=list(walk(doc.modelspace()))
    split=split_layers(ents,doc,s.layer_split)
    counts=Counter(eff_layer(e,split,doc) for e in ents)
    return {'layers':[{'name':n,'count':c,'suggested_role':guess(n)} for n,c in sorted(counts.items())],'warnings':warnings}
@app.put('/api/projects/{pid}/config')
def config(pid,s:Settings):
    idle(pid);d=store.directory(pid);store.write_json(d/'config.json',s.model_dump())
    with store.connect() as c:c.execute('UPDATE projects SET name=? WHERE id=?',(s.name,pid))
    return {'ok':True}
@app.post('/api/projects/{pid}/files')
async def upload(pid,file:UploadFile=File(...)):
    idle(pid);ext=Path(file.filename or '').suffix.lower()
    if ext not in ['.dxf','.kmz']:raise HTTPException(415,'Envie DXF ou KMZ. DWG deve ser convertido para DXF.')
    d=store.directory(pid);tmp=d/('upload'+ext+'.tmp');n=0
    try:
        with tmp.open('wb') as fo:
            while chunk:=await file.read(1024*1024):
                n+=len(chunk)
                if n>400*1024*1024:raise HTTPException(413,'Limite de 400 MB por arquivo.')
                fo.write(chunk)
        if n==0:raise HTTPException(422,'Arquivo vazio.')
        if ext=='.kmz':
            try:
                with zipfile.ZipFile(tmp) as z:
                    if sum(v.file_size for v in z.infolist())>100*1024*1024 or not any(v.filename.lower().endswith('.kml') for v in z.infolist()):raise ValueError('KMZ inválido ou excessivamente grande.')
            except zipfile.BadZipFile:raise ValueError('KMZ não é um arquivo ZIP válido.')
        tmp.replace(d/('input'+ext));(d/'analysis.json').unlink(missing_ok=True)
        config=json.loads((d/'config.json').read_text(encoding='utf-8'));config['coordinates_confirmed']=False;store.write_json(d/'config.json',config)
    finally:tmp.unlink(missing_ok=True);await file.close()
    return {'ok':True,'bytes':n,'type':ext}
@app.post('/api/projects/{pid}/analyze',status_code=202)
def analyze_job(pid):return enqueue(pid,'analyze')
@app.post('/api/projects/{pid}/preview',status_code=202)
def preview_job(pid):return enqueue(pid,'preview')
@app.post('/api/projects/{pid}/render',status_code=202)
def render_job(pid):
    d=store.directory(pid);s=Settings.model_validate(json.loads((d/'config.json').read_text(encoding='utf-8')))
    if not s.coordinates_confirmed:raise HTTPException(422,'Confirme as coordenadas na configuração antes de renderizar.')
    return enqueue(pid,'render')
@app.post('/api/projects/{pid}/reference',status_code=202)
def reference_job(pid):
    if not (ASSETS/'th57/referencia.mp4').exists():raise HTTPException(410,'O vídeo de referência foi substituído pela ficha técnica (somente dados para comparação).')
    return enqueue(pid,'reference')
@app.get('/api/reference/profile')
def reference_profile():
    f=ASSETS/'th57/referencia_ficha.json'
    data=json.loads(f.read_text(encoding='utf-8')) if f.exists() else {'status':'ausente'}
    data['video_present']=(ASSETS/'th57/referencia.mp4').exists();return data
@app.post('/api/projects/{pid}/reference_profile',status_code=202)
def reference_profile_job(pid,remove:bool=False):
    if not (ASSETS/'th57/referencia.mp4').exists():raise HTTPException(410,'O vídeo de referência não está mais na pasta; a ficha técnica já é a referência.')
    return enqueue(pid,'reference_profile_remove' if remove else 'reference_profile')
@app.post('/api/projects/{pid}/compare',status_code=202)
def compare_job(pid):
    if not (store.directory(pid)/'video.mp4').exists():raise HTTPException(409,'Gere um vídeo antes de comparar.')
    return enqueue(pid,'compare')
@app.get('/api/projects/{pid}/comparison')
def comparison(pid):
    f=store.directory(pid)/'comparacao.json'
    if not f.exists():return {'rows':[],'reference_status':None}
    return json.loads(f.read_text(encoding='utf-8'))
@app.get('/api/jobs/{jid}')
def get_job(jid):return store.job(jid)
@app.post('/api/jobs/{jid}/cancel')
def cancel(jid):
    with dispatch_lock:
        j=store.job(jid)
        if j['state']=='queued':store.update(jid,state='cancelled',message='Cancelado antes de iniciar')
        elif j['state']=='running':store.update(jid,state='cancel_requested',message='Cancelamento solicitado')
    return store.job(jid)
@app.get('/api/projects/{pid}/preview.png')
def preview_file(pid):
    file=store.directory(pid)/'preview.png'
    if not file.is_file():raise HTTPException(404,'Gere uma prévia primeiro.')
    return FileResponse(file,media_type='image/png',headers={'Cache-Control':'no-store'})
@app.get('/api/projects/{pid}/video.mp4')
def video_file(pid):
    file=store.directory(pid)/'video.mp4'
    if not file.is_file():raise HTTPException(404,'O vídeo ainda não está pronto.')
    return FileResponse(file,media_type='video/mp4',filename='video_rodoviario.mp4')
@app.get('/api/projects/{pid}/config.json')
def config_file(pid):return FileResponse(store.directory(pid)/'config.json',filename='configuracao_rodovia.json')
@app.get('/api/projects/{pid}/log')
def logs(pid):
    d=store.directory(pid);return {'error':(d/'error.log').read_text(encoding='utf-8')[-8000:] if (d/'error.log').exists() else '', 'ffmpeg':(d/'ffmpeg.log').read_text(encoding='utf-8',errors='replace')[-8000:] if (d/'ffmpeg.log').exists() else ''}

@app.get('/api/projects/{pid}/traffic_network.json')
def traffic_report(pid):
    path=store.directory(pid)/'traffic_network.json'
    if not path.exists():raise HTTPException(404,'Gere uma prévia primeiro.')
    return FileResponse(path,filename='diagnostico_trafego.json')

@app.get('/api/maintenance')
def maintenance_info():
    from .maintenance import clean
    return clean(store.ROOT)

@app.post('/api/maintenance/cleanup')
def maintenance_clean():
    from .maintenance import clean
    with dispatch_lock:
        with store.connect() as c:
            row=c.execute("SELECT id FROM jobs WHERE state IN ('queued','running','cancel_requested') LIMIT 1").fetchone()
        if row:raise HTTPException(409,'Termine ou cancele a tarefa antes de limpar os caches.')
        return clean(store.ROOT,True)


@app.get('/api/projects/{pid}/editor.json')
def editor_file(pid):
    path=store.directory(pid)/'editor.json'
    if not path.exists():raise HTTPException(404,'Gere uma prévia para carregar o editor.')
    return FileResponse(path,media_type='application/json',headers={'Cache-Control':'no-store'})

@app.post('/api/projects/{pid}/validate_path')
def validate_path(pid,body:dict):
    """Valida um fluxo desenhado antes de aceitá-lo (mesma regra do motor)."""
    import shapely
    from shapely.geometry import Polygon
    from shapely.ops import unary_union
    from .markup import validate_path as check
    from .models import Point
    d=store.directory(pid)/'editor'
    if not (d/'allowed.wkb').exists():raise HTTPException(409,'Gere a prévia antes de incluir fluxos.')
    try:points=[Point.model_validate(p) for p in body.get('points',[])]
    except Exception:raise HTTPException(422,'Pontos inválidos.')
    g={n:shapely.from_wkb((d/(n+'.wkb')).read_bytes()) for n in ['roads','obstacles','allowed']}
    cfg=Settings.model_validate(json.loads((store.directory(pid)/'config.json').read_text(encoding='utf-8')))
    ex=unary_union([Polygon([(p.x,p.y) for p in a]).buffer(0) for a in cfg.exclusions]) if cfg.exclusions else Polygon()
    allowed=g['allowed'].difference(ex) if not ex.is_empty else g['allowed']
    return check(points,g['roads'],g['obstacles'],ex,allowed)

@app.post('/api/alignment/fit')
def alignment_fit(body:dict):
    from .alignment import fit
    from .models import DxfAlignment
    al=DxfAlignment.model_validate(body)
    return fit(al.pairs,al.mode)

# ---------------- Fase B: camadas, imagem local, exportação e importação ----------------
from fastapi import Form
from fastapi.responses import Response
from typing import List

def _config(pid):
    d=store.directory(pid);return d,Settings.model_validate(json.loads((d/'config.json').read_text(encoding='utf-8')))
def _save_config(pid,s):
    d=store.directory(pid);store.write_json(d/'config.json',s.model_dump() if hasattr(s,'model_dump') else s)
async def _receive(file,dest,limit):
    n=0;tmp=Path(str(dest)+'.tmp')
    try:
        with tmp.open('wb') as fo:
            while chunk:=await file.read(1024*1024):
                n+=len(chunk)
                if n>limit:raise HTTPException(413,f'Limite de {limit//1024//1024} MB por arquivo.')
                fo.write(chunk)
        if n==0:raise HTTPException(422,'Arquivo vazio.')
        store.replace(tmp,dest)
    finally:tmp.unlink(missing_ok=True);await file.close()
    return n

@app.post('/api/projects/{pid}/overlays',status_code=201)
async def overlay_upload(pid,file:UploadFile=File(...)):
    from .geometry import overlay_layers,guess
    from .models import OverlayLayer
    idle(pid);name=file.filename or 'camada.dxf'
    if Path(name).suffix.lower()!='.dxf':raise HTTPException(415,'Envie a camada adicional em DXF.')
    d,s=_config(pid);oid=uuid.uuid4().hex;(d/'camadas').mkdir(exist_ok=True);dest=d/'camadas'/(oid+'.dxf')
    await _receive(file,dest,400*1024*1024)
    try:layers=overlay_layers(dest)
    except Exception as e:
        dest.unlink(missing_ok=True);raise HTTPException(422,'DXF inválido: '+str(e)[:200])
    ov=OverlayLayer(id=oid,name=Path(name).stem[:100] or 'Camada',original_name=name[:260],order=len(s.overlays),roles={l['name']:(l['suggested_role'] or '') for l in layers})
    s.overlays.append(ov);_save_config(pid,s)
    return {'overlay':ov.model_dump(),'layers':layers}

@app.get('/api/projects/{pid}/overlays/{oid}/layers')
def overlay_info(pid,oid):
    from .geometry import overlay_layers
    if len(oid)!=32 or any(c not in '0123456789abcdef' for c in oid):raise HTTPException(422,'Identificador inválido.')
    path=store.directory(pid)/'camadas'/(oid+'.dxf')
    if not path.exists():raise HTTPException(404,'Camada não encontrada.')
    return overlay_layers(path)

@app.delete('/api/projects/{pid}/overlays/{oid}')
def overlay_delete(pid,oid):
    idle(pid);d,s=_config(pid)
    if not any(o.id==oid for o in s.overlays):raise HTTPException(404,'Camada não encontrada.')
    s.overlays=[o for o in s.overlays if o.id!=oid];_save_config(pid,s)
    (d/'camadas'/(oid+'.dxf')).unlink(missing_ok=True)
    return {'ok':True}

@app.post('/api/projects/{pid}/imagery')
async def imagery_upload(pid,files:List[UploadFile]=File(...),crs:str=Form(''),mode:str=Form('replace')):
    """Imagem local. mode='replace' (a imagem principal, como antes) ou 'add' (1.17: mais uma no mosaico).
    ECW/MrSID e outros formatos do GDAL ficam guardados e são convertidos pela tarefa 'Converter'."""
    from .local_imagery import IMAGE_EXT,WORLD_EXT,CONVERT_EXT,georef,describe
    from .models import LocalImagery,LocalSource
    idle(pid);d,s=_config(pid);base=d/'imagem_local';base.mkdir(exist_ok=True)
    names={'image':None,'world':None,'prj':None,'convert':None}
    for f in files:
        ext=Path(f.filename or '').suffix.lower();safe=re.sub(r'[^\w.\- ]','_',Path(f.filename or 'arquivo').name)[:120]
        kind='image' if ext in IMAGE_EXT else 'convert' if ext in CONVERT_EXT else 'world' if ext in WORLD_EXT else 'prj' if ext=='.prj' else None
        if kind is None:raise HTTPException(415,f'Arquivo não suportado: {f.filename}. Use GeoTIFF/COG, JPEG2000 (.jp2), JPG/PNG + arquivo de mundo e .prj, ou ECW/MrSID (conversão com o QGIS).')
        await _receive(f,base/safe,4000*1024*1024 if kind=='convert' else 2500*1024*1024);names[kind]=safe
    if names['convert'] and not names['image']:
        from .local_tiles import find_gdal
        g=find_gdal()
        store.write_json(base/'_converter.json',{'file':names['convert'],'mode':mode,'crs':crs.strip() or None})
        return {'needs_conversion':True,'file':names['convert'],'gdal':bool(g),'gdal_bin':g['bin'] if g else None}
    if not names['image']:raise HTTPException(422,'Envie a imagem (GeoTIFF, JPEG2000, JPG ou PNG).')
    li=LocalImagery(name=names['image'],image=names['image'],world=names['world'],prj=names['prj'],crs=crs.strip() or None)
    try:georef(base/li.image,base/li.world if li.world else None,base/li.prj if li.prj else None,li.crs);info=describe(d,li,s.crs)
    except ValueError as e:
        for k,n in names.items():
            if n and k!='convert':(base/n).unlink(missing_ok=True)
        raise HTTPException(422,str(e))
    if mode=='add' and s.local_imagery.image:
        s.local_imagery.others.append(LocalSource(**{k:getattr(li,k) for k in ('name','image','world','prj','crs')}))
    else:
        li.others=s.local_imagery.others;li.detail=s.local_imagery.detail;li.editor=s.local_imagery.editor
        s.local_imagery=li;s.imagery='local'
    _save_config(pid,s)
    return {'local_imagery':s.local_imagery.model_dump(),'info':info}

@app.post('/api/projects/{pid}/imagery/convert',status_code=202)
def imagery_convert(pid):
    d=store.directory(pid)
    if not (d/'imagem_local'/'_converter.json').exists():raise HTTPException(409,'Envie primeiro o arquivo ECW/MrSID.')
    return enqueue(pid,'convert_imagery')

_SRC_FIELDS=('name','image','world','prj','crs','nodata','shift_x','shift_y','rotation_deg','scale')
def _li_entries(li):
    """Imagens do mosaico em ordem de prioridade (0 = principal), como dicionários de origem."""
    first={k:getattr(li,k) for k in _SRC_FIELDS};first['enabled']=True
    return [first]+[o.model_dump() for o in li.others]
def _li_rebuild(li,entries):
    from .models import LocalImagery,LocalSource
    if not entries:return LocalImagery()
    head={k:entries[0].get(k) for k in _SRC_FIELDS}
    return li.model_copy(update={**head,'others':[LocalSource(**e) for e in entries[1:]]})

@app.delete('/api/projects/{pid}/imagery/{index}')
def imagery_remove(pid,index:int):
    """Retira uma imagem do mosaico (0 = principal; a próxima vira principal). O arquivo fica na pasta do projeto."""
    idle(pid);d,s=_config(pid);li=s.local_imagery;ent=_li_entries(li) if li.image else []
    if not 0<=index<len(ent):raise HTTPException(404,'Imagem não encontrada.')
    ent.pop(index);s.local_imagery=_li_rebuild(li,ent)
    if not ent and s.imagery=='local':s.imagery='esri'
    _save_config(pid,s);_local_cache.pop(pid,None);return {'local_imagery':s.local_imagery.model_dump()}

class ImageOrder(_BM):
    index:int
    to:int

@app.post('/api/projects/{pid}/imagery/order')
def imagery_order(pid,body:ImageOrder):
    """1.19: muda a prioridade de uma imagem nas sobreposições (0 = fica por cima). Onde nenhuma cobre, vale a fonte web."""
    idle(pid);d,s=_config(pid);li=s.local_imagery;ent=_li_entries(li) if li.image else []
    if not(0<=body.index<len(ent) and 0<=body.to<len(ent)):raise HTTPException(404,'Imagem não encontrada.')
    e=ent.pop(body.index);ent.insert(body.to,e);s.local_imagery=_li_rebuild(li,ent)
    _save_config(pid,s);_local_cache.pop(pid,None);return {'local_imagery':s.local_imagery.model_dump()}

class ImageAdjust(_BM):
    model_config=ConfigDict(allow_inf_nan=False)
    shift_x:float=Field(default=0,ge=-2000,le=2000)
    shift_y:float=Field(default=0,ge=-2000,le=2000)
    rotation_deg:float=Field(default=0,ge=-30,le=30)
    scale:float=Field(default=1,ge=.8,le=1.25)
    enabled:bool|None=None

@app.put('/api/projects/{pid}/imagery/{index}/adjust')
def imagery_adjust(pid,index:int,body:ImageAdjust):
    """1.19: ajuste por grips (deslocar, girar, escalar) de uma imagem local; o arquivo não é alterado."""
    idle(pid);d,s=_config(pid);li=s.local_imagery;ent=_li_entries(li) if li.image else []
    if not 0<=index<len(ent):raise HTTPException(404,'Imagem não encontrada.')
    u=body.model_dump(exclude_none=True)
    if index==0:u.pop('enabled',None)
    ent[index].update(u);s.local_imagery=_li_rebuild(li,ent)
    _save_config(pid,s);_local_cache.pop(pid,None);return {'local_imagery':s.local_imagery.model_dump()}

_local_cache={}
def _local_mosaic(pid):
    from .local_tiles import LocalMosaic
    d,s=_config(pid);li=s.local_imagery
    if not li.image:return None
    sig=json.dumps(li.model_dump(),sort_keys=True)+s.crs
    hit=_local_cache.get(pid)
    if hit and hit[0]==sig:return hit[1]
    m=LocalMosaic(d,s);_local_cache[pid]=(sig,m);return m

@app.get('/api/projects/{pid}/local/info')
def local_info(pid):
    from .local_tiles import find_gdal,gdal_formats
    from pyproj import Transformer
    g=find_gdal();out={'gdal':bool(g),'gdal_bin':g['bin'] if g else None,'sources':[]}
    try:m=_local_mosaic(pid)
    except Exception as e:out['error']=str(e)[:300];return out
    if m is None:return out
    tr=Transformer.from_crs(m.target,3857,always_xy=True)
    for k,(src,b) in enumerate(zip(m.sources,m.bbox)):
        x,y=tr.transform([b[0],b[2]],[b[1],b[3]])
        c=src.corners(m.target)
        out['sources'].append({'index':m.index[k],'name':src.name,'file':src.path.name,'size':list(src.size),'pixel_m':round(src.pixel_m(m.target),4),'crs':src.crs.to_string(),'bounds':list(b),'merc':[min(x),min(y),max(x),max(y)],
                               'corners':[[float(p[0]),float(p[1])] for p in c],'center':list(src.center),'adjust':dict(zip(('shift_x','shift_y','rotation_deg','scale'),src.adj))})
    out['count']=1+len(m.li.others)
    px=m.pixel_m();out['pixel_m']=px
    import math
    out['max_zoom']=int(min(22,max(15,math.ceil(math.log2(2*20037508.342789244/256/max(px,.02))))))
    out['key']=m.key;out['editor']=m.li.editor
    return out

@app.get('/api/projects/{pid}/local_tiles/{z}/{y}/{x}.png')
def local_tile(pid,z:int,y:int,x:int):
    """Ladrilho Web Mercator da imagem local (editor), com cache em disco; 204 fora da cobertura."""
    from .local_tiles import web_tile
    if not(0<=z<=23 and 0<=x<2**z and 0<=y<2**z):raise HTTPException(422,'Ladrilho inválido.')
    try:m=_local_mosaic(pid)
    except Exception as e:raise HTTPException(409,str(e)[:300])
    if m is None:return Response(status_code=204)
    d=store.directory(pid)/'cache_local_web'/m.key/str(z)/str(y);f=d/f'{x}.png';e=d/f'{x}.empty'
    if f.exists():return FileResponse(f,media_type='image/png',headers={'Cache-Control':'max-age=86400'})
    if e.exists():return Response(status_code=204)
    a=web_tile(m,z,x,y);d.mkdir(parents=True,exist_ok=True)
    if a[:,:,3].max()==0:
        e.write_bytes(b'');return Response(status_code=204)
    import cv2 as _cv
    ok,buf=_cv.imencode('.png',_cv.cvtColor(a,_cv.COLOR_RGBA2BGRA))
    tmp=f.with_suffix('.tmp');tmp.write_bytes(buf.tobytes());tmp.replace(f)
    return Response(buf.tobytes(),media_type='image/png',headers={'Cache-Control':'max-age=86400'})

@app.post('/api/projects/{pid}/export',status_code=202)
def export_job(pid):return enqueue(pid,'export')
@app.post('/api/projects/{pid}/frames',status_code=202)
def frames_job(pid):return enqueue(pid,'frames')

EXPORTS={'modelo_wgs84.geojson':'application/geo+json','modelo.kml':'application/vnd.google-earth.kml+xml','modelo.kmz':'application/vnd.google-earth.kmz','marcacoes.dxf':'application/dxf','obras.csv':'text/csv'}
@app.get('/api/projects/{pid}/exports')
def export_list(pid):
    d=store.directory(pid)/'exportacao'
    files=[{'name':f.name,'bytes':f.stat().st_size} for f in sorted(d.iterdir()) if f.is_file() and not f.name.endswith('.tmp')] if d.exists() else []
    frames=sorted([p.name for p in (store.directory(pid)/'quadros_png').iterdir() if p.is_dir()]) if (store.directory(pid)/'quadros_png').exists() else []
    return {'files':files,'png_sequences':frames,'folder':str(d)}
@app.get('/api/projects/{pid}/exports/{name}')
def export_file(pid,name):
    if not re.fullmatch(r'[\w.\-]{1,80}',name):raise HTTPException(422,'Nome inválido.')
    f=store.directory(pid)/'exportacao'/name
    if not f.is_file():raise HTTPException(404,'Gere a exportação primeiro.')
    return FileResponse(f,filename=name,media_type=EXPORTS.get(name,'application/geo+json' if name.endswith('.geojson') else 'application/octet-stream'))

@app.get('/api/projects/{pid}/package.zip')
def package_zip(pid):
    from .exporters import package
    d,s=_config(pid);data=package(d,VERSION)
    safe=re.sub(r'[^\w\-]+','_',s.name)[:60] or 'projeto'
    return Response(data,media_type='application/zip',headers={'Content-Disposition':f'attachment; filename="{safe}.rodovia.zip"'})

@app.post('/api/import_package',status_code=201)
async def import_package(file:UploadFile=File(...)):
    from .exporters import unpack
    data=await file.read();await file.close()
    if len(data)>900*1024*1024:raise HTTPException(413,'Pacote acima de 900 MB.')
    pid=uuid.uuid4().hex;d=store.ROOT/pid;d.mkdir()
    try:
        unpack(data,d);s=Settings.model_validate(json.loads((d/'config.json').read_text(encoding='utf-8')))
        store.write_json(d/'config.json',s.model_dump())
    except Exception as e:
        shutil.rmtree(d,ignore_errors=True)
        raise HTTPException(422,'Pacote inválido: '+str(e)[:300])
    with store.connect() as c:c.execute('INSERT INTO projects(id,name) VALUES(?,?)',(pid,s.name))
    return {'id':pid,'config':s.model_dump()}

@app.post('/api/projects/{pid}/import_markings')
async def import_markings(pid,file:UploadFile=File(...)):
    from .exporters import read_any,apply_import
    from .per import read_csv
    idle(pid);data=await file.read();await file.close();d,s=_config(pid)
    if Path(file.filename or '').suffix.lower()=='.csv':
        works=read_csv(data);s.works=works;_save_config(pid,s);return {'imported':{'works':len(works)}}
    try:feats=read_any(data,file.filename or '',s.crs)
    except Exception as e:raise HTTPException(422,"Arquivo não reconhecido: "+str(e)[:300])
    cfg,counts=apply_import(s.model_dump(),feats)
    if not counts:raise HTTPException(422,'Nenhuma marcação do Rodovia Studio encontrada no arquivo.')
    s=Settings.model_validate(cfg);_save_config(pid,s)
    return {'imported':counts}

@app.get('/api/projects/{pid}/preview_cabin.png')
def preview_cabin(pid):
    f=store.directory(pid)/'preview_cabin.png'
    if not f.is_file():raise HTTPException(404,'Gere a prévia com a vista da cabine ativa e “Câmera do vídeo”.')
    return FileResponse(f,media_type='image/png',headers={'Cache-Control':'no-store'})

@app.get('/marca/icone.png',include_in_schema=False)
def app_icon():
    f=BASE/'app/icone.png'
    return FileResponse(f,media_type='image/png',headers={'Cache-Control':'public, max-age=86400'}) if f.exists() else Response(status_code=404)

@app.get('/marca/georas.png',include_in_schema=False)
def georas_logo():
    f=BASE/'app/georas_logo.png'
    return FileResponse(f,media_type='image/png',headers={'Cache-Control':'public, max-age=86400'}) if f.exists() else Response(status_code=404)

@app.get('/favicon.ico',include_in_schema=False)
def favicon():
    f=BASE/'app/icone.png'
    return FileResponse(f,media_type='image/png') if f.exists() else Response(status_code=204)

@app.post('/api/projects/{pid}/elevation')
async def elevation_upload(pid,files:List[UploadFile]=File(...),crs:str=Form('')):
    """MDT local: GeoTIFF de elevação ou imagem de 1 banda + arquivo de mundo (+ .prj ou CRS)."""
    from .local_imagery import IMAGE_EXT,WORLD_EXT,georef
    idle(pid);d,s=_config(pid);base=d/'elevacao';base.mkdir(exist_ok=True);names={'image':None,'world':None,'prj':None}
    for f in files:
        ext=Path(f.filename or '').suffix.lower();safe=re.sub(r'[^\w.\- ]','_',Path(f.filename or 'mdt').name)[:120]
        kind='image' if ext in IMAGE_EXT else 'world' if ext in WORLD_EXT else 'prj' if ext=='.prj' else None
        if kind is None:raise HTTPException(415,f'Arquivo não suportado: {f.filename}. Use GeoTIFF (ou TIF/PNG + arquivo de mundo) e .prj.')
        await _receive(f,base/safe,1500*1024*1024);names[kind]=safe
    if not names['image']:raise HTTPException(422,'Envie o arquivo de elevação (GeoTIFF).')
    try:georef(base/names['image'],base/names['world'] if names['world'] else None,base/names['prj'] if names['prj'] else None,crs.strip() or None)
    except ValueError as e:
        for n in names.values():
            if n:(base/n).unlink(missing_ok=True)
        raise HTTPException(422,str(e))
    s.elevation=s.elevation.model_copy(update={'source':'local','file':names['image'],'world':names['world'],'prj':names['prj'],'crs':crs.strip() or None});_save_config(pid,s)
    return {'elevation':s.elevation.model_dump()}

@app.get('/api/projects/{pid}/elevation_at')
def elevation_at(pid,x:float,y:float):
    from .elevation import value_at
    return {'z':value_at(store.directory(pid),x,y)}

# ---------------- 1.9: editor sobre imagem web ----------------
@app.get('/tiles/esri/{z}/{y}/{x}')
def esri_tile(z:int,y:int,x:int):
    from .webmap import tile
    try:data=tile(store.ROOT/'_ladrilhos',z,y,x)
    except ValueError as e:raise HTTPException(422,str(e))
    except Exception:raise HTTPException(404,'Ladrilho indisponível (sem internet e sem cache).')
    return Response(data,media_type='image/jpeg',headers={'Cache-Control':'public, max-age=604800'})

# ---------------- 1.19: outras fontes web ----------------
def _img_type(data):return 'image/png' if data[:8]==b'\x89PNG\r\n\x1a\n' else 'image/jpeg'

@app.get('/api/wayback/releases')
def wayback_list():
    from .webmap import wayback_releases
    try:return {'releases':wayback_releases(store.ROOT/'_ladrilhos')}
    except Exception as e:raise HTTPException(503,'Não foi possível obter a lista de datas da Esri Wayback (sem internet?). '+str(e)[:150])

@app.get('/api/projects/{pid}/web_tiles/{z}/{y}/{x}')
def project_web_tile(pid,z:int,y:int,x:int):
    """Ladrilho da fonte web escolhida no projeto (Esri atual, Wayback, XYZ ou WMS), com cache em disco."""
    from .webmap import tile,web_source
    d,s=_config(pid)
    try:src=web_source(s);data=tile(store.ROOT/'_ladrilhos',z,y,x,source=src)
    except ValueError as e:raise HTTPException(422,str(e))
    except Exception:raise HTTPException(404,'Ladrilho indisponível (sem internet e sem cache).')
    return Response(data,media_type=_img_type(data),headers={'Cache-Control':'public, max-age=604800'})

@app.get('/api/qms/search')
def qms_search(q:str):
    from . import qms
    try:return {'services':qms.search(q)}
    except ValueError as e:raise HTTPException(422,str(e))
    except Exception:raise HTTPException(503,'Não foi possível consultar QuickMapServices. Verifique o acesso a qms.nextgis.com; a fonte salva no projeto continua disponível pelo seu serviço e cache.')

@app.get('/api/qms/services/{service_id}')
def qms_service(service_id:int):
    from . import qms
    try:return qms.service(service_id).model_dump()
    except ValueError as e:raise HTTPException(422,str(e))
    except Exception:raise HTTPException(503,'Não foi possível carregar este serviço do QuickMapServices. Tente novamente quando a conexão estiver disponível.')

@app.get('/api/projects/{pid}/geo')
def project_geo(pid):
    from .webmap import fit
    d=store.directory(pid);a=d/'analysis.json'
    if not a.exists():raise HTTPException(409,'Analise os arquivos para abrir o editor sobre a imagem web.')
    rep=json.loads(a.read_text(encoding='utf-8'));cfg=json.loads((d/'config.json').read_text(encoding='utf-8'))
    key=json.dumps([rep['bounds'],cfg.get('crs')]);cache=d/'geo.json'
    if cache.exists():
        g=json.loads(cache.read_text(encoding='utf-8'))
        if g.get('key')==key:return g
    g=fit(cfg.get('crs','EPSG:31983'),rep['bounds']);g['key']=key;store.write_json(cache,g);return g

@app.get('/api/projects/{pid}/vectors.json')
def project_vectors(pid):
    f=store.directory(pid)/'vectors.json'
    if not f.exists():raise HTTPException(404,'Analise os arquivos para gerar os vetores do editor.')
    return FileResponse(f,media_type='application/json',headers={'Cache-Control':'no-store'})

# ---------------- 1.10: cidades próximas ----------------
@app.get('/api/projects/{pid}/cities/auto')
def project_cities(pid,radius_km:float=25):
    from .cities import nearby
    d=store.directory(pid);a=d/'analysis.json'
    if not a.exists():raise HTTPException(409,'Analise os arquivos antes de buscar as cidades próximas.')
    if not(1<=radius_km<=150):raise HTTPException(422,'Raio entre 1 e 150 km.')
    rep=json.loads(a.read_text(encoding='utf-8'));cfg=json.loads((d/'config.json').read_text(encoding='utf-8'))
    try:return {'cities':nearby(d,cfg.get('crs','EPSG:31983'),rep['bounds'],radius_km)}
    except ValueError as e:raise HTTPException(422,str(e))
    except OSError as e:raise HTTPException(503,str(e)+' Você pode marcar as cidades à mão com a ferramenta Cidade.')

# ---------------- 1.14: perfis de camadas e prévia por camada ----------------
@app.get('/api/layer_profiles')
def layer_profiles_list():
    from . import layer_profiles as LP
    return {'profiles':LP.load(store.ROOT),'roles':LP.ROLE_LABELS}

@app.post('/api/layer_profiles')
async def layer_profiles_save(request:Request):
    from . import layer_profiles as LP
    try:body=await request.json()
    except Exception:raise HTTPException(422,'Envie o perfil em JSON.')
    try:return LP.save(store.ROOT,body)
    except ValueError as e:raise HTTPException(422,str(e))

@app.delete('/api/layer_profiles/{name}')
def layer_profiles_delete(name:str):
    from . import layer_profiles as LP
    if not LP.delete(store.ROOT,name):raise HTTPException(404,'Perfil não encontrado (o perfil padrão não pode ser excluído).')
    return {'ok':True}

@app.post('/api/projects/{pid}/layer_profiles/apply')
async def layer_profiles_apply(pid,request:Request):
    from . import layer_profiles as LP
    d=store.directory(pid);a=d/'analysis.json'
    if not a.exists():raise HTTPException(409,'Analise os arquivos para listar as camadas do DXF.')
    body=await request.json();name=body.get('name');prof=next((p for p in LP.load(store.ROOT) if p['name']==name),None)
    if prof is None:raise HTTPException(404,'Perfil não encontrado.')
    layers=[l['name'] for l in json.loads(a.read_text(encoding='utf-8'))['layers']]
    mapping=LP.apply(layers,prof)
    return {'layers':mapping,'matched':sum(len(v) for v in mapping.values()),'total':len(layers)}

@app.get('/api/projects/{pid}/layers_preview.json')
def project_layers_preview(pid):
    f=store.directory(pid)/'camadas_previa.json'
    if not f.exists():raise HTTPException(404,'Analise os arquivos para gerar a prévia das camadas.')
    return FileResponse(f,media_type='application/json',headers={'Cache-Control':'no-store'})
