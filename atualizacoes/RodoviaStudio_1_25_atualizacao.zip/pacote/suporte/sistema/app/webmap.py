"""Editor sobre imagem web (1.9): ladrilhos Esri World Imagery com cache local e vetores simplificados.

O navegador trabalha em Web Mercator (como os ladrilhos). A conversão entre o CRS do projeto e
Web Mercator usa polinômios de 3º grau ajustados pelo pyproj na área do projeto (erro informado,
tipicamente milimétrico), para que o editor siga gravando tudo no CRS do projeto.
"""
import json,urllib.request,threading
from pathlib import Path
import numpy as np
from pyproj import CRS,Transformer
from shapely.geometry import LineString,Polygon

ESRI='https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}'
ATTRIBUTION='Esri, Maxar, Earthstar Geographics e GIS User Community'
R0=.25  # metros Web Mercator por pixel do "espaço de imagem" do editor
_lock=threading.Lock()

def _terms(u,v):
    return np.column_stack([np.ones_like(u),u,v,u*u,u*v,v*v,u**3,u*u*v,u*v*v,v**3])

def fit(crs,bounds,margin=.35,n=25):
    """Polinômios CRS<->Web Mercator na área (com margem). Retorna coeficientes e erros máximos (m)."""
    (x0,y0),(x1,y1)=bounds;w=max(x1-x0,50);h=max(y1-y0,50);x0-=w*margin;x1+=w*margin;y0-=h*margin;y1+=h*margin
    tr=Transformer.from_crs(CRS.from_user_input(crs),3857,always_xy=True)
    X,Y=np.meshgrid(np.linspace(x0,x1,n),np.linspace(y0,y1,n));X=X.ravel();Y=Y.ravel();MX,MY=tr.transform(X,Y);MX=np.asarray(MX);MY=np.asarray(MY)
    c=[(x0+x1)/2,(y0+y1)/2];s=[(x1-x0)/2,(y1-y0)/2];mc=[MX.mean(),MY.mean()];ms=[np.ptp(MX)/2,np.ptp(MY)/2]
    A=_terms((X-c[0])/s[0],(Y-c[1])/s[1]);B=_terms((MX-mc[0])/ms[0],(MY-mc[1])/ms[1])
    fx=np.linalg.lstsq(A,MX,rcond=None)[0];fy=np.linalg.lstsq(A,MY,rcond=None)[0];ix=np.linalg.lstsq(B,X,rcond=None)[0];iy=np.linalg.lstsq(B,Y,rcond=None)[0]
    # Erro em pontos fora da grade de ajuste.
    rng=np.random.default_rng(0);TX=rng.uniform(x0,x1,400);TY=rng.uniform(y0,y1,400);TMX,TMY=tr.transform(TX,TY)
    at=_terms((TX-c[0])/s[0],(TY-c[1])/s[1]);ef=float(np.max(np.hypot(at@fx-TMX,at@fy-TMY)))
    bt=_terms((np.asarray(TMX)-mc[0])/ms[0],(np.asarray(TMY)-mc[1])/ms[1]);ei=float(np.max(np.hypot(bt@ix-TX,bt@iy-TY)))
    # Fator de escala Mercator/CRS no centro (para converter metros do terreno em pixels).
    d=1.;cx,cy=tr.transform([c[0],c[0]+d],[c[1],c[1]]);k=float(np.hypot(cx[1]-cx[0],cy[1]-cy[0])/d)
    mx0,my1=tr.transform(x0,y1);mx1,my0=tr.transform(x1,y0)
    m0x=float(min(mx0,mx1));m0y=float(max(my0,my1))
    return {'crs':crs,'c':c,'s':s,'mc':mc,'ms':ms,'fx':fx.tolist(),'fy':fy.tolist(),'ix':ix.tolist(),'iy':iy.tolist(),'err_fwd_m':ef,'err_inv_m':ei,
            'k':k,'R0':R0,'m0x':m0x,'m0y':m0y,'img_w':float(abs(mx1-mx0)/R0),'img_h':float(abs(my1-my0)/R0),'mpp_crs':R0/k,'attribution':ATTRIBUTION,
            'bounds_padded':[x0,y0,x1,y1]}

def to_merc(g,x,y):
    a=_terms((np.asarray(x,float)-g['c'][0])/g['s'][0],(np.asarray(y,float)-g['c'][1])/g['s'][1]);return a@np.array(g['fx']),a@np.array(g['fy'])

def to_crs(g,mx,my):
    b=_terms((np.asarray(mx,float)-g['mc'][0])/g['ms'][0],(np.asarray(my,float)-g['mc'][1])/g['ms'][1]);return b@np.array(g['ix']),b@np.array(g['iy'])

# ---------------- 1.19: outras fontes web (Esri Wayback por data, XYZ ou WMS indicados pelo usuário) ----------------
WAYBACK_CONFIG='https://s3-us-west-2.amazonaws.com/config.maptiles.arcgis.com/waybackconfig.json'
WAYBACK_TILE='https://wayback.maptiles.arcgis.com/arcgis/rest/services/World_Imagery/WMTS/1.0.0/default028mm/MapServer/tile/{release}/{z}/{y}/{x}'
MERC_HALF=20037508.342789244

class WebSource:
    """Fonte de ladrilhos Web Mercator 256 px. 'esri' é a de sempre (mesmo cache e mesma URL)."""
    def __init__(self,kind='esri',url='',release=None,layers='',max_zoom=19,attribution='',label=''):
        import hashlib
        self.kind=kind;self.url=url;self.release=release;self.layers=layers;self.max_zoom=int(max_zoom);self.label=label
        if kind=='esri':self.cache='esri';self.attribution=ATTRIBUTION;self.max_zoom=min(self.max_zoom,19)
        elif kind=='wayback':
            if not release:raise ValueError('Escolha a data (versão) da Esri Wayback.')
            self.cache=f'wayback_{int(release)}';self.attribution='Esri World Imagery Wayback'+(f' ({label})' if label else '')
            if not url:self.url=WAYBACK_TILE.replace('{release}',str(int(release)))
        elif kind in ('xyz','wms','qms'):
            u=(url or '').strip()
            if not u.lower().startswith(('http://','https://')):raise ValueError('Informe o endereço (http/https) do serviço de imagens.')
            if kind=='xyz' and not all(t in u for t in ('{z}','{x}')) :raise ValueError('O endereço XYZ precisa conter {z}, {x} e {y} (ou {-y}).')
            self.url=u;self.cache=kind+'_'+hashlib.sha256((u+'|'+layers).encode()).hexdigest()[:12];self.attribution=attribution or 'Fonte indicada pelo usuário'
        else:raise ValueError('Fonte de imagem web desconhecida.')
    @property
    def key(self):return self.cache
    def tile_url(self,z,y,x):
        if self.kind=='esri':return ESRI.format(z=z,y=y,x=x)
        if self.kind=='wms':
            import urllib.parse
            size=2*MERC_HALF/2**z;x0=-MERC_HALF+x*size;y1=MERC_HALF-y*size
            q={'SERVICE':'WMS','REQUEST':'GetMap','VERSION':'1.3.0','LAYERS':self.layers,'STYLES':'','CRS':'EPSG:3857','BBOX':f'{x0},{y1-size},{x0+size},{y1}','WIDTH':256,'HEIGHT':256,'FORMAT':'image/jpeg'}
            return self.url+('&' if '?' in self.url else '?')+urllib.parse.urlencode(q)
        u=self.url
        q=''.join(str(((x>>i)&1)+2*((y>>i)&1)) for i in range(z-1,-1,-1))
        u=u.replace('{q}',q)
        for k,v in (('{z}',z),('{x}',x),('{y}',y),('{-y}',2**z-1-y),('{level}',z),('{row}',y),('{col}',x)):u=u.replace(k,str(v))
        return u.replace('{s}','a')

def web_source(settings):
    """Fonte configurada no projeto (padrão: Esri atual, como antes)."""
    w=getattr(settings,'web_imagery',None)
    if w is None or w.source=='esri':return WebSource('esri')
    src=WebSource(w.source,w.url if w.source!='wayback' else '',w.wayback_release,w.wms_layers,w.max_zoom,w.attribution,w.wayback_label)
    src.min_zoom=w.min_zoom
    if w.source=='qms':
        import hashlib
        src.cache='qms_'+str(w.qms_id)+'_'+hashlib.sha256(w.url.encode()).hexdigest()[:12]
    return src

def wayback_releases(cache_root,fetch=None,timeout=15,max_age_s=86400):
    """Lista de versões (datas) da Esri Wayback, da mais nova para a mais antiga; guarda cópia local."""
    import time,re
    f=Path(cache_root)/'wayback_config.json'
    data=None
    if f.exists() and time.time()-f.stat().st_mtime<max_age_s:data=f.read_bytes()
    if data is None:
        try:
            if fetch:data=fetch(WAYBACK_CONFIG)
            else:
                req=urllib.request.Request(WAYBACK_CONFIG,headers={'User-Agent':'RodoviaStudio/1.19'})
                with urllib.request.urlopen(req,timeout=timeout) as r:data=r.read()
            json.loads(data);f.parent.mkdir(parents=True,exist_ok=True);tmp=f.with_suffix('.tmp');tmp.write_bytes(data);tmp.replace(f)
        except Exception:
            if f.exists():data=f.read_bytes()
            else:raise
    cfg=json.loads(data);out=[]
    for k,v in cfg.items():
        try:r=int(k)
        except ValueError:continue
        t=str(v.get('itemTitle','')) if isinstance(v,dict) else '';m=re.search(r'(\d{4}-\d{2}-\d{2})',t)
        out.append({'release':r,'date':m.group(1) if m else '','title':t})
    out.sort(key=lambda d:(d['date'],d['release']),reverse=True);return out

def tile(cache_root,z,y,x,fetch=None,timeout=12,source=None):
    """Ladrilho JPEG/PNG da fonte web com cache em disco (funciona sem internet para áreas já vistas)."""
    src=source or WebSource('esri')
    if not(0<=z<=min(23,max(20,src.max_zoom)) and 0<=x<2**z and 0<=y<2**z):raise ValueError('Ladrilho fora do intervalo.')
    if src.kind=='qms' and not getattr(src,'min_zoom',0)<=z<=src.max_zoom:raise ValueError('Zoom fora do intervalo do serviço QMS.')
    f=Path(cache_root)/src.cache/str(z)/str(y)/f'{x}.jpg'
    if f.exists():return f.read_bytes()
    if fetch:data=fetch(z,y,x)
    else:
        req=urllib.request.Request(src.tile_url(z,y,x),headers={'User-Agent':'RodoviaStudio/1.9'})
        with urllib.request.urlopen(req,timeout=timeout) as r:data=r.read()
    if not data[:3]==b'\xff\xd8\xff' and not data[:8]==b'\x89PNG\r\n\x1a\n':raise ValueError('Resposta de ladrilho inválida.')
    with _lock:
        f.parent.mkdir(parents=True,exist_ok=True);tmp=f.with_suffix('.tmp');tmp.write_bytes(data);tmp.replace(f)
    return data

STYLE_ORDER=['water','cut','fill','existing_pavement','pavement','shoulder','median','barrier','oae','edge_line','sign_h','domain','axis','overlay']

def vectors(items,axis,kmz_lines=(),tol=.25):
    """Contornos simplificados por classe (CRS do projeto), para desenhar rápido sobre a imagem web."""
    out={r:[] for r in STYLE_ORDER};count=0
    for e in items:
        role=e['role'];role=role if role in out else 'overlay'
        if len(e['points'])==1 and e.get('entity_id'):
            out[role].append({'p':np.round(e['points'],2).tolist(),'c':False,'entity_id':e['entity_id'],'layer':e.get('layer','')});count+=1
            continue
        rings=[e['points']]+list(e.get('holes',[]))
        for r in rings:
            r=np.asarray(r)
            if len(r)<2:continue
            g=LineString(r).simplify(tol,preserve_topology=False)
            p=np.round(np.asarray(g.coords),2)
            if len(p)>=2:
                rec={'p':p.tolist(),'c':bool(e.get('closed')),'entity_id':e.get('entity_id',''),'layer':e.get('layer','')}
                if role=='overlay' and e.get('style'):rec['color']=e['style']['color']
                out[role].append(rec);count+=len(p)
    out['kmz']=[{'p':np.round(np.asarray(LineString(l).simplify(tol).coords),2).tolist(),'c':False} for l in kmz_lines if len(l)>=2]
    a=np.asarray(axis);ds=np.r_[0,np.cumsum(np.linalg.norm(np.diff(a,axis=0),axis=1))]
    ss=np.arange(0,ds[-1],2.);ax=np.column_stack([np.interp(ss,ds,a[:,0]),np.interp(ss,ds,a[:,1])]);ax=np.vstack([ax,a[-1:]])
    return {'layers':out,'axis_main':np.round(ax,3).tolist(),'points':count}

def write_vectors(directory,items,axis,crs):
    from .geometry import read_kmz
    kmz=Path(directory)/'input.kmz'
    lines=read_kmz(kmz,CRS.from_user_input(crs))[0] if kmz.exists() else []
    data=vectors(items,axis,lines)
    f=Path(directory)/'vectors.json';tmp=f.with_suffix('.tmp');tmp.write_text(json.dumps(data,separators=(',',':')),encoding='utf-8');tmp.replace(f)
    return data
