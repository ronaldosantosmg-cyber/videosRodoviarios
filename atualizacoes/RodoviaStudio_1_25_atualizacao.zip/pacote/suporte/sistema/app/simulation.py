"""1.12: tráfego simulado sem colisões (modelo de seguimento IDM), com engarrafamento, interdições e desvios.

Os veículos seguem os itinerários validados da rede (arestas + conectores). Cada trecho físico é
compartilhado por todos os itinerários que passam por ele, então o veículo de trás sempre "vê" o da
frente, mesmo vindo de outra origem. Nas convergências, quem vem da via principal tem prioridade e o
ramo cede passagem (sem sobreposição). A simulação é calculada uma vez, antes da montagem, com passo de
0,2 s e aquecimento de 90 s, e o quadro t só interpola posições: o resultado é idêntico em qualquer
número de processos.

Limitações: uma trajetória por sentido em cada pista (sem troca de faixa); ilustrativo, não é um
modelo de tráfego calibrado.
"""
import math,bisect,collections
import numpy as np
from shapely.geometry import Polygon,Point,LineString
from shapely import contains_xy

DT=.2
WARMUP=90.
IDM={'a':1.2,'b':2.0,'s0':2.5,'T':1.4}
SPEED_FACTOR={'car':1.0,'truck':.82,'bus':.88}

def _xy(p):return (p.x,p.y) if hasattr(p,'x') else (p['x'],p['y'])

class Block:
    def __init__(self,b):
        self.poly=Polygon([_xy(v) for v in b.points]).buffer(0);self.mode=b.mode;self.speed=max(1.,b.speed_kmh/3.6)
        self.start=float(b.start_s or 0);self.end=float(b.end_s) if b.end_s is not None else math.inf;self.name=b.name
    def active(self,t):return self.start<=t<self.end

class TrafficSim:
    def __init__(self,network,settings,vtype,duration=None,status=lambda *a:None,exit_visible=None):
        self.net=network;s=settings;self.s=s
        self.v0=s.traffic_speed_kmh/3.6;self.density=float(getattr(s,'traffic_density',1.))
        self.duration=float(duration if duration is not None else s.duration_s)
        self.paths=network.paths;self.vtype=vtype
        self.exit_visible=exit_visible;self._exit_cache={}
        self.blocks=[Block(b) for b in getattr(s,'lane_blocks',[]) if len(b.points)>=3]
        self.prepare()
        self.run(status)
    # ---------- preparação ----------
    def prepare(self):
        P=self.paths;self.link_of=[];self.starts=[]
        for i,path in enumerate(P):
            links=path.get('links') or [(('e',-1-i),0.,float(path['length']))]
            # Converte as fronteiras do polígono original para a distância reamostrada (proporção do comprimento).
            total=links[-1][2] or 1.;k=float(path['length'])/total
            L=[(lid,a*k,b*k) for lid,a,b in links];L[0]=(L[0][0],0.,L[0][2]);L[-1]=(L[-1][0],L[-1][1],float(path['length']))
            self.link_of.append(L);self.starts.append([a for _,a,_ in L])
        # Entradas: primeiro trecho; prioridade das convergências: via principal.
        kinds={}
        for i,path in enumerate(P):
            for lid,a,b in self.link_of[i]:
                if lid[0]=='e':kinds[lid]=self.net.edges[lid[1]]['kind'] if lid[1]>=0 else 'main'
        self.kind=kinds
        self.feeders=collections.defaultdict(set)  # trecho -> trechos que entram nele
        for L in self.link_of:
            for (a,_,_),(b,_,_) in zip(L[:-1],L[1:]):self.feeders[b].add(a)
        # Interdições: intervalo [a,b] (distância no itinerário) de cada bloqueio.
        self.zones=[]
        for i,path in enumerate(P):
            zs=[]
            for bi,bl in enumerate(self.blocks):
                inside=contains_xy(bl.poly,path['p'][:,0],path['p'][:,1])
                if inside.any():
                    idx=np.flatnonzero(inside);zs.append((bi,float(path['d'][idx[0]]),float(path['d'][idx[-1]])))
            self.zones.append(zs)
        # Desvios: itinerários com a mesma entrada que não passam pela interdição total.
        self.entry=[L[0][0] for L in self.link_of]
        by_entry=collections.defaultdict(list)
        for i,e in enumerate(self.entry):by_entry[e].append(i)
        self.siblings=by_entry
        # Demanda por itinerário (equivalente ao modelo anterior com densidade 1).
        self.rate=[]
        for path in P:
            L=float(path['length']);count=max(1,min(16,int(L/350)));self.rate.append(self.density*count/(L/self.v0+5))
    def blocked_total(self,i,t):
        return any(self.blocks[bi].mode=='total' and self.blocks[bi].active(t) for bi,_,_ in self.zones[i])
    def choose_path(self,i,t,rng):
        if not self.blocked_total(i,t):return i
        alt=[j for j in self.siblings[self.entry[i]] if j!=i and not self.blocked_total(j,t)]
        return int(alt[rng.integers(len(alt))]) if alt else i
    # ---------- simulação ----------
    def run(self,status):
        rng=np.random.default_rng(1729);n=len(self.paths)
        t0=-WARMUP;steps=int(math.ceil((self.duration-t0)/DT))+2
        nextspawn=[t0+rng.exponential(1/max(r,1e-6)) if r>0 else math.inf for r in self.rate]
        pending=[0]*n
        V=[]  # veículos vivos: dict
        self.track={}  # id -> listas (passo, s)
        self.info={}   # id -> (path,type,identity)
        frames=[]      # por passo: arrays (ids, s)
        vid=0;first=int(round(-t0/DT))
        self.collisions=0;self.min_gap=math.inf;self.max_queue=0;self.rerouted=0;self.spawned=0
        for k in range(steps):
            t=t0+k*DT
            # Chegadas (respeitando a ocupação da entrada).
            for i in range(n):
                while nextspawn[i]<=t:pending[i]+=1;nextspawn[i]+=rng.exponential(1/self.rate[i])
            occ=self.occupancy(V)
            for i in range(n):
                if not pending[i]:continue
                j=self.choose_path(i,t,rng)
                if j!=i:self.rerouted+=1
                ident=(j,vid,0);vt=self.vtype(self.paths[j]['kinds'],ident);Lv=_LEN[vt]
                v0=self.v0*SPEED_FACTOR[vt]*(.92+.16*rng.random())
                new={'id':vid,'p':j,'s':0.,'v':0.,'L':Lv,'v0':v0,'t':vt,'li':0}
                gap,vl=self.leader(new,occ)
                behind=[o for o,w in occ.get(self.link_of[j][0][0],[]) if o<Lv+IDM['s0']]
                if gap<IDM['s0']+1 or behind:continue
                # Entra com velocidade segura para a distância livre à frente.
                new['v']=min(.9*v0,math.sqrt(max(0.,2*IDM['b']*(gap-IDM['s0'])))+vl*.5) if gap<math.inf else .9*v0
                V.append(new)
                self.info[vid]=(j,vt,ident);vid+=1;pending[i]-=1;self.spawned+=1
                occ=self.occupancy(V)
            self.max_queue=max(self.max_queue,sum(pending))
            # Acelerações (todas calculadas antes de mover: atualização simultânea).
            acc=[self.accel(v,occ,t) for v in V]
            alive=[]
            for v,a in zip(V,acc):
                nv=max(0.,v['v']+a*DT);ds=max(0.,(v['v']+nv)/2*DT);v['v']=nv;v['s']+=ds
                if v['s']<self.paths[v['p']]['length']-.5:alive.append(v)
            V=alive
            if k>=first:
                frames.append((np.array([v['id'] for v in V],np.int32),np.array([v['s'] for v in V],np.float32),np.array([v['p'] for v in V],np.int32)))
                self.check(V)
            if k%250==0:status(.22+.03*k/steps,f'Simulando tráfego: {max(0.,t):.0f}/{self.duration:.0f} s')
        self.frames=frames;self.t_first=t0+first*DT
        # Rendering consults the precomputed tracks only; don't pickle a bound Scene callback.
        self.exit_visible=None;self._exit_cache.clear()
    def occupancy(self,V):
        occ=collections.defaultdict(list)
        for v in V:
            L=self.link_of[v['p']];st=self.starts[v['p']];j=bisect.bisect_right(st,v['s'])-1;lid,a,b=L[max(0,j)]
            v['li']=max(0,j);occ[lid].append((v['s']-a,v))
        for lst in occ.values():lst.sort(key=lambda x:x[0])
        return occ
    def leader(self,v,occ,look=150.):
        """Distância até a traseira do veículo da frente (no próprio trecho ou nos seguintes) e a velocidade dele."""
        L=self.link_of[v['p']];j=v['li'];off=v['s']-L[j][1];acc=0.
        for k in range(j,len(L)):
            lid,a,b=L[k]
            for o,w in occ.get(lid,[]):
                if w is v:continue
                if k==j:
                    if o>off+1e-6 or (abs(o-off)<=1e-6 and w['id']<v['id']):return o-off-(w['L']+v['L'])/2,w['v']
                else:return acc+o-(w['L']+v['L'])/2,w['v']
            acc+=(b-a)-(off if k==j else 0.)
            if acc>look:break
        return math.inf,0.
    def approach_priority(self,links,k):
        """Prioridade de quem chega ao trecho k pela aresta anterior (via principal > marginal > ramos)."""
        for m in range(k-1,-1,-1):
            if links[m][0][0]=='e':return self.priority(links[m][0])
        return 0
    def merge_conflict(self,v,occ,look=70.):
        """Convergências à frente (até 70 m): cede para quem vem da via principal; entre iguais, passa quem chega antes."""
        L=self.link_of[v['p']];j=v['li'];best=(math.inf,0.)
        for k in range(j+1,len(L)):
            nl=L[k][0];dist=L[k][1]-v['s']
            if dist>look:break
            feeders=self.feeders.get(nl,())
            if len(feeders)<2:continue
            mine=self.approach_priority(L,k);own=L[k-1][0]
            cand=[]
            for f in feeders:
                if f==own:continue
                cand.extend(w for _,w in occ.get(f,[]))
                for g in self.feeders.get(f,()):cand.extend(w for _,w in occ.get(g,[]))
            for w in cand:
                if w is v:continue
                Lw=self.link_of[w['p']];idx=None
                for q in range(w['li'],min(len(Lw),w['li']+4)):
                    if Lw[q][0]==nl:idx=q;break
                if idx is None:continue
                dw=Lw[idx][1]-w['s']
                if dw>look or dw<-w['L']:continue
                other=self.approach_priority(Lw,idx)
                tv=dist/max(v['v'],.5);tw=max(dw,0.)/max(w['v'],.5)
                if other>mine or (other==mine and (tw<tv or (tw==tv and w['id']<v['id']))):
                    if other>mine and tw-tv>4.:continue
                    if dw<dist:gap,vl=dist-dw-(w['L']+v['L'])/2,w['v']
                    else:gap,vl=dist-v['L']/2-1.5,0.
                    if gap<best[0]:best=(gap,vl)
        return best
    def priority(self,lid):
        if lid[0]!='e':return 0
        return 2 if self.kind.get(lid)=='main' else 1 if self.kind.get(lid)=='marginal' else 0
    def accel(self,v,occ,t):
        v0=v['v0'];T=IDM['T'];s=v['s']
        for bi,a,b in self.zones[v['p']]:
            bl=self.blocks[bi]
            if not bl.active(t):continue
            if bl.mode=='partial' and a-40<=s<=b:v0=min(v0,bl.speed);T=2.4
            elif bl.mode=='total' and s<a:
                v['_stop']=a-2-v['L']/2-s
        gap,vl=self.leader(v,occ)
        # An incomplete route must not consume a visible vehicle. Queue at its end until
        # the camera moves past the exit; never invent roadway beyond the supplied DXF.
        if self.exit_visible is not None and t>=-8.:
            key=(v['p'],round(max(0.,t)/DT))
            if key not in self._exit_cache:
                self._exit_cache[key]=self.exit_visible(v['p'],max(0.,t)) or self.exit_visible(v['p'],max(0.,t)+8.)
            if self._exit_cache[key]:
                terminal=self.paths[v['p']]['length']-v['L']/2-2.-s
                if terminal<gap:gap,vl=terminal,0.
        stop=v.pop('_stop',math.inf)
        if stop<gap:gap,vl=stop,0.
        mg,mv=self.merge_conflict(v,occ)
        if mg<gap:gap,vl=mg,mv
        vv=v['v'];dv=vv-vl
        star=IDM['s0']+max(0.,vv*T+vv*dv/(2*math.sqrt(IDM['a']*IDM['b'])))
        free=1-(vv/max(v0,.1))**4
        a=IDM['a']*(free-(star/max(gap,.1))**2) if gap<math.inf else IDM['a']*free
        return max(-9.,min(IDM['a'],a))
    def check(self,V):
        occ=self.occupancy(V)
        for lst in occ.values():
            for (o1,w1),(o2,w2) in zip(lst[:-1],lst[1:]):
                g=o2-o1-(w1['L']+w2['L'])/2
                if g<self.min_gap:self.min_gap=g
                if g<0:
                    self.collisions+=1
                    if len(getattr(self,'_log',[]))<10:self.__dict__.setdefault('_log',[]).append((w1['p'],w2['p'],round(o1,1),round(o2,1),w1['li'],w2['li'],round(w1['v'],1),round(w2['v'],1)))
    # ---------- consulta por quadro ----------
    def state(self,t):
        if not self.frames:return []
        x=(t-self.t_first)/DT;k=int(np.clip(math.floor(x),0,len(self.frames)-1));f=float(np.clip(x-k,0,1))
        ids,ss,ps=self.frames[k]
        if k+1<len(self.frames) and f>0:
            ids2,ss2,_=self.frames[k+1];m=dict(zip(ids2.tolist(),ss2.tolist()))
            ss=np.array([s if i not in m else s+(m[i]-s)*f for i,s in zip(ids.tolist(),ss.tolist())],np.float32)
        return list(zip(ids.tolist(),ps.tolist(),ss.tolist()))
    def vehicles_ex(self,t,speed=None):
        from .traffic import path_pose
        for vid,i,s in self.state(t):
            pt,tan,j=path_pose(self.paths[i],s)
            yield pt,tan,vid,self.info[vid][2],j
    def report(self):
        return {'model':'simulado','vehicles':self.spawned,'rear_collisions':self.collisions,'min_gap_m':None if self.min_gap==math.inf else round(self.min_gap,2),
                'max_waiting_at_entries':self.max_queue,'rerouted':self.rerouted,'blocks':len(self.blocks),'density':self.density}

from .visual import TYPES as _T
_LEN={k:v['L'] for k,v in _T.items()}
