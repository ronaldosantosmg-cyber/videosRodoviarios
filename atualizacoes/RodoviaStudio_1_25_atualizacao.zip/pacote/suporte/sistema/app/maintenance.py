"""Remove apenas caches regeneráveis e saídas temporárias interrompidas."""
import shutil
from pathlib import Path

CACHE_DIRS={'cache_geometria','imagery','hidrografia','render_tmp','cache_detalhe'}
TEMP_FILES={'video.partial.mp4','upload.dxf.tmp','upload.kmz.tmp'}

def candidates(root):
    root=Path(root).resolve()
    if (root/'_ladrilhos').is_dir():yield root/'_ladrilhos'
    for project in root.iterdir() if root.exists() else []:
        if project.name=='_ladrilhos':continue
        if project.is_symlink() or not project.is_dir():continue
        for p in project.iterdir():
            if p.is_symlink():continue
            if p.name in CACHE_DIRS and p.is_dir():yield p
            elif p.name in TEMP_FILES and p.is_file():yield p

def size(path):
    if path.is_file():return path.stat().st_size
    return sum(p.stat().st_size for p in path.rglob('*') if p.is_file() and not p.is_symlink())

def clean(root,execute=False):
    total=0;count=0;errors=[]
    for p in candidates(root):
        try:
            n=size(p)
            if execute:
                if p.is_dir():shutil.rmtree(p)
                else:p.unlink()
            total+=n;count+=1
        except OSError as exc:errors.append(p.name+': '+str(exc))
    return {'bytes':total,'items':count,'executed':execute,'errors':errors}
