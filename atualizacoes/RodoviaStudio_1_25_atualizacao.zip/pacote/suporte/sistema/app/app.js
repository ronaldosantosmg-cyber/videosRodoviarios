'use strict';
/* Rodovia Studio — interface local. Editor da prévia (1.3): zoom/arraste, ferramentas de marcação,
   desfazer/refazer. Todas as marcações são gravadas na configuração em coordenadas do CRS. */
const $=id=>document.getElementById(id);
let pid='',cfg={},analysis=null,meta=null,task='',baseImage=null,editingPoi=null,lastRender=null,editor=null,alignResult=null;
let commandRevision=0,multiSel=[],nativeSel=null,layerCatalog=null,sel=null,snapMark=null,lastPick=null,cadCmd=null,snapIndex=null;
const canvas=$('canvas'),ctx=canvas.getContext('2d');
const roles={axis:'Eixo',pavement:'Pista projetada',existing_pavement:'Pista existente',shoulder:'Acostamento',edge_line:'Bordo (linha de borda)',median:'Canteiro',barrier:'Barreira',oae:'OAE',cut:'Corte',fill:'Aterro',earthwork:'Talude (corte/aterro pela proximidade)',domain:'Faixa de domínio',water:'Hidrografia',sign_h:'Sinalização horizontal',sign_v:'Sinalização vertical'};
const ROLE_COLOR={edge_line:'#f4f2e2',water:'#2a80b9',existing_pavement:'#a4a8a9',pavement:'#454c4e',shoulder:'#858983',median:'#7f9b6e',barrier:'#e0ddd2',oae:'#b9bcb7',cut:'#df6262',fill:'#53bb77',domain:'#ffd56b'};
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const uid=()=>(crypto.randomUUID?crypto.randomUUID():Date.now().toString(36)+Math.random().toString(36).slice(2));
function msg(s,error=false){$('message').textContent=s;$('message').classList.toggle('error',error)}
async function api(url,opt={}){const r=await fetch(url,opt);if(!r.ok){let e;try{e=await r.json()}catch{throw Error('Falha HTTP '+r.status)}throw Error(typeof e.detail==='string'?e.detail:JSON.stringify(e.detail))}return r.json()}
const json=(method,body)=>({method,headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
function guard(fn){return async(...a)=>{try{await fn(...a)}catch(e){msg(e.message,true)}}}
function requireProject(){if(!pid)throw Error('Crie ou abra um projeto primeiro.')}
function parseKm(s){s=String(s).trim();if(s.includes('+')){const a=s.split('+');if(a.length!==2||!/^-?\d+$/.test(a[0])||!/^\d{1,3}$/.test(a[1]))throw Error('Km inválido: '+s);return Number(a[0])*1000+(a[0].startsWith('-')?-1:1)*Number(a[1])}const v=Number(s.replace(',','.'));if(!Number.isFinite(v))throw Error('Km inválido: '+s);return v*1000}
function formatKm(m){if(m==null||!Number.isFinite(m))return '';const neg=m<0;const v=Math.round(Math.abs(m));return (neg?'-':'')+Math.floor(v/1000)+'+'+String(v%1000).padStart(3,'0')}

/* ---------- Estado das marcações + histórico ---------- */
const MARK_KEYS=['excluded_signs','excluded_entities','custom_axis','pavement_areas','shoulder_marks','pois','exclusions','traffic_paths','chainage','dxf_alignment','direction_marks','flow_overrides','oae_marks','no_connection_zones','cabin','highlights','clean_areas','cities','lane_blocks','crossing_zones','crosswalks','hatch_areas','signs','lane_zones','accesses','lane_ranges'];
let M=emptyMarks(),undoStack=[],redoStack=[];
function emptyMarks(){return {excluded_signs:[],excluded_entities:[],custom_axis:null,pavement_areas:[],shoulder_marks:[],lane_ranges:[],accesses:[],crosswalks:[],hatch_areas:[],signs:[],lane_zones:[],lane_blocks:[],crossing_zones:[],clean_areas:[],cities:[],highlights:[],pois:[],exclusions:[],traffic_paths:[],chainage:{mode:'auto',start:null,end:null,direction:1,calibrate:false},dxf_alignment:{mode:'translation',pairs:[],applied:false},direction_marks:[],flow_overrides:[],oae_marks:[],no_connection_zones:[],cabin:{enabled:false,start:null,duration_s:20,eye_height_m:1.25,fov_deg:72,pitch_deg:4,smoothing_s:1.2,speed_kmh:null,hood:true}}}
function checkpoint(){undoStack.push(JSON.stringify(M));if(undoStack.length>200)undoStack.shift();redoStack=[];updateUndo()}
function changed(text){refreshLists();draw();scheduleSave();if(text)msg(text)}
function undo(){if(!undoStack.length)return;redoStack.push(JSON.stringify(M));M=JSON.parse(undoStack.pop());draft=null;selected=null;sel=null;multiSel=[];nativeSel=null;showProps();buildVectorPaths();changed('Desfeito.');updateUndo()}
function redo(){if(!redoStack.length)return;undoStack.push(JSON.stringify(M));M=JSON.parse(redoStack.pop());draft=null;sel=null;multiSel=[];nativeSel=null;showProps();buildVectorPaths();changed('Refeito.');updateUndo()}
function updateUndo(){$('undo').disabled=!undoStack.length;$('redo').disabled=!redoStack.length}
let saveTimer=null;
let savePending=false;
function scheduleSave(){if(!pid)return;savePending=true;$('saveState').textContent='alterações não salvas…';clearTimeout(saveTimer);saveTimer=setTimeout(async()=>{try{await save();savePending=false;$('saveState').textContent='salvo na configuração'}catch(e){$('saveState').textContent='não salvo: '+e.message;msg('A alteração NÃO foi salva: '+e.message+' Corrija o valor ou use Desfazer.',true)}},900)}

/* ---------- Configuração ---------- */
const fields=['export_start_s','export_end_s','name','origin','destination','work_year','crs','units_to_m','imagery','width','fps','duration_s','view_width_m','imagery_pixels','traffic_speed_kmh','preview_mode','preview_time_s','encoder','cpu_preset','short_video_mode','visual_quality','water_texture_opacity','water_names_opacity','render_workers','render_profile','signage_style','flow_arrows','flow_arrow_spacing_m','cities_radius_km','imagery_detail','traffic_model','traffic_density','median_crossing','day_night','night_start_s','night_transition_s','night_darkness','signage_detail','lane_width_m','dxf_signage','texture_style','earthwork_look','detail_resolution_m','lane_arrow_repeat','arrow_min_gap_m','layer_split','lanes_per_direction','style_profile','camera_mode','vehicle_paths','direction_reference','pavement_material','existing_material','shoulder_material','joint_spacing_m','project_contrast'];
const numeric=['export_start_s','export_end_s','units_to_m','width','fps','duration_s','view_width_m','imagery_pixels','traffic_speed_kmh','preview_time_s','water_texture_opacity','water_names_opacity','render_workers','flow_arrow_spacing_m','cities_radius_km','traffic_density','night_start_s','night_transition_s','night_darkness','lane_width_m','detail_resolution_m','arrow_min_gap_m','lanes_per_direction','joint_spacing_m','project_contrast'];
const checks=['keep_vehicles_visible','reverse_axis','coordinates_confirmed','traffic','hydrography','traffic_network_preview','water_texture','water_names','water_animated','headlights','km_markers','direction_badge','median_grass','cities_show','detail_textures','night_signage_glow','auto_earthworks','lane_arrows','gore_hatch','stop_lines','auto_signs','progress_indicator','technical_textures'];
function fill(s){cfg=s;for(const k of fields){const el=$(k);if(el)el.value=s[k]??({encoder:'auto',cpu_preset:'veryfast',preview_mode:'overview',preview_time_s:30,short_video_mode:'auto',visual_quality:'enhanced',water_texture_opacity:.65,water_names_opacity:1,render_workers:0,render_profile:'final',signage_style:'clean',flow_arrows:'km_conflicts',flow_arrow_spacing_m:1000,cities_radius_km:25,imagery_detail:'auto',traffic_model:'simulado',traffic_density:1,median_crossing:'returns',day_night:'off',night_start_s:40,night_transition_s:8,night_darkness:.78,signage_detail:'full',lane_width_m:3.5,dxf_signage:'replace',texture_style:'realistic',earthwork_look:'hatch',detail_resolution_m:.2,lane_arrow_repeat:'conflicts',arrow_min_gap_m:25,layer_split:'auto',lanes_per_direction:2,style_profile:'padrao',camera_mode:'obras',vehicle_paths:'smooth',direction_reference:'axis',pavement_material:'flexivel',existing_material:'flexivel',shoulder_material:'flexivel',joint_spacing_m:5,project_contrast:0}[k]??'')}
 for(const k of checks)if($(k))$(k).checked=s[k]??['keep_vehicles_visible','hydrography','water_texture','water_names','traffic','km_markers','direction_badge','median_grass','cities_show','detail_textures','night_signage_glow','auto_earthworks','lane_arrows','gore_hatch','stop_lines','auto_signs'].includes(k);$('km_start_m').value=formatKm(s.km_start_m);$('km_end_m').value=formatKm(s.km_end_m);$('reference_length_m').value=(s.reference_length_m/1000).toFixed(3).replace('.',',');
 M=emptyMarks();for(const k of MARK_KEYS)if(s[k]!==undefined)M[k]=JSON.parse(JSON.stringify(s[k]));undoStack=[];redoStack=[];updateUndo();
 $('preview_time_s').step=1/(s.fps||30);$('preview_time_s').max=s.duration_s||202;$('timeLabel').textContent=(s.preview_time_s??30)+' s';$('alignMode').value=M.dxf_alignment.mode;refreshLists()}
function collect(){let s={...cfg};for(const k of fields){const el=$(k);if(el)s[k]=k==='export_end_s'&&el.value===''?null:numeric.includes(k)?Number(el.value):el.value}for(const k of checks)if($(k))s[k]=$(k).checked;
 s.km_start_m=parseKm($('km_start_m').value);s.km_end_m=parseKm($('km_end_m').value);s.reference_length_m=Number($('reference_length_m').value.replace(',','.'))*1000;
 for(const k of MARK_KEYS)s[k]=JSON.parse(JSON.stringify(M[k]));M.dxf_alignment.mode=$('alignMode').value;s.dxf_alignment.mode=M.dxf_alignment.mode;
 s.layers={};s.ignored_layers=[];document.querySelectorAll('#layers select').forEach(el=>{if(el.value)(s.layers[el.value]??=[]).push(el.dataset.layer);else s.ignored_layers.push(el.dataset.layer)});if(!document.querySelector('#layers select')){s.layers=cfg.layers||{};s.ignored_layers=cfg.ignored_layers||[]}
 s.route_directions={...(cfg.route_directions||{})};document.querySelectorAll('#routes select').forEach(el=>s.route_directions[el.dataset.route]=el.value);return s}
async function save(){requireProject();const s=collect();await api('/api/projects/'+pid+'/config',json('PUT',s));cfg=s;savePending=false;announce({t:'saved'});$('configDownload').href='/api/projects/'+pid+'/config.json';$('configDownload').hidden=false}
async function list(){const rows=await api('/api/projects');$('projects').innerHTML='<option value="">Selecione…</option>'+rows.map(r=>`<option value="${r.id}">${esc(r.name)} · ${esc(r.created)}</option>`).join('');$('projects').value=pid}
function showLayers(){const catalog=analysis||layerCatalog;if(!catalog)return;$('layers').innerHTML=catalog.layers.map(l=>{let current=Object.entries(cfg.layers||{}).find(([k,v])=>v.includes(l.name))?.[0]||(!Object.keys(cfg.layers||{}).length&&!(cfg.ignored_layers||[]).includes(l.name)?l.suggested_role:'');return `<tr><td>${esc(l.name)}<br><small>${l.count} entidades</small></td><td><select data-layer="${esc(l.name)}"><option value="">Ignorar</option>${Object.entries(roles).map(([k,v])=>`<option value="${k}" ${k===current?'selected':''}>${v}</option>`).join('')}</select></td><td><button class="mini" data-showlayer="${esc(l.name)}" title="Destacar esta camada no editor">Ver</button></td></tr>`}).join('');showRoleColors();
 $('routes').innerHTML=(analysis?.routes||[]).map(r=>`<tr><td>Eixo ${r.id} · ${r.length_m.toFixed(1)} m<br>${esc(r.layer)}</td><td><select data-route="${r.id}">${[['auto','Automático'],['forward','Crescente (km)'],['reverse','Decrescente (km)'],['off','Sem veículos']].map(([k,v])=>`<option value="${k}" ${(cfg.route_directions||{})[r.id]===k?'selected':''}>${v}</option>`).join('')}</select></td></tr>`).join('');
 if(!analysis){filterLayers();return}$('warnings').textContent=(analysis.warnings||[]).join('\n');$('geom').textContent=`Comprimento geométrico: ${(analysis.geometric_length_m/1000).toFixed(3)} km. A extensão de referência permanece independente.`+(analysis.georef_check?` Conferência DXF × KMZ (${analysis.georef_check.points} pontos ao longo do eixo): desvio mediano ${analysis.georef_check.median_m.toFixed(2)} m, 95% até ${analysis.georef_check.p95_m.toFixed(2)} m, máximo ${analysis.georef_check.max_m.toFixed(2)} m.`:' Sem KMZ: a posição não foi conferida contra outra referência.')}
async function load(id){pid=id;localStorage.setItem('rodovia_project',pid);const r=await api('/api/projects/'+pid);fill(r.config);lastRender=r.render_info||null;analysis=r.analysis||null;meta=r.preview||null;
 $('fileState').textContent=`DXF: ${r.files.dxf?'carregado':'ausente'} · KMZ: ${r.files.kmz?'carregado':'ausente'}`;showLayers();$('projects').value=pid;$('configDownload').href='/api/projects/'+pid+'/config.json';$('configDownload').hidden=false;
 editor=null;if(r.editor_ready||meta)try{editor=await api('/api/projects/'+pid+'/editor.json')}catch{}
 const same=geoPid===pid;await loadGeo();
 if(meta)await loadImage(same&&useGeo());else{baseImage=null;if(!same||!ready())fitView();else draw()}refreshLists();baseUi()}
async function loadImage(keepView=false){if(!meta)return;const im=new Image();await new Promise((resolve,reject)=>{im.onload=resolve;im.onerror=()=>reject(Error('Não foi possível carregar a prévia.'));im.src='/api/projects/'+pid+'/preview.png?v='+Date.now()});baseImage=im;if(keepView)draw();else fitView();}

/* ---------- Vista: imagem <-> canvas <-> mundo ---------- */
let view={s:1,ox:0,oy:0};
function resizeCanvas(){const r=canvas.getBoundingClientRect(),d=window.devicePixelRatio||1;const w=Math.max(320,Math.round(r.width*d)),h=Math.max(180,Math.round(r.height*d));if(canvas.width!==w||canvas.height!==h){const k=w/canvas.width;canvas.width=w;canvas.height=h;view.s*=k;view.ox*=k;view.oy*=k}draw()}
function fitView(){if(!ready()){draw();return}let x0=0,y0=0,x1,y1;[x1,y1]=imgSize();
 if(useGeo()&&analysis?.bounds){const [[a,b],[c,d]]=analysis.bounds;const q=[[a,b],[c,b],[a,d],[c,d]].map(([x,y])=>worldToImg({x,y}));x0=Math.min(...q.map(v=>v[0]));x1=Math.max(...q.map(v=>v[0]));y0=Math.min(...q.map(v=>v[1]));y1=Math.max(...q.map(v=>v[1]));const m=.06*Math.max(x1-x0,y1-y0);x0-=m;x1+=m;y0-=m;y1+=m}
 const s=Math.min(canvas.width/(x1-x0),canvas.height/(y1-y0));view={s,ox:(canvas.width-(x1-x0)*s)/2-x0*s,oy:(canvas.height-(y1-y0)*s)/2-y0*s};draw()}
const mpp=()=>useGeo()?geo.mpp_crs:meta.width_m/meta.screen_width; // metros (CRS) por pixel do espaço de imagem
function worldToImg(p){if(useGeo()){const [mx,my]=toMerc(p.x,p.y);return [(mx-geo.m0x)/geo.R0,(geo.m0y-my)/geo.R0]}const dx=p.x-meta.camera[0],dy=p.y-meta.camera[1],m=mpp();return [(dx*meta.right[0]+dy*meta.right[1])/m+meta.screen_width/2,meta.screen_height/2-(dx*meta.up[0]+dy*meta.up[1])/m]}
function imgToWorld(x,y){if(useGeo()){const [X,Y]=toCrs(geo.m0x+x*geo.R0,geo.m0y-y*geo.R0);return {x:X,y:Y}}const m=mpp(),a=(x-meta.screen_width/2)*m,b=-(y-meta.screen_height/2)*m;return {x:meta.camera[0]+a*meta.right[0]+b*meta.up[0],y:meta.camera[1]+a*meta.right[1]+b*meta.up[1]}}
const W2C=p=>{const [x,y]=worldToImg(p);return [x*view.s+view.ox,y*view.s+view.oy]};
const C2W=(x,y)=>imgToWorld((x-view.ox)/view.s,(y-view.oy)/view.s);
const pxPerM=()=>view.s/mpp();
function evtCanvas(e){const r=canvas.getBoundingClientRect();return [(e.clientX-r.left)*canvas.width/r.width,(e.clientY-r.top)*canvas.height/r.height]}

/* ---------- 1.9: base de edição sobre imagem web (Esri) + vetores simplificados ---------- */
let localInfo=null,geo=null,vec=null,geoPid='',baseMode='map',vecPaths=null,tileState={ok:0,fail:0};
let directTiles=true;const ESRI_DIRECT=(z,y,x)=>`https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/${z}/${y}/${x}`;
const tiles=new Map(),TILE_MAX_Z=19,MERC=20037508.342789244;
const VSTYLE={water:['#4aa8ff',1.6,[],.25],edge_line:['#f4f2e2',1.2,[],0],cut:['#ff7a66',1.3,[],0],fill:['#86e08f',1.3,[],0],existing_pavement:['#d9d9d9',1.5,[],.10],pavement:['#ffffff',1.9,[],.14],shoulder:['#efe4b8',1.2,[],0],median:['#66e07a',1.5,[],.12],barrier:['#ffb347',1.7,[],0],oae:['#5ad8ff',2.2,[],.18],domain:['#ffe14d',1.4,[8,6],0],axis:['#ff4fd8',1.6,[10,6],0],overlay:['#c3b2ff',1.4,[],0],kmz:['#3fe0c5',2.2,[5,4],0]};
const VNAME={water:'Hidrografia (DXF)',edge_line:'Bordos (DXF)',pavement:'Pavimento',existing_pavement:'Pavimento existente',shoulder:'Acostamento',median:'Canteiro',barrier:'Barreira',oae:'OAE',cut:'Corte',fill:'Aterro',domain:'Faixa de domínio',axis:'Eixos',overlay:'DXF adicionais',kmz:'KMZ'};
const SIGN={signage:['Sinalização do vídeo','#f4f2e2'],arrows:['Setas de fluxo do vídeo','#ffffff'],flows:['Trajetórias e sentidos','#61e6d7']};
let vecOn={},vecAlpha=.9,tileAlpha=1;
try{const v=JSON.parse(localStorage.getItem('rodovia_base')||'{}');if(v.mode)baseMode=v.mode;if(v.on)vecOn=v.on;if(v.va!=null)vecAlpha=v.va;if(v.ta!=null)tileAlpha=v.ta}catch{}
function saveBasePrefs(){try{localStorage.setItem('rodovia_base',JSON.stringify({mode:baseMode,on:vecOn,va:vecAlpha,ta:tileAlpha}))}catch{}}
const useGeo=()=>!!geo&&(baseMode!=='preview'||!baseImage||!meta);
const ready=()=>useGeo()||!!(baseImage&&meta);
const imgSize=()=>useGeo()?[geo.img_w,geo.img_h]:[baseImage.width,baseImage.height];
function minScale(){if(!ready())return .05;const [w,h]=imgSize();return Math.min(.05,.25*Math.min(canvas.width/w,canvas.height/h))}
function T10(u,v){return [1,u,v,u*u,u*v,v*v,u*u*u,u*u*v,u*v*v,v*v*v]}
function dot10(t,c){let r=0;for(let i=0;i<10;i++)r+=t[i]*c[i];return r}
function toMerc(x,y){const t=T10((x-geo.c[0])/geo.s[0],(y-geo.c[1])/geo.s[1]);return [dot10(t,geo.fx),dot10(t,geo.fy)]}
function toCrs(mx,my){const t=T10((mx-geo.mc[0])/geo.ms[0],(my-geo.mc[1])/geo.ms[1]);return [dot10(t,geo.ix),dot10(t,geo.iy)]}
async function loadGeo(){const keep=geoPid===pid&&geo;geo=null;vec=null;vecPaths=null;axisCache=null;
 if(!analysis){geoPid=pid;return}
 try{geo=await api('/api/projects/'+pid+'/geo')}catch(e){geo=null;$('baseInfo')&&($('baseInfo').textContent='Imagem web indisponível: '+e.message)}
 if(geo){try{vec=await api('/api/projects/'+pid+'/vectors.json')}catch{vec=null}buildVectorPaths()}
 localInfo=null;localTiles.clear();if(geo&&cfg?.local_imagery?.image){try{localInfo=await api(`/api/projects/${pid}/local/info`)}catch{localInfo=null}}
 try{await localUi()}catch{}
 if(!keep&&geoPid!==pid)tileState={ok:0,fail:0};geoPid=pid}
function buildVectorPaths(){snapIndex=null;vecPaths={};if(!vec||!geo)return;const L=vec.layers||{};
 for(const [role,list] of Object.entries(L)){if(!list.length)continue;const path=new Path2D(),fill=new Path2D();let nf=0;
  for(const r of list){if((M.excluded_entities||[]).includes(r.entity_id))continue;r.p.forEach((q,i)=>{const [x,y]=worldToImg({x:q[0],y:q[1]});if(i){path.lineTo(x,y);if(r.c)fill.lineTo(x,y)}else{path.moveTo(x,y);if(r.c){fill.moveTo(x,y);nf++}}});if(r.c){path.closePath();fill.closePath()}}
  const col=role==='overlay'&&list[0].color?list[0].color:VSTYLE[role]?.[0];vecPaths[role]={path,fill:nf?fill:null,n:list.length,color:col};if(vecOn[role]===undefined)vecOn[role]=true}
 buildSignage()}
function buildSignage(){if(!vecPaths||!geo)return;delete vecPaths.signage;delete vecPaths.signage_y;delete vecPaths.arrows;if(!editor)return;
 const w={signage:new Path2D(),signage_y:new Path2D()};let n=0;
 for(const m of editor.markings||[]){const a=worldToImg({x:m[0],y:m[1]}),b=worldToImg({x:m[2],y:m[3]});const P=m[4]?w.signage_y:w.signage;P.moveTo(a[0],a[1]);P.lineTo(b[0],b[1]);n++}
 const ar=new Path2D();for(const a of editor.arrows||[]){const p={x:a[0],y:a[1]},t={x:a[2],y:a[3]},nn={x:-t.y,y:t.x};const pts=[[-2.4,0],[2.4,0],[.6,.9],[2.4,0],[.6,-.9]].map(([u,v])=>worldToImg({x:p.x+t.x*u+nn.x*v,y:p.y+t.y*u+nn.y*v}));ar.moveTo(...pts[0]);ar.lineTo(...pts[1]);ar.moveTo(...pts[2]);ar.lineTo(...pts[3]);ar.lineTo(...pts[4])}
 const pw=new Path2D(),py=new Path2D();for(const [yl,rings] of editor.paint||[]){const P=yl?py:pw;for(const r of rings){r.forEach((q,i)=>{const [x,y]=worldToImg({x:q[0],y:q[1]});i?P.lineTo(x,y):P.moveTo(x,y)});P.closePath()}}
 vecPaths.signage={path:w.signage,yellow:w.signage_y,paint:pw,paintY:py,n:n+(editor.paint||[]).length,color:'#f4f2e2'};vecPaths.arrows={path:ar,n:(editor.arrows||[]).length,color:'#ffffff'};
 for(const k of ['signage','arrows','flows'])if(vecOn[k]===undefined)vecOn[k]=true}
function tileKey(z,x,y){return webKey()+':'+z+'/'+x+'/'+y}
// 1.19: fonte web do projeto (Esri atual, Wayback por data, XYZ ou WMS).
const webSrc=()=>cfg?.web_imagery?.source||'esri';
const webKey=()=>{const w=cfg?.web_imagery||{};return w.source&&w.source!=='esri'?[w.source,w.qms_id||'',w.wayback_release||'',w.url||'',w.wms_layers||''].join('|'):'esri'};
const tileMaxZ=()=>webSrc()==='esri'?TILE_MAX_Z:Math.min(23,cfg.web_imagery.max_zoom||19);
let tileDrawPending=false;function tileRedraw(){if(tileDrawPending)return;tileDrawPending=true;requestAnimationFrame(()=>{tileDrawPending=false;draw()})}
function getTile(z,x,y){const k=tileKey(z,x,y);let t=tiles.get(k);if(t&&t.fail&&performance.now()-t.failAt>30000){tiles.delete(k);t=null}if(t){t.used=performance.now();return t}
 t={direct:webSrc()!=='esri',img:new Image(),ok:false,fail:false,used:performance.now()};t.img.decoding='async';t.img.onload=()=>{t.ok=true;tileState.ok++;tileRedraw()};t.img.onerror=()=>{if(!t.direct&&directTiles!==false){t.direct=true;t.img.src=ESRI_DIRECT(z,y,x);return}t.fail=true;t.failAt=performance.now();tileState.fail++;tileRedraw()};t.img.onload=()=>{t.ok=true;tileState.ok++;if(t.direct){tileState.direct=(tileState.direct||0)+1}tileRedraw()};t.img.src=webSrc()==='esri'?`/tiles/esri/${z}/${y}/${x}`:`/api/projects/${pid}/web_tiles/${z}/${y}/${x}?k=${encodeURIComponent(webKey())}`;if(webSrc()!=='esri')t.direct=true;tiles.set(k,t);
 if(tiles.size>700){const old=[...tiles.entries()].sort((a,b)=>a[1].used-b[1].used).slice(0,200);for(const [kk] of old)tiles.delete(kk)}return t}
/* 1.17: imagem local em ladrilhos Web Mercator (servidor local), por cima da Esri, até o zoom da resolução dela. */
const localTiles=new Map();
function getLocalTile(z,x,y){const k=z+'/'+x+'/'+y;let t=localTiles.get(k);if(t){t.used=performance.now();return t}
 t={direct:webSrc()!=='esri',img:new Image(),ok:false,empty:false,used:performance.now()};t.img.onload=()=>{t.ok=true;tileRedraw()};t.img.onerror=()=>{t.empty=true};
 fetch(`/api/projects/${pid}/local_tiles/${z}/${y}/${x}.png?k=${localInfo?.key||''}`).then(r=>{if(r.status===204){t.empty=true;return null}if(!r.ok){t.empty=true;return null}return r.blob()}).then(b=>{if(b)t.img.src=URL.createObjectURL(b)}).catch(()=>{t.empty=true});
 localTiles.set(k,t);if(localTiles.size>500){const old=[...localTiles.entries()].sort((a,b)=>a[1].used-b[1].used).slice(0,150);for(const [kk,v] of old){if(v.img.src.startsWith('blob:'))URL.revokeObjectURL(v.img.src);localTiles.delete(kk)}}return t}
function drawLocalTiles(){if(!localInfo||!localInfo.sources?.length||localInfo.editor===false||!geo)return;
 const res=geo.R0/view.s;const z=Math.max(10,Math.min(localInfo.max_zoom,Math.ceil(Math.log2(2*MERC/256/res)-.25))),n=2**z,size=2*MERC/n;
 const corners=[[0,0],[canvas.width,0],[0,canvas.height],[canvas.width,canvas.height]].map(([cx,cy])=>[geo.m0x+(cx-view.ox)/view.s*geo.R0,geo.m0y-(cy-view.oy)/view.s*geo.R0]);
 let mx0=Math.min(...corners.map(c=>c[0])),mx1=Math.max(...corners.map(c=>c[0])),my0=Math.min(...corners.map(c=>c[1])),my1=Math.max(...corners.map(c=>c[1]));
 const B=localInfo.sources.reduce((b,s)=>[Math.min(b[0],s.merc[0]),Math.min(b[1],s.merc[1]),Math.max(b[2],s.merc[2]),Math.max(b[3],s.merc[3])],[Infinity,Infinity,-Infinity,-Infinity]);
 mx0=Math.max(mx0,B[0]);my0=Math.max(my0,B[1]);mx1=Math.min(mx1,B[2]);my1=Math.min(my1,B[3]);if(mx1<=mx0||my1<=my0)return;
 const tx0=Math.floor((mx0+MERC)/size),tx1=Math.floor((mx1+MERC)/size),ty0=Math.floor((MERC-my1)/size),ty1=Math.floor((MERC-my0)/size);if((tx1-tx0+1)*(ty1-ty0+1)>300)return;
 ctx.save();ctx.setTransform(view.s,0,0,view.s,view.ox,view.oy);ctx.globalAlpha=tileAlpha;const px=size/geo.R0,pad=.6/view.s;
 for(let ty=ty0;ty<=ty1;ty++)for(let tx=tx0;tx<=tx1;tx++){const t=getLocalTile(z,tx,ty);if(t.ok){const ix=(-MERC+tx*size-geo.m0x)/geo.R0,iy=(geo.m0y-(MERC-ty*size))/geo.R0;ctx.drawImage(t.img,ix,iy,px+pad,px+pad)}}
 ctx.restore()}
function peekTile(z,x,y){const t=tiles.get(tileKey(z,x,y));return t&&t.ok?t:null}
function tileZoom(){const res=geo.R0/view.s;return Math.max(cfg?.web_imagery?.min_zoom||0,Math.min(tileMaxZ(),Math.ceil(Math.log2(2*MERC/256/res)-.25)))}
function drawTiles(){const z=tileZoom(),n=2**z,size=2*MERC/n;
 const corners=[[0,0],[canvas.width,0],[0,canvas.height],[canvas.width,canvas.height]].map(([cx,cy])=>[geo.m0x+(cx-view.ox)/view.s*geo.R0,geo.m0y-(cy-view.oy)/view.s*geo.R0]);
 const mx0=Math.min(...corners.map(c=>c[0])),mx1=Math.max(...corners.map(c=>c[0])),my0=Math.min(...corners.map(c=>c[1])),my1=Math.max(...corners.map(c=>c[1]));
 const tx0=Math.max(0,Math.floor((mx0+MERC)/size)),tx1=Math.min(n-1,Math.floor((mx1+MERC)/size)),ty0=Math.max(0,Math.floor((MERC-my1)/size)),ty1=Math.min(n-1,Math.floor((MERC-my0)/size));
 if((tx1-tx0+1)*(ty1-ty0+1)>400)return;
 ctx.save();ctx.setTransform(view.s,0,0,view.s,view.ox,view.oy);ctx.globalAlpha=tileAlpha;ctx.imageSmoothingEnabled=true;const px=size/geo.R0,pad=.6/view.s;
 for(let ty=ty0;ty<=ty1;ty++)for(let tx=tx0;tx<=tx1;tx++){const ix=(-MERC+tx*size-geo.m0x)/geo.R0,iy=(geo.m0y-(MERC-ty*size))/geo.R0;const t=getTile(z,tx,ty);
  if(t.ok){ctx.drawImage(t.img,ix,iy,px+pad,px+pad);continue}
  for(let k=1;k<=6&&z-k>=0;k++){const p=peekTile(z-k,tx>>k,ty>>k);if(!p)continue;const sub=256/2**k,sx=(tx-((tx>>k)<<k))*sub,sy=(ty-((ty>>k)<<k))*sub;ctx.drawImage(p.img,sx,sy,sub,sub,ix,iy,px+pad,px+pad);break}}
 ctx.restore()}
function drawVectors(){if(!vecPaths)return;ctx.save();ctx.setTransform(view.s,0,0,view.s,view.ox,view.oy);ctx.lineJoin='round';ctx.lineCap='round';ctx.globalAlpha=vecAlpha;const k=1/view.s;
 for(const role of [...Object.keys(VSTYLE)]){const v=vecPaths[role];if(!v||vecOn[role]===false)continue;const st=VSTYLE[role];
  if(v.fill&&st[3]){ctx.fillStyle=v.color+Math.round(st[3]*255).toString(16).padStart(2,'0');ctx.fill(v.fill,'evenodd')}
  ctx.setLineDash([]);ctx.strokeStyle='#05101a';ctx.globalAlpha=vecAlpha*.55;ctx.lineWidth=(st[1]+2)*k;ctx.stroke(v.path);ctx.globalAlpha=vecAlpha;
  ctx.setLineDash(st[2].map(d=>d*k));ctx.strokeStyle=v.color;ctx.lineWidth=st[1]*k;ctx.stroke(v.path)}
 ctx.setLineDash([]);const mpx=geo.R0/geo.k;// metros por pixel do espaço de imagem
 // Sinalização e setas como no vídeo: largura real (0,15 m / 0,16 m) com mínimo de 1 px na tela.
 if(vecPaths.signage&&vecOn.signage!==false){ctx.globalAlpha=Math.min(1,vecAlpha+.1);ctx.lineWidth=Math.max(.15/mpx,1*k);ctx.strokeStyle='#f4f2e2';ctx.stroke(vecPaths.signage.path);ctx.strokeStyle='#f4c846';ctx.stroke(vecPaths.signage.yellow);ctx.fillStyle='#f4f2e2';ctx.fill(vecPaths.signage.paint,'evenodd');ctx.fillStyle='#f4c846';ctx.fill(vecPaths.signage.paintY,'evenodd')}
 if(vecPaths.arrows&&vecOn.arrows!==false&&editor?.signage_detail!=='full'){ctx.globalAlpha=1;ctx.lineWidth=Math.max(.35/mpx,2*k);ctx.strokeStyle='#05101a';ctx.stroke(vecPaths.arrows.path);ctx.lineWidth=Math.max(.18/mpx,1.2*k);ctx.strokeStyle='#ffffff';ctx.stroke(vecPaths.arrows.path)}
 ctx.restore();if(editor&&vecOn.signage!==false)for(const g of editor.signs||[])if(g.source!=='manual'&&!(M.excluded_signs||[]).includes(g.sign_id))drawSignIcon({x:g.x,y:g.y},g.code,g.text,false)}
function setBase(mode){if(mode==='preview'&&!(baseImage&&meta))return msg('Gere uma prévia para usar a imagem renderizada como fundo.',true);if(mode!=='preview'&&!geo)return msg('Analise os arquivos (seção 1) para usar a imagem web.',true);
 let c=null,ppm=null;if(ready()){c=C2W(canvas.width/2,canvas.height/2);ppm=pxPerM()}baseMode=mode;saveBasePrefs();
 if(c){const [x,y]=worldToImg(c);view.s=ppm*mpp();view.ox=canvas.width/2-x*view.s;view.oy=canvas.height/2-y*view.s}baseUi();draw()}
function baseUi(){const sel=$('baseMode');if(!sel)return;sel.value=useGeo()?(baseMode==='none'?'none':'map'):'preview';
 sel.querySelector('option[value=preview]').disabled=!(baseImage&&meta);for(const v of ['map','none'])sel.querySelector(`option[value=${v}]`).disabled=!geo;
 $('vecAlpha').value=vecAlpha;$('tileAlpha').value=tileAlpha;
 const roles=vecPaths?Object.keys(VSTYLE).filter(r=>vecPaths[r]).concat(['signage','arrows'].filter(r=>vecPaths[r])):[];if(editor)roles.push('flows');$('vecLayers').innerHTML=roles.length?roles.map(r=>`<label class="vl"><input type="checkbox" data-vrole="${r}" ${vecOn[r]!==false?'checked':''}><span style="background:${(vecPaths[r]||{color:SIGN[r]?.[1]}).color}"></span>${VNAME[r]||SIGN[r]?.[0]||r} <small>(${r==='flows'?editor.segments.length:vecPaths[r].n})</small></label>`).join(''):'<span class="muted">Sem vetores: clique “Analisar arquivos”.</span>';
 $('baseInfo').textContent=geo?`Conversão CRS ↔ imagem web: erro máx. ${(Math.max(geo.err_fwd_m,geo.err_inv_m)*1000).toFixed(1)} mm`+(vec?` · ${vec.points} vértices simplificados (tolerância 0,25 m)`:' · vetores ainda não gerados: clique “Analisar arquivos”')+(useGeo()?'':' · editando sobre a prévia renderizada'):(analysis?'':'Analise os arquivos para abrir a imagem web.')}

/* ---------- Geometria auxiliar (cliente) ---------- */
function axisPts(){const a=editor?.axis||vec?.axis_main;return a?a.map(p=>({x:p[0],y:p[1]})):null}
let axisCache=null;
function axisData(){const src=editor||vec;if(!src||!(src.axis||src.axis_main))return null;if(axisCache&&axisCache.src===src)return axisCache;const a=axisPts(),s=[0];for(let i=1;i<a.length;i++)s.push(s[i-1]+Math.hypot(a[i].x-a[i-1].x,a[i].y-a[i-1].y));axisCache={src,a,s};return axisCache}
function projectAxis(p){const d=axisData();if(!d)return null;let best={dist:Infinity};for(let i=0;i<d.a.length-1;i++){const A=d.a[i],B=d.a[i+1],vx=B.x-A.x,vy=B.y-A.y,L2=vx*vx+vy*vy||1e-9;let t=((p.x-A.x)*vx+(p.y-A.y)*vy)/L2;t=Math.max(0,Math.min(1,t));const q={x:A.x+t*vx,y:A.y+t*vy},dist=Math.hypot(p.x-q.x,p.y-q.y);if(dist<best.dist)best={dist,point:q,s:d.s[i]+t*Math.sqrt(L2)}}return best}
/* Estaqueamento: mesmo cálculo do servidor (início, sentido e fator). */
function station(){const c=M.chainage||{},man=c.mode==='manual',d=axisData();const L=d?d.s[d.s.length-1]:0;
 const s0=man&&c.start?(projectAxis(c.start)?.s??0):0;const se=man&&c.end?projectAxis(c.end)?.s:null;
 let dir=se!=null&&Math.abs(se-s0)>1e-6?(se>s0?1:-1):(man?(c.direction||1):1);let scale=1;
 if(man&&c.calibrate&&se!=null&&Math.abs(se-s0)>1){const v=(cfg.km_end_m-cfg.km_start_m)/(dir*(se-s0));if(v>0)scale=v}
 const kmEndGeo=se!=null?cfg.km_start_m+dir*scale*(se-s0):cfg.km_start_m+dir*scale*((dir>0?L:0)-s0);return {s0,se,dir,scale,L,kmEndGeo,mode:c.mode||'auto'}}
function s0(){return station().s0}
function kmOf(p){const r=projectAxis(p);if(!r)return null;const st=station();return {km:cfg.km_start_m+st.dir*st.scale*(r.s-st.s0),off:r.dist,point:r.point,s:r.s}}
function sOfKm(km){const st=station();return st.s0+st.dir*(km-cfg.km_start_m)/st.scale}
function axisAt(s){const d=axisData();s=Math.max(0,Math.min(d.s[d.s.length-1],s));let i=1;while(i<d.s.length-1&&d.s[i]<s)i++;const t=(s-d.s[i-1])/((d.s[i]-d.s[i-1])||1e-9);return {x:d.a[i-1].x+(d.a[i].x-d.a[i-1].x)*t,y:d.a[i-1].y+(d.a[i].y-d.a[i-1].y)*t}}
function axisSub(sa,sb){const d=axisData();if(sa>sb)[sa,sb]=[sb,sa];const out=[axisAt(sa)];for(let i=0;i<d.s.length;i++)if(d.s[i]>sa&&d.s[i]<sb)out.push(d.a[i]);out.push(axisAt(sb));return out}
function distSeg(p,a,b){const vx=b.x-a.x,vy=b.y-a.y,L2=vx*vx+vy*vy||1e-9;let t=((p.x-a.x)*vx+(p.y-a.y)*vy)/L2;t=Math.max(0,Math.min(1,t));return Math.hypot(p.x-a.x-t*vx,p.y-a.y-t*vy)}
function distPolyline(p,pts){let d=Infinity;for(let i=0;i<pts.length-1;i++)d=Math.min(d,distSeg(p,pts[i],pts[i+1]));return d}
const P=a=>({x:a[0],y:a[1]});
function nearestSegment(p,maxM=8){if(!editor)return null;let best=null;for(const s of editor.segments){const pts=s.points.map(P),d=distPolyline(p,pts);if(d<=maxM&&(!best||d<best.d))best={d,seg:s}}return best&&best.seg}
function simplify(pts,tol){if(pts.length<3)return pts;let dmax=0,idx=0;for(let i=1;i<pts.length-1;i++){const d=distSeg(pts[i],pts[0],pts[pts.length-1]);if(d>dmax){dmax=d;idx=i}}if(dmax>tol){const a=simplify(pts.slice(0,idx+1),tol),b=simplify(pts.slice(idx),tol);return a.slice(0,-1).concat(b)}return [pts[0],pts[pts.length-1]]}
function invAlign(p){const r=editor&&editor.alignment;if(!r||!M.dxf_alignment.applied)return p;const k=r.a*r.a+r.b*r.b,ia=r.a/k,ib=-r.b/k,x=p.x-r.tx,y=p.y-r.ty;return {x:ia*x-ib*y,y:ib*x+ia*y}}
function fwdAlign(p,r){return {x:r.a*p.x-r.b*p.y+r.tx,y:r.b*p.x+r.a*p.y+r.ty}}

/* ---------- Ferramentas ---------- */
const TOOLS=[
 ['pan','✋ Navegar / selecionar','Clique num objeto para selecioná-lo: grips para arrastar, propriedades editáveis (Enter confirma) e Delete apaga. Arraste o fundo para mover a vista; roda do mouse aproxima. Digite comandos (MOVER, APAGAR, DIST, AL…) ou coordenadas na linha de comando.'],
 ['move','✥ Mover ponto','Arraste qualquer ponto marcado para outro lugar: placa, intervenção/passarela (centro), âncora e início da linha de chamada, destaque, cidade, faixa de pedestre, início/fim de faixa adicional, vértices de acesso, travessia, início/fim do km. Enter encerra.'],
 ['imgadjust','⧉ Ajustar imagem local','Escolha a imagem na lista (botão Ajustar). Arraste DENTRO dela para deslocar; arraste um CANTO para girar e escalar (Shift: só girar; Ctrl: só escalar). Setas do teclado deslocam 5 cm (Shift: 50 cm). Enter encerra.'],
 ['inspect','⌖ Inspecionar','Clique para ver coordenada, km e o item mais próximo.'],
 '|',
 ['chain','📏 Início do km','Clique sobre o eixo: ali vale o km inicial. Clique e ARRASTE ao longo do eixo para indicar o sentido de crescimento do km.'],
 ['chainend','🏁 Fim do km','Clique sobre o eixo onde vale o km final. Com início e fim, o sentido é automático; o ajuste proporcional distribui a diferença para o km final informado.'],
 ['poi','📍 Intervenção','Clique para preencher X/Y do formulário de intervenção (seção 4).'],
 ['span','↔ Vão da passarela','Arraste uma PONTA do vão: comprimento e ângulo acompanham o mouse (Shift: só o comprimento). Arraste o CENTRO para mudar a passarela de lugar. Enter encerra.'],
 ['anchor','↘ Linha de chamada','Escolha a obra abaixo e clique o ponto de ancoragem. Arraste a âncora (ponta) ou o marcador da obra (início) para movê-los. Enter encerra.'],
 ['highlight','⭐ Destaque','Clique no ponto especial (edificação, interferência, poste…). Clique e ARRASTE para posicionar a caixa de informação com linha de chamada. Arraste uma caixa existente para movê-la.'],
 ['oae','🌉 OAE (2 pontos)','Clique o início e depois o fim da OAE sobre o eixo.'],
 ['oaepoly','🌉 OAE (vértices)','Clique os vértices do tabuleiro (mínimo 4; polígono irregular permitido): comece por uma cabeceira, siga por um lado e volte pelo outro. Enter ou duplo clique conclui. Escolha o sentido abaixo. Ajuste depois com “Editar vértices”.'],
 '|',
 ['arrowrot','↻ Girar seta','Clique numa seta de fluxo para invertê-la; clique e arraste para apontar a seta (ela se alinha à faixa). O fluxo da via passa a seguir a seta — clique “Atualizar fluxos”.'],
 ['dir','➜ Sentido','Clique e arraste sobre a pista, no sentido do tráfego.'],
 ['flowrev','⇄ Inverter fluxo','Clique numa trajetória para inverter o sentido dos veículos nesse trecho (clique de novo para desfazer).'],
 ['flowoff','⦸ Desativar fluxo','Clique numa trajetória para desativá-la sem apagar a geometria (clique de novo para reativar).'],
 ['flowadd','✚ Incluir fluxo','Clique os pontos do novo fluxo; duplo clique ou Enter conclui. Só é aceito se passar na validação.'],
 ['noconn','✕ Sem conexão (ponto)','Clique no cruzamento em desnível: não haverá ligação de tráfego dentro do raio.'],
 ['noconnarea','⬚ Sem conexão (área)','Clique os vértices; duplo clique ou Enter conclui.'],
 '|',
 ['exvert','⬠ Exclusão (vértices)','Clique os vértices; duplo clique ou Enter conclui a área.'],
 ['exlasso','✎ Exclusão (laço)','Pressione e desenhe o contorno à mão livre; ao soltar, a área é fechada.'],
 ['exedit','◇ Editar vértices','Arraste vértices (exclusões e áreas sem sinalização). Clique numa aresta para inserir vértice; Shift+clique num vértice o remove.'],
 ['cleanarea','🧽 Sem sinalização','Pressione e desenhe (laço) a área onde pinturas e setas NÃO devem aparecer no vídeo (sujeiras). Ao soltar, a área é fechada; o pavimento continua.'],
 ['hatch','▨ Zebrado','Clique os vértices da área a zebrar (gore, ilha pintada, início de canteiro); Enter ou duplo clique conclui. Cor, ângulo e espaçamento na lista.'],
 ['crosswalk','🚶 Faixa de pedestre','Clique num bordo da pista e depois no bordo oposto: as barras são pintadas entre os dois pontos.'],
 ['sign','🛑 Placa','Escolha o tipo e o texto e clique ao lado da pista. Arraste uma placa existente para mudá-la de lugar. Enter encerra.'],
 ['pavarea','▦ Área de pista (desenhar)','Escolha o tipo abaixo (pista nova, pista existente ou acostamento) e clique os vértices da área; Enter ou duplo clique conclui. A área recebe a hachura do tipo e prevalece sobre o DXF.'],
 ['pavpick','⬚ Área de pista (selecionar)','Escolha o tipo abaixo e clique DENTRO de uma área fechada do desenho (pavimento, canteiro, camada extra…): ela passa a ser do tipo escolhido.'],
 ['shoulder','⇥ Acostamento (início/fim)','Informe a largura abaixo, clique o início e depois o fim junto ao bordo da pista: é criada a faixa de acostamento ao longo do bordo.'],
 ['lanerange','➕ 3ª faixa (início/fim)','Clique sobre a pista no início e depois no fim da faixa adicional: entre os dois km, a pista passa a ter o número de faixas informado abaixo (por sentido).'],
 ['lanes','☰ Faixas por trecho','Clique os vértices do trecho; Enter conclui. Dentro dele vale o número de faixas POR SENTIDO informado abaixo.'],
 ['city','🏙 Cidade','Clique no mapa para marcar uma cidade com o nome digitado abaixo. Na lista de marcações, “Buscar cidades próximas” traz os nomes do OpenStreetMap.'],
 '|',
 ['block','🚧 Interdição','Clique os vértices da área interditada (faixa ou pista); Enter conclui. Parcial: veículos reduzem a velocidade e formam fila; total: param antes e, se houver, seguem por rota alternativa.'],
 ['access','🛣 Acesso com taper','Clique o primeiro ponto junto ao bordo da pista e siga pelo eixo do acesso; Enter conclui. São gerados o pavimento do acesso e os tapers de entrada (antes) e saída (depois), com sinalização e fluxos. Ajuste larguras e comprimentos abaixo ou na lista.'],
 ['crossok','↶ Travessia permitida','Clique onde os veículos podem cruzar o canteiro (retorno indicado). Raio abaixo.'],
 ['crossno','⛔ Travessia proibida','Clique onde os veículos NÃO podem cruzar o canteiro, mesmo que a geometria permita.'],
 '|',
 ['pair','⊕ Par de controle','Clique o ponto no DXF e depois o mesmo ponto na imagem.'],
 ['cabin','🚗 Cabine','Clique sobre uma trajetória: define o veículo e o início do trecho da vista da cabine.']];
const SIGN_LABEL={'R-1':'R-1 Parada obrigatória (PARE)','R-2':'R-2 Dê a preferência','R-19':'R-19 Velocidade máxima','A':'Advertência (amarela)','OBRAS':'Obras (laranja)','I':'Indicação (verde)','S':'Serviço (azul)'};
const SIGN_STYLE={'R-1':['#c81e24','#fff'],'R-2':['#fff','#c81e24'],'R-19':['#fff','#c81e24'],'A':['#fac814','#111'],'OBRAS':['#f07814','#111'],'I':['#006e3c','#fff'],'S':['#14469f','#fff']};
const HL_LABEL={edificacao:'Edificação',interferencia:'Interferência',poste:'Poste',rede:'Rede',drenagem:'Drenagem',acesso:'Acesso',outro:'Ponto especial'};
const HL_STYLE={edificacao:['#f2a541','E'],interferencia:['#ff5d5d','!'],poste:['#ffd84d','P'],rede:['#7cc6ff','R'],drenagem:['#4fd1c5','D'],acesso:['#b48cff','A'],outro:['#ff8a3d','•']};
function hitHighlight(c){for(const h of M.highlights||[]){const [x,y]=h.label?W2C(h.label):(()=>{const q=W2C(h.point);return [q[0]+60,q[1]-60]})();if(Math.abs(c.cx-x)<70&&Math.abs(c.cy-y)<14)return h}return null}
let tool='pan',draft=null,selected=null,drag=null,spaceDown=false,lastWorld=null,anchorTarget='';
// 1.19: barra de ferramentas profissional — ícones vetoriais, grupos com título, rótulo curto e dica completa.
const ICON_PATHS={pan:'M8 12V6a1.5 1.5 0 013 0v5M11 11V4.5a1.5 1.5 0 013 0V11M14 11V6a1.5 1.5 0 013 0v7c0 4-2.5 7-6 7-2.5 0-4-1.2-5.5-3.5L4 13.5a1.5 1.5 0 012.5-1.6L8 14',
 move:'M12 3v18M3 12h18M12 3l-3 3M12 3l3 3M12 21l-3-3M12 21l3-3M3 12l3-3M3 12l3 3M21 12l-3-3M21 12l-3 3',imgadjust:'M4 7l9-3 7 6-9 3zM4 7l1 9 7 5M20 10l-1 8-7 3M11 13l1 8',
 inspect:'M11 4a7 7 0 100 14 7 7 0 000-14zM21 21l-5-5M11 8v6M8 11h6',chain:'M4 20L20 4M7 17l2 2M10 14l2 2M13 11l2 2M16 8l2 2',chainend:'M5 21V4M5 4h11l-2 4 2 4H5',
 poi:'M12 21s-6-6-6-11a6 6 0 0112 0c0 5-6 11-6 11zM12 7.5a2.5 2.5 0 100 5 2.5 2.5 0 000-5z',span:'M3 15h18M5 15V9h14v6M3 9h18M8 12h8',anchor:'M5 19L17 7M17 7h-6M17 7v6M4 20h3',
 highlight:'M12 3l2.6 5.6 6 .7-4.5 4.1 1.2 6L12 16.5 6.7 19.4l1.2-6L3.4 9.3l6-.7z',oae:'M2 16h20M4 16c2-6 14-6 16 0M7 16v4M17 16v4',oaepoly:'M3 8l6-4 12 3-2 10-12 3-4-6zM3 8v6',
 arrowrot:'M20 12a8 8 0 11-3-6.2M20 4v5h-5',dir:'M4 12h14M13 7l5 5-5 5',flowrev:'M4 8h14l-3-3M20 16H6l3 3',flowoff:'M12 3a9 9 0 100 18 9 9 0 000-18zM5.6 5.6l12.8 12.8',
 flowadd:'M12 5v14M5 12h14',noconn:'M6 6l12 12M18 6L6 18',noconnarea:'M4 4h16v16H4zM8 8l8 8M16 8l-8 8',exvert:'M5 8l7-4 7 4v8l-7 4-7-4z',exlasso:'M5 13c-2-5 3-9 8-8s8 5 5 9-9 4-11 1M7 15l-2 5',
 exedit:'M12 3l9 9-9 9-9-9zM12 8v.01M16 12v.01M12 16v.01M8 12v.01',cleanarea:'M4 20l6-6M9 9l6 6M13 5l6 6-4 4-6-6z',hatch:'M4 4h16v16H4zM4 12l8-8M4 20L20 4M12 20l8-8',
 crosswalk:'M5 4v16M9 4v16M13 4v16M17 4v16',pavarea:'M4 6l8-3 8 4-2 12-12 2zM6 12l6-6M6 18l12-12M12 19l6-6',pavpick:'M4 4h16v16H4zM9 9l3 9 1.5-3.5L17 13z',shoulder:'M4 4v16M9 4v16M9 8l11-4M9 20l11-4M14 6v12',sign:'M12 2l8 8-8 8-8-8zM12 18v4',lanerange:'M6 3v18M12 3v4M12 10v4M12 17v4M18 3v18M18 12h4M20 10v4',lanes:'M5 3v18M10 3v3M10 9v3M10 15v3M15 3v3M15 9v3M15 15v3M20 3v18',
 city:'M3 21h18M5 21V10l4-3v14M9 21V4h7v17M16 21V9h3v12',block:'M3 10h18v5H3zM6 10l3 5M11 10l3 5M16 10l3 5M5 15v5M19 15v5',access:'M3 6h18M3 18h18M12 18c0-6 3-9 9-9',
 crossok:'M4 14l5 5 11-12',crossno:'M12 3a9 9 0 100 18 9 9 0 000-18zM8 12h8',pair:'M6 6a2 2 0 100 4 2 2 0 000-4zM18 14a2 2 0 100 4 2 2 0 000-4zM8 9l8 6',cabin:'M4 15l2-6h12l2 6v3H4zM7 18v2M17 18v2M7.5 15h.01M16.5 15h.01'};
const TOOL_GROUPS=['Navegação','Estaqueamento e obras','Fluxos de tráfego','Áreas e sinalização','Tráfego e acessos','Calibração e cabine'];
function toolIcon(id){const d=ICON_PATHS[id];return d?`<svg viewBox="0 0 24 24" aria-hidden="true"><path d="${d}"/></svg>`:''}
const toolLabel=t=>t[1].replace(/^[^\p{L}\p{N}(]+/u,'').trim();
function buildToolbar(){let g=0,html=`<div class="tgroup"><span class="tgname">${TOOL_GROUPS[0]}</span><div class="tbtns">`;for(const t of TOOLS){if(t==='|'){g++;html+=`</div></div><div class="tgroup"><span class="tgname">${TOOL_GROUPS[g]||''}</span><div class="tbtns">`;continue}html+=`<button data-tool="${t[0]}" title="${esc(toolLabel(t)+' — '+t[2])}">${toolIcon(t[0])}<span>${esc(toolLabel(t))}</span></button>`}
 let lbl=false;try{lbl=localStorage.getItem('rodovia_tool_labels')==='1'}catch{}
 $('toolbar').innerHTML=html+`</div></div><button type="button" class="tlabels" id="toolLabels" title="Mostrar ou ocultar os nomes das ferramentas">${lbl?'Ocultar nomes':'Mostrar nomes'}</button>`;$('toolbar').classList.toggle('compact',!lbl);
 $('toolLabels').addEventListener('click',e=>{e.stopPropagation();const on=$('toolbar').classList.toggle('compact');try{localStorage.setItem('rodovia_tool_labels',on?'0':'1')}catch{};$('toolLabels').textContent=on?'Mostrar nomes':'Ocultar nomes'});$('toolbar').onclick=e=>{const b=e.target.closest('button');if(b?.dataset.tool)setTool(b.dataset.tool)};setTool('pan')}
function setTool(t){if(!TOOLS.some(x=>x[0]===t))return;commandRevision++;tool=t;draft=null;cadCmd=null;document.querySelectorAll('#toolbar button').forEach(b=>b.classList.toggle('active',b.dataset.tool===t));const d=TOOLS.find(x=>x[0]===t);$('toolHint').innerHTML=`Ferramenta ativa: <b>${esc(toolLabel(d))}</b> — ${esc(d[2])}`;canvas.style.cursor=t==='pan'?'grab':'crosshair';toolOptions();draw()}
function toolOptions(){const o=$('toolOptions');if(tool==='imgadjust'){imgAdjOptions(o);return}if(tool==='anchor'){const list=(editor?.pois||M.pois);o.innerHTML=`<label>Obra/caixa de apresentação<select id="anchorTarget">${M.pois.map(p=>`<option value="${esc(p.id)}" ${p.id===anchorTarget?'selected':''}>${esc(p.title)}</option>`).join('')}</select></label>`+(M.pois.length?'':'<p class="muted">Cadastre intervenções na seção 4 para definir âncoras.</p>');const sel=$('anchorTarget');if(sel){anchorTarget=sel.value;sel.onchange=()=>anchorTarget=sel.value}}else if(tool==='highlight'){o.innerHTML=`<div class="grid"><label>Tipo do destaque<select id="hlCat">${Object.entries(HL_LABEL).map(([k,v])=>`<option value="${k}">${v}</option>`).join('')}</select></label><label>Nome (opcional)<input id="hlName" placeholder="Ex.: Edifício Sede, Poste 123"></label></div><label>Descrição curta (opcional)<input id="hlDesc" maxlength="160" placeholder="Ex.: Interferência com rede de média tensão"></label>`}else if(tool==='chain'||tool==='chainend'){o.innerHTML=`<label>Km neste ponto (opcional; vazio = ${tool==='chain'?'km inicial do projeto':'calculado pela distância'})<input id="kmHere" placeholder="ex.: 325+850"></label>`}else if(tool==='access'){o.innerHTML='<div class="grid"><label>Largura do acesso (m)<input id="accWidth" type="number" value="7" min="3" max="20" step="0.5"></label><label>Taper de entrada (m)<input id="accIn" type="number" value="60" min="0" max="300"></label><label>Taper de saída (m)<input id="accOut" type="number" value="60" min="0" max="300"></label><label>Movimentos<select id="accMode"><option value="both">Entrada e saída</option><option value="in">Só entrada (desaceleração)</option><option value="out">Só saída (aceleração)</option></select></label></div>'}else if(tool==='city'){o.innerHTML='<label>Nome da cidade<input id="cityName" placeholder="Ex.: Nova Era"></label>'}else if(tool==='sign'){o.innerHTML=`<div class="grid"><label>Tipo de placa<select id="signCode">${Object.entries(SIGN_LABEL).map(([k,v])=>`<option value="${k}">${v}</option>`).join('')}</select></label><label>Texto (velocidade, destino, aviso)<input id="signText" maxlength="40" placeholder="Ex.: 60 · Nova Era · OBRAS"></label></div>`}else if(tool==='pavarea'||tool==='pavpick'){o.innerHTML=`<div class="grid"><label>Tipo da área<select id="pavKind">${Object.entries(PAV_LABEL).map(([k,v])=>`<option value="${k}" ${k===pavKind?'selected':''}>${v}</option>`).join('')}</select></label><label>Pavimento<select id="pavMat">${Object.entries(MAT_LABEL).map(([k,v])=>`<option value="${k}" ${k===pavMat?'selected':''}>${v}</option>`).join('')}</select></label></div>`;$('pavKind').onchange=()=>pavKind=$('pavKind').value;$('pavMat').onchange=()=>pavMat=$('pavMat').value}else if(tool==='shoulder'){o.innerHTML='<label>Largura do acostamento (m)<input id="shWidth" type="number" min="0.5" max="6" step="0.1" value="2.5"></label>'}else if(tool==='lanerange'){o.innerHTML='<label>Faixas por sentido entre o início e o fim<input id="rangeLanes" type="number" min="1" max="6" value="3"></label>'}else if(tool==='lanes'){o.innerHTML='<label>Número de faixas por sentido no trecho<input id="laneCount" type="number" min="1" max="6" value="2"></label>'}else if(tool==='hatch'){o.innerHTML='<label>Cor<select id="hatchColor"><option value="white">Branco (mesmo sentido)</option><option value="yellow">Amarelo (sentidos opostos)</option></select></label>'}else if(tool==='crosswalk'){o.innerHTML='<label>Largura da faixa de pedestre (m)<input id="cwWidth" type="number" min="2" max="10" step="0.5" value="4"></label>'}else if(tool==='noconn'){o.innerHTML='<label>Raio do cruzamento (m)<input id="zoneRadius" type="number" min="2" max="300" value="25"></label>'}else if(tool==='block'){o.innerHTML='<div class="grid"><label>Tipo<select id="blkMode"><option value="partial">Parcial (reduz velocidade, fila)</option><option value="total">Total (fecha; usa desvio)</option></select></label><label>Velocidade na parcial (km/h)<input id="blkSpeed" type="number" value="20" min="5" max="80"></label><label>Início no vídeo (s)<input id="blkStart" type="number" value="0" min="0"></label><label>Fim no vídeo (s, vazio = até o fim)<input id="blkEnd" type="number" min="0"></label></div>'}else if(tool==='crossok'||tool==='crossno'){o.innerHTML='<label>Raio (m)<input id="crossRadius" type="number" value="25" min="2" max="300"></label>'}else if(tool==='oaepoly'){o.innerHTML='<div class="grid"><label>Nível / cota relativa (m)<input id="oaeLevel" type="number" value="6" min="-30" max="60" step="0.5"></label><label>Sentido do tráfego na OAE<select id="oaeDir"><option value="both">Dois sentidos</option><option value="growing">Crescente (km aumenta)</option><option value="decreasing">Decrescente</option></select></label></div>'}else if(tool==='oae'){o.innerHTML='<div class="grid"><label>Nível / cota relativa (m)<input id="oaeLevel" type="number" value="6" min="-30" max="60" step="0.5"></label><label>Largura do tabuleiro (m)<input id="oaeWidth" type="number" value="14" min="3" max="60"></label></div>'}else o.innerHTML=''}

function canvasPt(e){const [x,y]=evtCanvas(e);return {cx:x,cy:y,w:ready()?C2W(x,y):null}}
const POLY_LISTS=['exclusions','clean_areas','oae','blocks','hatch','lanes','pav'];
function PG(k,i){return k==='pav'?M.pavement_areas[i].points:k==='oae'?M.oae_marks[i].polygon:k==='blocks'?M.lane_blocks[i].points:k==='hatch'?M.hatch_areas[i].points:k==='lanes'?M.lane_zones[i].points:M[k][i]}
function PN(k){return k==='pav'?(M.pavement_areas||[]).length:k==='oae'?M.oae_marks.length:k==='blocks'?M.lane_blocks.length:k==='hatch'?(M.hatch_areas||[]).length:k==='lanes'?(M.lane_zones||[]).length:M[k].length}
function PV(k,i){const a=PG(k,i);return Array.isArray(a)&&a.length>=3}
function oaeEnds(m){const P=m.polygon;if(!P||P.length<4)return;// eixo aproximado: maior dimensão do polígono (o programa recalcula exato)
 let best=[0,1,0];for(let a=0;a<P.length;a++)for(let b=a+1;b<P.length;b++){const d=Math.hypot(P[a].x-P[b].x,P[a].y-P[b].y);if(d>best[2])best=[a,b,d]}
 const c={x:P.reduce((s,p)=>s+p.x,0)/P.length,y:P.reduce((s,p)=>s+p.y,0)/P.length};const u={x:(P[best[1]].x-P[best[0]].x)/best[2],y:(P[best[1]].y-P[best[0]].y)/best[2]};
 const pr=P.map(p=>(p.x-c.x)*u.x+(p.y-c.y)*u.y),lo=Math.min(...pr),hi=Math.max(...pr);m.start={x:c.x+u.x*lo,y:c.y+u.y*lo};m.end={x:c.x+u.x*hi,y:c.y+u.y*hi};
 const area=Math.abs(P.reduce((s,p,i)=>{const q=P[(i+1)%P.length];return s+p.x*q.y-q.x*p.y},0))/2;m.width_m=Math.max(3,Math.min(60,area/Math.max(1,hi-lo)))}
function hitVertex(c,maxPx=9){for(const k of POLY_LISTS)for(let i=0;i<PN(k);i++){if(!PV(k,i))continue;for(let j=0;j<PG(k,i).length;j++){const [x,y]=W2C(PG(k,i)[j]);if(Math.hypot(x-c.cx,y-c.cy)<=maxPx)return {k,i,j}}}return null}
function hitEdge(c,maxPx=7){for(const k of POLY_LISTS)for(let i=0;i<PN(k);i++){if(!PV(k,i))continue;const a=PG(k,i);for(let j=0;j<a.length;j++){const A=W2C(a[j]),B=W2C(a[(j+1)%a.length]);const d=distSeg({x:c.cx,y:c.cy},{x:A[0],y:A[1]},{x:B[0],y:B[1]});if(d<=maxPx)return {k,i,j}}}return null}
function roadTangent(p){const r=projectAxis(p);if(!r||!isFinite(r.s))return {x:1,y:0};const a=axisAt(r.s-1),b=axisAt(r.s+1),L=Math.hypot(b.x-a.x,b.y-a.y)||1;return {x:(b.x-a.x)/L,y:(b.y-a.y)/L}}
function spanGeom(p){const u=roadTangent(p),a=(p.bridge_angle_deg||0)*Math.PI/180,v0={x:-u.y,y:u.x},v={x:v0.x*Math.cos(a)+u.x*Math.sin(a),y:v0.y*Math.cos(a)+u.y*Math.sin(a)},h=(p.bridge_span_m||38)/2;return {a:{x:p.x-v.x*h,y:p.y-v.y*h},b:{x:p.x+v.x*h,y:p.y+v.y*h}}}
function hitPasarela(c){for(const p of M.pois){if(p.kind!=='passarela')continue;const [x,y]=W2C(p);if(Math.hypot(x-c.cx,y-c.cy)<14)return p;const g=spanGeom(p);for(const q of [g.a,g.b]){const [qx,qy]=W2C(q);if(Math.hypot(qx-c.cx,qy-c.cy)<12)return p}}return null}
function setSpan(p,w,keepAngle){const u=roadTangent(p),v0={x:-u.y,y:u.x};let d={x:w.x-p.x,y:w.y-p.y};const L=Math.hypot(d.x,d.y);if(L<.5)return;d={x:d.x/L,y:d.y/L};
 if(d.x*v0.x+d.y*v0.y<0)d={x:-d.x,y:-d.y};p.bridge_span_m=Math.max(10,Math.min(160,Math.round(L*2*10)/10));
 if(!keepAngle){const ang=Math.atan2(d.x*u.x+d.y*u.y,d.x*v0.x+d.y*v0.y)*180/Math.PI;p.bridge_angle_deg=Math.max(-85,Math.min(85,Math.round(ang)))}}
// 1.19: pontos móveis de todas as marcações (ferramenta Mover).
function movablePoints(){const out=[];const add=(p,set,name)=>{if(p&&isFinite(p.x))out.push({p,set,name})};
 for(const g of M.signs||[])add(g.point,w=>g.point=w,'placa');
 for(const p of M.pois){add(p,w=>{p.x=w.x;p.y=w.y},p.kind==='passarela'?'passarela':'intervenção');if(p.anchor)add(p.anchor,w=>p.anchor=w,'âncora')}
 for(const h of M.highlights||[]){add(h.point,w=>h.point=w,'destaque');if(h.label)add(h.label,w=>h.label=w,'caixa do destaque')}
 for(const c of M.cities||[])add(c.point,w=>c.point=w,'cidade');
 for(const c of M.crosswalks||[]){add(c.a,w=>c.a=w,'faixa de pedestre');add(c.b,w=>c.b=w,'faixa de pedestre')}
 for(const m of M.shoulder_marks||[]){add(m.start,w=>m.start=w,'início do acostamento');add(m.end,w=>m.end=w,'fim do acostamento')}
 for(const r of M.lane_ranges||[]){add(r.start,w=>r.start=w,'início da faixa adicional');add(r.end,w=>r.end=w,'fim da faixa adicional')}
 for(const a of M.accesses||[])a.points.forEach((q,i)=>add(q,w=>a.points[i]=w,'acesso'));
 for(const z of M.crossing_zones||[])if(z.point)add(z.point,w=>z.point=w,'travessia');
 for(const z of M.no_connection_zones||[])if(z.point)add(z.point,w=>z.point=w,'sem conexão');
 for(const o of M.oae_marks||[])if(!(o.polygon&&o.polygon.length>=4)){add(o.start,w=>o.start=w,'OAE');add(o.end,w=>o.end=w,'OAE')}
 if(M.chainage?.start)add(M.chainage.start,w=>M.chainage={...M.chainage,start:w},'início do km');if(M.chainage?.end)add(M.chainage.end,w=>M.chainage={...M.chainage,end:w},'fim do km');
 return out}
function hitMovable(c,maxPx=12){let best=null;for(const m of movablePoints()){const [x,y]=W2C(m.p);const d=Math.hypot(x-c.cx,y-c.cy);if(d<=maxPx&&(!best||d<best.d))best={...m,d}}return best}
function hitAnchor(c){for(const p of M.pois)if(p.anchor){const [x,y]=W2C(p.anchor);if(Math.hypot(x-c.cx,y-c.cy)<10)return p}return null}

canvas.addEventListener('wheel',e=>{if(!ready())return;e.preventDefault();const [x,y]=evtCanvas(e);const k=Math.pow(1.0015,-e.deltaY);const s=Math.min(useGeo()?240:60,Math.max(minScale(),view.s*k));const f=s/view.s;view.ox=x-(x-view.ox)*f;view.oy=y-(y-view.oy)*f;view.s=s;draw()},{passive:false});
canvas.addEventListener('contextmenu',e=>e.preventDefault());
canvas.addEventListener('pointerdown',e=>{if(!ready())return;const c=canvasPt(e);canvas.focus({preventScroll:true});canvas.setPointerCapture(e.pointerId);
 if(e.button===1||e.button===2||tool==='pan'||spaceDown){drag={type:'pan',x:c.cx,y:c.cy,ox:view.ox,oy:view.oy};canvas.style.cursor='grabbing';return}
 if(e.button!==0)return;const w=c.w;
 if(tool==='dir'){drag={type:'dir',start:w,end:w};return}
 if(tool==='arrowrot'){const a=hitArrow(c);if(!a)return msg('Clique sobre uma seta de fluxo (camada “Setas de fluxo do vídeo”).',true);drag={type:'arrowrot',arrow:a,start:{x:a.p[0],y:a.p[1]},end:w,cx:c.cx,cy:c.cy};return}
 if(tool==='chain'&&axisData()){const r=projectAxis(w);if(r&&r.dist<=60){drag={type:'chain',start:r.point,end:w,cx:c.cx,cy:c.cy};return}}
 if(tool==='highlight'){const hh=hitHighlight(c);if(hh){checkpoint();drag={type:'hllabel',h:hh};return}drag={type:'hlnew',start:w,end:w,cx:c.cx,cy:c.cy};return}
 if(tool==='exlasso'||tool==='cleanarea'){drag={type:'lasso',pts:[w],target:tool==='cleanarea'?'clean_areas':'exclusions'};return}
 if(tool==='exedit'){const v=hitVertex(c);if(v){if(e.shiftKey){if(PG(v.k,v.i).length<=(v.k==='oae'?4:3))return msg(v.k==='oae'?'A OAE precisa de pelo menos 4 vértices.':'A área precisa de pelo menos três vértices. Exclua a área pela lista.',true);checkpoint();PG(v.k,v.i).splice(v.j,1);if(v.k==='oae')oaeEnds(M.oae_marks[v.i]);changed('Vértice removido.');return}checkpoint();drag={type:'vertex',...v};return}const ed=hitEdge(c);if(ed){checkpoint();PG(ed.k,ed.i).splice(ed.j+1,0,w);drag={type:'vertex',k:ed.k,i:ed.i,j:ed.j+1};changed();return}return}
 if(tool==='imgadjust'){const g=imgAdjHit(c);if(!g)return msg('Clique dentro da imagem (deslocar) ou num canto (girar/escalar). Escolha a imagem pelo botão Ajustar da lista.',true);drag={type:'imgadj',mode:g,w0:w,a0:{...imgAdj.cur},rot:e.shiftKey,scl:e.ctrlKey};return}
 if(tool==='move'){const m=hitMovable(c);if(!m)return msg('Clique sobre um ponto marcado (placa, intervenção, âncora, destaque, cidade, faixa de pedestre…).',true);checkpoint();drag={type:'move',m};canvas.style.cursor='move';return}
 if(tool==='sign'){const g=(M.signs||[]).find(g=>{const [x,y]=W2C(g.point);return Math.hypot(x-c.cx,y-c.cy)<14});if(g){checkpoint();drag={type:'move',m:{set:w=>g.point=w,name:'placa'}};return}}
 if(tool==='span'){const p0=M.pois.find(p=>p.kind==='passarela'&&Math.hypot(W2C(p)[0]-c.cx,W2C(p)[1]-c.cy)<9);if(p0){checkpoint();drag={type:'move',m:{set:w=>{p0.x=w.x;p0.y=w.y},name:'passarela'}};return}const p=hitPasarela(c);if(!p)return msg('Clique sobre uma passarela (cadastre a intervenção do tipo passarela na seção 4).',true);checkpoint();drag={type:'span',poi:p,shift:e.shiftKey};return}
 if(tool==='anchor'){const a=hitAnchor(c);if(a){checkpoint();drag={type:'anchor',poi:a};return}const p0=M.pois.find(p=>Math.hypot(W2C(p)[0]-c.cx,W2C(p)[1]-c.cy)<10);if(p0){checkpoint();drag={type:'move',m:{set:w=>{p0.x=w.x;p0.y=w.y},name:'início da linha de chamada'}};return}}
 click(w,e)});
canvas.addEventListener('pointermove',e=>{if(!ready())return;const c=canvasPt(e);lastWorld=c.w;cursorInfo(c.w);
 if(!drag){if(draft)draw();return}
 if(drag.type==='pan'){view.ox=drag.ox+c.cx-drag.x;view.oy=drag.oy+c.cy-drag.y;draw()}
 else if(drag.type==='dir'||drag.type==='chain'||drag.type==='hlnew'){drag.end=c.w;drag.moved=Math.hypot(c.cx-(drag.cx??c.cx),c.cy-(drag.cy??c.cy));draw()}
 else if(drag.type==='hllabel'){drag.h.label=c.w;draw()}
 else if(drag.type==='arrowrot'){drag.end=c.w;drag.moved=Math.hypot(c.cx-drag.cx,c.cy-drag.cy);draw()}
 else if(drag.type==='lasso'){const l=drag.pts[drag.pts.length-1];if(Math.hypot(l.x-c.w.x,l.y-c.w.y)*pxPerM()>3)drag.pts.push(c.w);draw()}
 else if(drag.type==='vertex'){PG(drag.k||'exclusions',drag.i)[drag.j]=c.w;draw()}
 else if(drag.type==='anchor'){drag.poi.anchor=c.w;draw()}
 else if(drag.type==='span'){setSpan(drag.poi,c.w,drag.shift);draw()}
 else if(drag.type==='move'){drag.m.set(c.w);drag.moved=true;draw()}
 else if(drag.type==='imgadj'){imgAdjDrag(drag,c.w);drag.moved=true;draw()}});
canvas.addEventListener('pointerup',e=>{if(!drag)return;const d=drag;drag=null;canvas.style.cursor=tool==='pan'?'grab':'crosshair';
 if(d.type==='chain'){checkpoint();const r=projectAxis(d.start);let dir=M.chainage.direction||1,txt='';if((d.moved||0)>12){const a=axisAt(r.s),b=axisAt(Math.min(r.s+1,station().L)),tx=b.x-a.x,ty=b.y-a.y;dir=((d.end.x-d.start.x)*tx+(d.end.y-d.start.y)*ty)>=0?1:-1;txt=dir>0?' Sentido: o do eixo.':' Sentido: contrário ao eixo.'}
  M.chainage={...M.chainage,mode:'manual',start:{x:d.start.x,y:d.start.y},direction:dir};kmTyped('start');changed(`Início do estaqueamento: km ${formatKm(cfg.km_start_m)}.`+txt+(M.chainage.end?' O ponto final, se marcado, prevalece sobre o sentido arrastado.':''));return}
 if(d.type==='hlnew'){checkpoint();const cat=$('hlCat')?.value||'outro',n=M.highlights.length+1,name=($('hlName')?.value||'').trim()||HL_LABEL[cat]+' '+n;M.highlights.push({id:uid(),name,category:cat,description:($('hlDesc')?.value||'').trim(),point:d.start,label:(d.moved||0)>12?d.end:null,color:'',show_in_video:true,show_km:true,stop:false});changed(`Destaque “${name}” criado. Edite nome e descrição na lista de marcações; arraste a caixa para reposicionar.`);return}
 if(d.type==='hllabel'){changed('Caixa do destaque movida.');return}
 if(d.type==='arrowrot'){rotateArrow(d.arrow,(d.moved||0)>10?{x:d.end.x-d.start.x,y:d.end.y-d.start.y}:null);return}
 if(d.type==='dir'){const len=Math.hypot(d.end.x-d.start.x,d.end.y-d.start.y);if(len<1)return msg('Arraste ao longo da pista para indicar o sentido (mínimo 1 m).',true);checkpoint();M.direction_marks.push({id:uid(),start:d.start,end:d.end});changed('Sentido definido. Clique “Atualizar fluxos” para aplicar.')}
 else if(d.type==='lasso'){const pts=simplify(d.pts,1.5/pxPerM());if(pts.length<3)return msg('Contorno pequeno demais.',true);checkpoint();if(d.target==='clean_areas'){M.clean_areas.push(pts);changed('Área sem sinalização adicionada: pinturas e setas dentro dela não aparecem no vídeo (atualize a prévia).');draw();return}M.exclusions.push(pts);changed('Área de exclusão adicionada.')}
 else if(d.type==='vertex'){if(d.k==='oae')oaeEnds(M.oae_marks[d.i]);changed('Vértice movido.')}
 else if(d.type==='anchor'){changed('Linha de chamada movida.')}
 else if(d.type==='move'){if(d.moved)changed(`Ponto movido (${d.m.name}).`)}
 else if(d.type==='imgadj'){if(d.moved)imgAdjCommit(d.a0)}
 else if(d.type==='span'){changed(`Vão da passarela “${d.poi.title}”: ${Math.round(d.poi.bridge_span_m||38)} m, ângulo ${Math.round(d.poi.bridge_angle_deg||0)}°.`)}
 draw()});
canvas.addEventListener('dblclick',e=>{if(draft&&draft.pts.length)finishDraft()});
canvas.addEventListener('keydown',e=>{if(tool==='imgadjust'&&imgAdj.cur&&e.key.startsWith('Arrow')){e.preventDefault();const st=e.shiftKey?.5:.05,a0={...imgAdj.cur};imgAdj.cur.shift_x+=e.key==='ArrowRight'?st:e.key==='ArrowLeft'?-st:0;imgAdj.cur.shift_y+=e.key==='ArrowUp'?st:e.key==='ArrowDown'?-st:0;draw();clearTimeout(imgAdj.t);imgAdj.t=setTimeout(()=>imgAdjCommit(imgAdj.k0||a0),500);imgAdj.k0=imgAdj.k0||a0;return}
 if(e.key===' '){spaceDown=true;e.preventDefault()}if(e.key==='Enter'){e.preventDefault();endCommand()}if(e.key==='Escape'){draft=null;cancelCommand()}});
// 1.19: Enter conclui o comando e volta para Navegar (libera outro comando em outro lugar).
async function endCommand(){const revision=commandRevision,had=!!draft;if(had)await finishDraft();if(revision!==commandRevision)return;if(!draft&&tool!=='pan'){setTool('pan');if(!had)msg('Comando encerrado. Escolha outra ferramenta.')}}
canvas.addEventListener('keyup',e=>{if(e.key===' ')spaceDown=false});
document.addEventListener('keydown',e=>{if(e.target.matches('input,select,textarea'))return;if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='z'){e.preventDefault();e.shiftKey?redo():undo()}else if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='y'){e.preventDefault();redo()}});

function kmTyped(which){const el=$('kmHere');if(!el||!el.value.trim())return null;let v;try{v=parseKm(el.value)}catch(e){msg(e.message,true);return null}
 if(which==='start'){$('km_start_m').value=formatKm(v);cfg.km_start_m=v}else{$('km_end_m').value=formatKm(v);cfg.km_end_m=v;M.chainage={...M.chainage,calibrate:true}}scheduleSave();return v}
function cursorInfo(w){if(!w)return;const k=axisData()?kmOf(w):null;$('cursor').textContent=`X ${w.x.toFixed(2)} · Y ${w.y.toFixed(2)} · ${cfg.crs||''}`+(k?` · km ${formatKm(k.km)} · ${k.off.toFixed(1)} m do eixo`+(M.chainage.mode==='off'?' (estaqueamento desligado: km medido do início do eixo)':''):'')}
function click(w,e){
 if(tool==='inspect'){const seg=nearestSegment(w,10);const k=axisData()?kmOf(w):null;msg(`Ponto X ${w.x.toFixed(3)} Y ${w.y.toFixed(3)}`+(k?` · km ${formatKm(k.km)}`:'')+(seg?`\nTrajetória ${seg.id}: ${seg.kind}, ${seg.both?'dois sentidos':seg.forward?'sentido do desenho':'sentido inverso ao desenho'}${seg.disabled?' · DESATIVADA':''}${seg.reversed?' · invertida pelo usuário':''} · ${seg.source}`:''));return}
 if(tool==='poi'){$('poiX').value=w.x.toFixed(3);$('poiY').value=w.y.toFixed(3);const k=axisData()?kmOf(w):null;msg('Coordenada copiada para a intervenção'+(k?` · km calculado ${formatKm(k.km)}`:'')+'. Preencha o nome e clique “Adicionar intervenção”.');return}
 if(tool==='chain'){if(!axisData())return msg('Analise os arquivos (seção 1) ou gere a prévia para carregar o eixo.',true);const r=projectAxis(w);if(r.dist>60)return msg(`Clique sobre o eixo (o ponto está a ${r.dist.toFixed(0)} m).`,true);checkpoint();M.chainage={...M.chainage,mode:'manual',start:{x:r.point.x,y:r.point.y}};kmTyped('start');changed(`Início do estaqueamento: km ${formatKm(cfg.km_start_m)} neste ponto do eixo (${r.s.toFixed(1)} m do início geométrico). Arraste ao clicar para indicar o sentido.`);return}
 if(tool==='chainend'){if(!axisData())return msg('Analise os arquivos (seção 1) ou gere a prévia para carregar o eixo.',true);const r=projectAxis(w);if(r.dist>60)return msg(`Clique sobre o eixo (o ponto está a ${r.dist.toFixed(0)} m).`,true);checkpoint();M.chainage={...M.chainage,mode:'manual',end:{x:r.point.x,y:r.point.y}};const typed=kmTyped('end');const st=station();if(typed!=null){changed(`Fim do estaqueamento: km ${formatKm(typed)} neste ponto (ajuste proporcional ligado: a diferença para a distância medida é distribuída).`);return}changed(`Fim do estaqueamento: km ${formatKm(st.kmEndGeo)} pela distância medida`+(Math.abs(st.kmEndGeo-cfg.km_end_m)>.5&&!M.chainage.calibrate?` (km final informado: ${formatKm(cfg.km_end_m)}; ative o ajuste proporcional ou use o km do eixo).`:'.'));return}
 if(tool==='highlight'){return}
if(tool==='crossok'||tool==='crossno'){checkpoint();const n=M.crossing_zones.length+1;M.crossing_zones.push({id:uid(),name:(tool==='crossok'?'Travessia permitida ':'Travessia proibida ')+n,mode:tool==='crossok'?'allow':'deny',kind:'point',point:w,radius_m:Number($('crossRadius')?.value||25),points:[]});changed((tool==='crossok'?'Travessia permitida':'Travessia proibida')+' marcada. Clique “Atualizar fluxos”.');return}
 if(tool==='sign'){const code=$('signCode')?.value||'I',text=($('signText')?.value||'').trim();checkpoint();M.signs.push({id:uid(),point:w,code,text,heading_deg:null,show:true});changed(`Placa ${SIGN_LABEL[code]} marcada. Gere a prévia para vê-la no vídeo.`);return}
 if(tool==='pavpick'){const r=pickRing(w);if(!r)return msg('Nenhuma área fechada do desenho contém este ponto. Desenhe a área com “Área de pista (desenhar)”.',true);checkpoint();const n=M.pavement_areas.length+1;M.pavement_areas.push({id:uid(),name:PAV_LABEL[pavKind]+' '+n,kind:pavKind,material:pavMat,points:r.map(q=>({x:q[0],y:q[1]})),source:'picked',enabled:true});changed(`Área ${n} selecionada como ${PAV_LABEL[pavKind].toLowerCase()} (${r.length} vértices). Clique “Analisar arquivos” ou gere a prévia para aplicar.`);return}
 if(tool==='shoulder'){if(!draft||draft.type!=='shoulder'){draft={type:'shoulder',pts:[w]};draw();return msg('Início do acostamento marcado. Clique no fim, junto ao mesmo bordo.')}const a=draft.pts[0];draft=null;if(Math.hypot(w.x-a.x,w.y-a.y)<2)return msg('Início e fim muito próximos.',true);checkpoint();const n=M.shoulder_marks.length+1;M.shoulder_marks.push({id:uid(),name:'Acostamento '+n,start:a,end:w,width_m:Math.max(.5,Math.min(6,Number($('shWidth')?.value||2.5))),enabled:true});changed(`Acostamento ${n} criado (${M.shoulder_marks[n-1].width_m} m). Clique “Analisar arquivos” ou gere a prévia para aplicar.`);return}
 if(tool==='lanerange'){if(!draft||draft.type!=='lanerange'){draft={type:'lanerange',pts:[w]};draw();const k=axisData()?kmOf(w):null;return msg('Início marcado'+(k?` (km ${formatKm(k.km)})`:'')+'. Clique no fim da faixa adicional, na mesma pista.')}const a=draft.pts[0];draft=null;if(Math.hypot(w.x-a.x,w.y-a.y)<20)return msg('Início e fim muito próximos (mínimo 20 m).',true);checkpoint();const n=M.lane_ranges.length+1;M.lane_ranges.push({id:uid(),name:'Faixa adicional '+n,start:a,end:w,lanes:Math.max(1,Math.min(6,Number($('rangeLanes')?.value||3)))});const ka=axisData()?kmOf(a):null,kb=axisData()?kmOf(w):null;changed(`Faixa adicional ${n}: ${M.lane_ranges[n-1].lanes} faixas por sentido`+(ka&&kb?` do km ${formatKm(Math.min(ka.km,kb.km))} ao ${formatKm(Math.max(ka.km,kb.km))}`:'')+'. Clique “Atualizar fluxos” ou gere a prévia.');return}
 if(tool==='crosswalk'){if(!draft||draft.type!=='crosswalk'){draft={type:'crosswalk',pts:[w]};draw();return msg('Primeiro bordo marcado. Clique no bordo oposto da pista.')}const a=draft.pts[0];draft=null;if(Math.hypot(w.x-a.x,w.y-a.y)<1)return msg('Faixa de pedestre com menos de 1 m.',true);checkpoint();const n=M.crosswalks.length+1;M.crosswalks.push({id:uid(),name:'Faixa de pedestre '+n,a,b:w,width_m:Number($('cwWidth')?.value||4),show:true});changed(`Faixa de pedestre ${n} criada.`);return}
 if(tool==='city'){const name=($('cityName')?.value||'').trim();if(!name)return msg('Digite o nome da cidade abaixo da barra de ferramentas.',true);checkpoint();M.cities.push({id:uid(),name,point:w,kind:'',population:null,source:'manual',show:true});changed(`Cidade “${name}” marcada.`);return}
 if(tool==='anchor'){const p=M.pois.find(p=>p.id===anchorTarget);if(!p)return msg('Escolha a obra na lista abaixo da barra de ferramentas.',true);checkpoint();p.anchor=w;changed(`Âncora da chamada “${p.title}” definida.`);return}
 if(tool==='oae'){if(!axisData())return msg('Analise os arquivos (seção 1) ou gere a prévia para carregar o eixo.',true);const r=projectAxis(w);if(r.dist>80)return msg('Clique sobre o eixo.',true);if(!draft||draft.type!=='oae'){draft={type:'oae',pts:[r.point]};draw();msg('Início marcado. Clique o fim da OAE.');return}const a=draft.pts[0],b=r.point;draft=null;if(Math.hypot(a.x-b.x,a.y-b.y)<2)return msg('OAE com menos de 2 m.',true);checkpoint();const n=M.oae_marks.length+1;M.oae_marks.push({id:uid(),name:'OAE '+n,start:a,end:b,level_m:Number($('oaeLevel')?.value||6),width_m:Number($('oaeWidth')?.value||14),km_start_override_m:null,km_end_override_m:null,callout:true});changed(`OAE ${n} criada: km ${formatKm(kmOf(a).km)} a ${formatKm(kmOf(b).km)}.`);return}
 if(tool==='flowrev'||tool==='flowoff'){const action=tool==='flowrev'?'reverse':'disable';const seg=nearestSegment(w);if(!seg)return msg('Nenhuma trajetória a menos de 8 m. Gere a prévia e clique sobre uma trajetória.',true);const segPts=seg.points.map(P);checkpoint();const existing=M.flow_overrides.findIndex(o=>o.action===action&&distPolyline(o,segPts)<=6);if(existing>=0){M.flow_overrides.splice(existing,1);changed(action==='reverse'?'Inversão removida. Clique “Atualizar fluxos”.':'Fluxo reativado. Clique “Atualizar fluxos”.')}else{M.flow_overrides.push({id:uid(),x:seg.mid[0],y:seg.mid[1],action,enabled:true});changed(action==='reverse'?'Sentido invertido neste trecho. Clique “Atualizar fluxos” para aplicar.':'Trajetória desativada (geometria preservada). Clique “Atualizar fluxos”.')}
  editorSegmentPreview(seg,action);return}
 if(tool==='noconn'){checkpoint();M.no_connection_zones.push({id:uid(),name:'Cruzamento sem conexão '+(M.no_connection_zones.length+1),kind:'point',point:w,radius_m:Number($('zoneRadius')?.value||25),points:[]});changed('Cruzamento sem conexão criado. Clique “Atualizar fluxos”.');return}
 if(tool==='pair'){if(!draft||draft.type!=='pair'){draft={type:'pair',pts:[w]};draw();msg('Ponto do DXF marcado. Clique o mesmo ponto na imagem'+(useGeo()&&baseMode==='map'?' web (Esri).':' aérea.'));return}const dxf=invAlign(draft.pts[0]);draft=null;checkpoint();M.dxf_alignment.pairs.push({id:uid(),dxf,image:w,enabled:true});changed('Par de controle adicionado. Use “Calcular resíduos”.');fitAlign(false);return}
 if(tool==='cabin'){const seg=nearestSegment(w,20);if(!seg)return msg('Clique sobre uma trajetória (até 20 m).',true);checkpoint();M.cabin={...M.cabin,start:w};changed('Início da vista da cabine definido. Marque “Gerar o vídeo pela vista da cabine” e gere a prévia na “Câmera do vídeo”.');cabinUi();return}
 if(['flowadd','exvert','noconnarea','oaepoly','block','hatch','lanes','access','pavarea'].includes(tool)){if(!draft||draft.type!==tool)draft={type:tool,pts:[]};draft.pts.push(w);draw()}}
function editorSegmentPreview(seg,action){if(action==='reverse'){seg.forward=!seg.forward;seg.reversed=!seg.reversed}else seg.disabled=!seg.disabled;draw()}
async function finishDraft(){if(!draft)return;const d=draft;
 if(d.type==='block'){if(d.pts.length<3)return msg('Marque pelo menos 3 vértices da interdição.',true);draft=null;checkpoint();const n=M.lane_blocks.length+1,end=$('blkEnd')?.value;M.lane_blocks.push({id:uid(),name:'Interdição '+n,points:d.pts,mode:$('blkMode')?.value||'partial',speed_kmh:Number($('blkSpeed')?.value||20),start_s:Number($('blkStart')?.value||0),end_s:end===''||end==null?null:Number(end),show:true});changed(`Interdição ${n} criada. Gere a prévia na “Câmera do vídeo” ou o vídeo para ver a fila.`)}
 else if(d.type==='oaepoly'){if(d.pts.length<4)return msg('Marque pelo menos 4 vértices do tabuleiro.',true);draft=null;checkpoint();const n=M.oae_marks.length+1;const m={id:uid(),name:'OAE '+n,start:d.pts[0],end:d.pts[1],level_m:Number($('oaeLevel')?.value||6),width_m:14,km_start_override_m:null,km_end_override_m:null,callout:true,polygon:d.pts,direction:$('oaeDir')?.value||'both'};oaeEnds(m);M.oae_marks.push(m);changed(`OAE ${n} criada com ${d.pts.length} vértices (${({both:'dois sentidos',growing:'sentido crescente',decreasing:'sentido decrescente'})[m.direction]}). Clique “Atualizar fluxos” para aplicar o sentido.`)}
 else if(d.type==='access'){if(d.pts.length<2)return msg('Marque pelo menos dois pontos (o primeiro junto ao bordo da pista).',true);draft=null;checkpoint();const n=M.accesses.length+1;M.accesses.push({id:uid(),name:'Acesso '+n,points:d.pts,width_m:Number($('accWidth')?.value||7),lane_width_m:3.5,taper_in_m:Number($('accIn')?.value||60),taper_out_m:Number($('accOut')?.value||60),mode:$('accMode')?.value||'both',enabled:true});changed(`Acesso ${n} criado. Clique “Analisar arquivos” (ou atualizar a prévia) para gerar o pavimento, os tapers e os fluxos.`)}
 else if(d.type==='pavarea'){if(d.pts.length<3)return msg('Marque pelo menos três vértices.',true);draft=null;checkpoint();const n=M.pavement_areas.length+1;M.pavement_areas.push({id:uid(),name:PAV_LABEL[pavKind]+' '+n,kind:pavKind,material:pavMat,points:d.pts,source:'drawn',enabled:true});changed(`Área ${n} (${PAV_LABEL[pavKind].toLowerCase()}) criada. Clique “Analisar arquivos” ou gere a prévia para aplicar.`)}
 else if(d.type==='hatch'){if(d.pts.length<3)return msg('Marque pelo menos três vértices.',true);draft=null;checkpoint();const n=M.hatch_areas.length+1;M.hatch_areas.push({id:uid(),name:'Zebrado '+n,points:d.pts,color:$('hatchColor')?.value||'white',angle_deg:null,spacing_m:2.6});changed(`Zebrado ${n} criado. Gere a prévia para vê-lo.`)}
 else if(d.type==='lanes'){if(d.pts.length<3)return msg('Marque pelo menos três vértices.',true);draft=null;checkpoint();const n=M.lane_zones.length+1;M.lane_zones.push({id:uid(),name:'Faixas '+n,points:d.pts,lanes:Math.max(1,Math.min(6,Number($('laneCount')?.value||2)))});changed(`Trecho com ${M.lane_zones[n-1].lanes} faixa(s) criado. Clique “Atualizar fluxos”.`)}
 else if(d.type==='exvert'){if(d.pts.length<3)return msg('Marque pelo menos três vértices.',true);draft=null;checkpoint();M.exclusions.push(d.pts);changed('Área de exclusão adicionada.')}
 else if(d.type==='noconnarea'){if(d.pts.length<3)return msg('Marque pelo menos três vértices.',true);draft=null;checkpoint();M.no_connection_zones.push({id:uid(),name:'Cruzamento sem conexão '+(M.no_connection_zones.length+1),kind:'area',point:null,radius_m:25,points:d.pts});changed('Área sem conexão criada. Clique “Atualizar fluxos”.')}
 else if(d.type==='flowadd'){if(d.pts.length<2)return msg('Marque ao menos dois pontos.',true);requireProject();await save();if(draft!==d)return;const r=await api('/api/projects/'+pid+'/validate_path',json('POST',{points:d.pts,level:Number($('pathLevel').value)}));if(draft!==d)return;if(!r.ok){draft={...d,fail:r.at};draw();return msg('Fluxo rejeitado: '+r.reason+' O ponto do problema está marcado em vermelho; ajuste (Esc descarta).',true)}draft=null;checkpoint();M.traffic_paths.push({id:uid(),name:$('pathName').value||'Fluxo',kind:$('pathKind').value,direction:$('pathDirection').value,level:Number($('pathLevel').value),points:d.pts,enabled:true});changed(`Fluxo aceito (${r.length_m.toFixed(0)} m). Clique “Atualizar fluxos” para incluí-lo.`)}
 draw()}

/* ---------- Desenho ---------- */
function poly(pts,close){ctx.beginPath();pts.forEach((p,i)=>{const q=W2C(p);i?ctx.lineTo(...q):ctx.moveTo(...q)});if(close)ctx.closePath()}
function arrowHead(a,b,size,color){const [x1,y1]=W2C(a),[x2,y2]=W2C(b),ang=Math.atan2(y2-y1,x2-x1);ctx.beginPath();ctx.moveTo(x2,y2);ctx.lineTo(x2-size*Math.cos(ang-.45),y2-size*Math.sin(ang-.45));ctx.lineTo(x2-size*Math.cos(ang+.45),y2-size*Math.sin(ang+.45));ctx.closePath();ctx.fillStyle=color;ctx.fill()}
function arrowsAlong(pts,forward,both,color,spacingPx=90){const L=[0];for(let i=1;i<pts.length;i++){const a=W2C(pts[i-1]),b=W2C(pts[i]);L.push(L[i-1]+Math.hypot(b[0]-a[0],b[1]-a[1]))}const total=L[L.length-1];if(total<30)return;for(let d=spacingPx/2;d<total;d+=spacingPx){let i=1;while(i<L.length-1&&L[i]<d)i++;const t=(d-L[i-1])/((L[i]-L[i-1])||1),a=pts[i-1],b=pts[i],m={x:a.x+(b.x-a.x)*t,y:a.y+(b.y-a.y)*t};const dirs=both?[1,-1]:[forward?1:-1];for(const s of dirs){const tip={x:m.x+(b.x-a.x)*.001*s,y:m.y+(b.y-a.y)*.001*s};arrowHead(s>0?m:tip,s>0?tip:m,9,color)}}}
function label(text,p,color='#fff'){const [x,y]=W2C(p);ctx.font='12px system-ui';ctx.lineWidth=3;ctx.strokeStyle='#081623';ctx.strokeText(text,x+8,y-8);ctx.fillStyle=color;ctx.fillText(text,x+8,y-8)}
// 1.19: desenha só o recorte visível da prévia. Com zoom forte (~10 m na tela) o destino ficava com dezenas de
// milhares de pixels e o navegador deixava de desenhar a imagem.
function drawPreviewImage(){const im=baseImage,s=view.s;ctx.imageSmoothingEnabled=s<2;
 const sx0=Math.max(0,Math.floor(-view.ox/s)-1),sy0=Math.max(0,Math.floor(-view.oy/s)-1),sx1=Math.min(im.width,Math.ceil((canvas.width-view.ox)/s)+1),sy1=Math.min(im.height,Math.ceil((canvas.height-view.oy)/s)+1);
 if(sx1<=sx0||sy1<=sy0)return;ctx.drawImage(im,sx0,sy0,sx1-sx0,sy1-sy0,view.ox+sx0*s,view.oy+sy0*s,(sx1-sx0)*s,(sy1-sy0)*s)}
function draw(){ctx.setTransform(1,0,0,1,0,0);ctx.fillStyle='#0c1722';ctx.fillRect(0,0,canvas.width,canvas.height);if(!ready()){ctx.fillStyle='#9cb3bf';ctx.font='16px system-ui';ctx.fillText(pid?'Clique “Analisar arquivos” (seção 1) para editar sobre a imagem web, ou gere uma prévia.':'Crie ou abra um projeto.',24,40);return}
 if(useGeo()){if(baseMode==='map'){drawTiles();drawLocalTiles()}drawVectors()}else drawPreviewImage();ctx.lineJoin='round';ctx.lineCap='round';
 const ad=axisData();
 if(ad){poly(ad.a);ctx.strokeStyle='#ffffff55';ctx.lineWidth=1.5;ctx.setLineDash([6,6]);ctx.stroke();ctx.setLineDash([]);
  const st=station(),L=ad.s[ad.s.length-1],ppm=pxPerM(),step=ppm>.5?100:ppm>.1?500:1000;const ka=cfg.km_start_m+st.dir*st.scale*(0-st.s0),kb=cfg.km_start_m+st.dir*st.scale*(L-st.s0);const first=Math.ceil(Math.min(ka,kb)/step)*step;
  for(let km=first;km<=Math.max(ka,kb)+1e-6;km+=step){const s=sOfKm(km);if(s<0||s>L)continue;const p=axisAt(s),[x,y]=W2C(p);ctx.fillStyle='#ffd56b';ctx.beginPath();ctx.arc(x,y,3,0,7);ctx.fill();if(step>=500||km%500===0)label(formatKm(km),p,'#ffe9a8')}
  if(M.chainage.mode==='manual'&&M.chainage.end){const st=station();const [x,y]=W2C(M.chainage.end);ctx.fillStyle='#ffd56b';ctx.strokeStyle='#081623';ctx.lineWidth=2;ctx.beginPath();ctx.rect(x-8,y-8,16,16);ctx.fill();ctx.stroke();label('Fim km '+formatKm(st.kmEndGeo),M.chainage.end,'#ffd56b')}
  if(M.chainage.mode!=='off'){const st=station();const a=axisAt(st.s0),b=axisAt(st.s0+st.dir*Math.min(60,st.L/4));arrowHead(a,b,16,'#ffd56b');poly([a,b]);ctx.strokeStyle='#ffd56b';ctx.lineWidth=3;ctx.stroke()}
  if(M.chainage.mode==='manual'&&M.chainage.start){const [x,y]=W2C(M.chainage.start);ctx.fillStyle='#ffd56b';ctx.strokeStyle='#081623';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(x,y-14);ctx.lineTo(x+10,y);ctx.lineTo(x,y+14);ctx.lineTo(x-10,y);ctx.closePath();ctx.fill();ctx.stroke();label('Início km '+formatKm(cfg.km_start_m),M.chainage.start,'#ffd56b')}}
 if(editor&&vecOn.flows!==false)for(const s of editor.segments){const pts=s.points.map(P);poly(pts);ctx.lineWidth=s.disabled?2:2.5;ctx.strokeStyle=s.disabled?'#9aa3a8':s.reversed?'#ffae5c':s.manual?'#e78bff':'#61e6d7';ctx.setLineDash(s.disabled?[5,6]:[]);ctx.stroke();ctx.setLineDash([]);if(!s.disabled)arrowsAlong(pts,s.forward,s.both,ctx.strokeStyle)}
 for(const p of M.traffic_paths){poly(p.points);ctx.strokeStyle=p.enabled===false?'#9aa3a8':'#e78bff';ctx.lineWidth=3;ctx.setLineDash(p.enabled===false?[4,6]:[]);ctx.stroke();ctx.setLineDash([])}
 for(const d of M.direction_marks){poly([d.start,d.end]);ctx.strokeStyle='#ffe14d';ctx.lineWidth=4;ctx.stroke();arrowHead(d.start,d.end,14,'#ffe14d')}
 for(const o of M.flow_overrides){const [x,y]=W2C(o);ctx.fillStyle=o.action==='reverse'?'#ffae5c':'#c9d1d6';ctx.beginPath();ctx.arc(x,y,6,0,7);ctx.fill();ctx.fillStyle='#081623';ctx.font='bold 10px system-ui';ctx.fillText(o.action==='reverse'?'⇄':'⦸',x-4,y+4)}
 M.exclusions.forEach((a,i)=>{if(!a.length)return;poly(a,true);ctx.fillStyle=selected===`ex${i}`?'#ff786077':'#ff786044';ctx.fill();ctx.strokeStyle='#ff9577';ctx.lineWidth=2.5;ctx.stroke();if(tool==='exedit')for(const p of a){const [x,y]=W2C(p);ctx.fillStyle='#fff';ctx.strokeStyle='#c4442a';ctx.lineWidth=2;ctx.beginPath();ctx.rect(x-4,y-4,8,8);ctx.fill();ctx.stroke()}});
 (M.clean_areas||[]).forEach((a,i)=>{if(!a.length)return;poly(a,true);ctx.fillStyle=selected===`ca${i}`?'#5ad8ff55':'#5ad8ff26';ctx.fill();ctx.strokeStyle='#5ad8ff';ctx.lineWidth=2;ctx.setLineDash([7,5]);ctx.stroke();ctx.setLineDash([]);if(tool==='exedit')for(const p of a){const [x,y]=W2C(p);ctx.fillStyle='#fff';ctx.strokeStyle='#1d7fa3';ctx.lineWidth=2;ctx.beginPath();ctx.rect(x-4,y-4,8,8);ctx.fill();ctx.stroke()}label('🧽 sem sinalização',a[0],'#bdefff')});
 (M.lane_blocks||[]).forEach((b,i)=>{if(!b.points||b.points.length<3)return;poly(b.points,true);ctx.fillStyle=b.mode==='total'?'#ec701c77':'#ec701c44';ctx.fill();ctx.strokeStyle='#ec701c';ctx.lineWidth=2.5;ctx.setLineDash([6,4]);ctx.stroke();ctx.setLineDash([]);if(tool==='exedit')for(const p of b.points){const [x,y]=W2C(p);ctx.fillStyle='#fff';ctx.strokeStyle='#ec701c';ctx.lineWidth=2;ctx.beginPath();ctx.rect(x-4,y-4,8,8);ctx.fill();ctx.stroke()}label('🚧 '+b.name+(b.mode==='total'?' (total)':` (${b.speed_kmh} km/h)`),b.points[0],'#ffd2b0')});
 (M.pavement_areas||[]).forEach((a,i)=>{if(!a.points||a.points.length<3)return;const st=PAV_STYLE[a.kind]||PAV_STYLE.pavement;poly(a.points,true);ctx.fillStyle=a.enabled===false?'#9aa3a822':st[0];ctx.fill();ctx.save();ctx.clip();ctx.strokeStyle=st[1];ctx.lineWidth=1.2;const b=a.points.map(p=>W2C(p)),xs=b.map(v=>v[0]),ys=b.map(v=>v[1]),x0=Math.min(...xs),x1=Math.max(...xs),y0=Math.min(...ys),y1=Math.max(...ys);ctx.beginPath();for(let k=x0-(y1-y0);k<x1;k+=st[2]){ctx.moveTo(k,y0);ctx.lineTo(k+(y1-y0),y1)}ctx.stroke();ctx.restore();poly(a.points,true);ctx.strokeStyle=st[1];ctx.lineWidth=selected===`pav${i}`?3:1.8;ctx.stroke();if(tool==='exedit')for(const p of a.points){const [x,y]=W2C(p);ctx.fillStyle='#fff';ctx.strokeStyle=st[1];ctx.lineWidth=2;ctx.beginPath();ctx.rect(x-4,y-4,8,8);ctx.fill();ctx.stroke()}label('▦ '+a.name+(a.material==='rigido'?' · concreto':a.material==='flexivel'?' · asfalto':''),a.points[0],'#f3e6c4')});
 (M.shoulder_marks||[]).forEach(m=>{poly([m.start,m.end]);ctx.strokeStyle=m.enabled===false?'#9aa3a8':'#d9c27a';ctx.lineWidth=Math.max(3,m.width_m*pxPerM());ctx.globalAlpha=.45;ctx.stroke();ctx.globalAlpha=1;for(const [p,t] of [[m.start,'início'],[m.end,'fim']]){const [x,y]=W2C(p);ctx.fillStyle='#d9c27a';ctx.beginPath();ctx.arc(x,y,6,0,7);ctx.fill();label(m.name+' · '+t,p,'#f3e6c4')}});
 (M.hatch_areas||[]).forEach((h,i)=>{if(!h.points||h.points.length<3)return;poly(h.points,true);ctx.save();ctx.clip();ctx.strokeStyle=h.color==='yellow'?'#f4c846aa':'#ffffffaa';ctx.lineWidth=2;const b=h.points.map(p=>W2C(p));const xs=b.map(v=>v[0]),ys=b.map(v=>v[1]);const x0=Math.min(...xs),x1=Math.max(...xs),y0=Math.min(...ys),y1=Math.max(...ys);ctx.beginPath();for(let k=x0-(y1-y0);k<x1;k+=10){ctx.moveTo(k,y1);ctx.lineTo(k+(y1-y0),y0)}ctx.stroke();ctx.restore();poly(h.points,true);ctx.strokeStyle=h.color==='yellow'?'#f4c846':'#fff';ctx.lineWidth=2;ctx.stroke();if(tool==='exedit')for(const p of h.points){const [x,y]=W2C(p);ctx.fillStyle='#fff';ctx.strokeStyle='#555';ctx.lineWidth=2;ctx.beginPath();ctx.rect(x-4,y-4,8,8);ctx.fill();ctx.stroke()}label('▨ '+h.name,h.points[0],'#fff')});
 (M.lane_ranges||[]).forEach(r=>{poly([r.start,r.end]);ctx.strokeStyle='#a78bfa';ctx.lineWidth=4;ctx.setLineDash([10,6]);ctx.stroke();ctx.setLineDash([]);for(const [p,t] of [[r.start,'início'],[r.end,'fim']]){const [x,y]=W2C(p);ctx.fillStyle='#a78bfa';ctx.beginPath();ctx.arc(x,y,6,0,7);ctx.fill();label(`${t} · ${r.lanes} faixas`,p,'#ddd2ff')}});
 (M.accesses||[]).forEach(a=>{if(!a.points||a.points.length<2)return;poly(a.points);ctx.strokeStyle=a.enabled===false?'#9aa3a8':'#ffcf5c';ctx.lineWidth=Math.max(3,a.width_m*pxPerM());ctx.globalAlpha=.45;ctx.stroke();ctx.globalAlpha=1;ctx.lineWidth=2;ctx.setLineDash([8,5]);ctx.stroke();ctx.setLineDash([]);label('🛣 '+a.name+` · tapers ${a.mode!=='out'?a.taper_in_m:0}/${a.mode!=='in'?a.taper_out_m:0} m`,a.points[a.points.length-1],'#ffe7a6')});
 (M.lane_zones||[]).forEach(z=>{if(!z.points||z.points.length<3)return;poly(z.points,true);ctx.fillStyle='#a78bfa22';ctx.fill();ctx.strokeStyle='#a78bfa';ctx.lineWidth=2;ctx.setLineDash([4,4]);ctx.stroke();ctx.setLineDash([]);if(tool==='exedit')for(const p of z.points){const [x,y]=W2C(p);ctx.fillStyle='#fff';ctx.strokeStyle='#a78bfa';ctx.lineWidth=2;ctx.beginPath();ctx.rect(x-4,y-4,8,8);ctx.fill();ctx.stroke()}label('☰ '+z.lanes+' faixa(s)',z.points[0],'#ddd2ff')});
 for(const c of M.crosswalks||[]){poly([c.a,c.b]);ctx.strokeStyle='#ffffff';ctx.lineWidth=Math.max(4,c.width_m*pxPerM());ctx.setLineDash([Math.max(2,.4*pxPerM()),Math.max(2,.6*pxPerM())]);ctx.lineCap='butt';ctx.stroke();ctx.setLineDash([]);ctx.lineCap='round';label('🚶 '+c.name,c.a,'#fff')}
 for(const g of M.signs||[])drawSignIcon(g.point,g.code,g.text,g.show===false);
 for(const z of M.crossing_zones||[]){const [x,y]=W2C(z.point);ctx.beginPath();ctx.arc(x,y,z.radius_m*pxPerM(),0,7);ctx.fillStyle=z.mode==='allow'?'#3fe08a26':'#ff3b3b26';ctx.fill();ctx.strokeStyle=z.mode==='allow'?'#3fe08a':'#ff3b3b';ctx.lineWidth=2;ctx.stroke();label((z.mode==='allow'?'↶ ':'⛔ ')+z.name,z.point,z.mode==='allow'?'#b7f7d2':'#ffc2c2')}
 for(const c of M.cities||[]){const [x,y]=W2C(c.point);ctx.fillStyle=c.show===false?'#889':'#fff';ctx.strokeStyle='#081623';ctx.lineWidth=3;ctx.beginPath();ctx.arc(x,y,6,0,7);ctx.fill();ctx.stroke();ctx.font='bold 14px system-ui';ctx.lineWidth=4;ctx.strokeText(c.name,x+10,y+5);ctx.fillStyle=c.show===false?'#aab':'#fff';ctx.fillText(c.name,x+10,y+5)}
 for(const z of M.no_connection_zones){if(z.kind==='point'){const [x,y]=W2C(z.point);ctx.beginPath();ctx.arc(x,y,z.radius_m*pxPerM(),0,7)}else poly(z.points,true);ctx.fillStyle='#ff3b5c22';ctx.fill();ctx.strokeStyle='#ff3b5c';ctx.lineWidth=2;ctx.setLineDash([8,5]);ctx.stroke();ctx.setLineDash([]);label('✕ '+z.name,z.kind==='point'?z.point:z.points[0],'#ff9fb0')}
 for(const o of M.oae_marks){if(!(o.polygon&&o.polygon.length>=4))continue;poly(o.polygon,true);ctx.fillStyle='#d9dcd6aa';ctx.fill();ctx.strokeStyle='#5ad8ff';ctx.lineWidth=2;ctx.stroke();
  if(tool==='exedit')for(const p of o.polygon){const [x,y]=W2C(p);ctx.fillStyle='#fff';ctx.strokeStyle='#1d7fa3';ctx.lineWidth=2;ctx.beginPath();ctx.rect(x-4,y-4,8,8);ctx.fill();ctx.stroke()}
  if(o.direction&&o.direction!=='both'&&o.start&&o.end){let a=o.start,b=o.end;const ka=kmOf(a)?.km,kb=kmOf(b)?.km;if(ka!=null&&kb!=null&&kb<ka)[a,b]=[b,a];if(o.direction==='decreasing')[a,b]=[b,a];const m1={x:a.x+(b.x-a.x)*.3,y:a.y+(b.y-a.y)*.3},m2={x:a.x+(b.x-a.x)*.7,y:a.y+(b.y-a.y)*.7};poly([m1,m2]);ctx.strokeStyle='#0b3d5c';ctx.lineWidth=5;ctx.stroke();arrowHead(m1,m2,16,'#0b3d5c')}
  const ka=o.km_start_override_m??kmOf(o.start)?.km,kb=o.km_end_override_m??kmOf(o.end)?.km;label(`${o.name}`+(ka!=null?` · km ${formatKm(Math.min(ka,kb))}–${formatKm(Math.max(ka,kb))}`:'')+` · nível ${o.level_m} m`,o.polygon[0],'#eef')}
 if(ad)for(const o of M.oae_marks){if(o.polygon&&o.polygon.length>=4)continue;const ra=projectAxis(o.start),rb=projectAxis(o.end);if(!ra||!rb)continue;const pts=axisSub(ra.s,rb.s);poly(pts);ctx.strokeStyle='#d9dcd6cc';ctx.lineWidth=Math.max(4,o.width_m*pxPerM());ctx.lineCap='butt';ctx.stroke();ctx.lineCap='round';ctx.strokeStyle='#5b6166';ctx.lineWidth=1.5;ctx.stroke();const a=o.km_start_override_m??(cfg.km_start_m+Math.min(ra.s,rb.s)-s0()),b=o.km_end_override_m??(cfg.km_start_m+Math.max(ra.s,rb.s)-s0());label(`${o.name} · km ${formatKm(a)}–${formatKm(b)} · nível ${o.level_m} m`,pts[0],'#eef')}
 if(axisData())for(const p of M.pois){if(p.kind!=='passarela')continue;const g=spanGeom(p);poly([g.a,g.b]);ctx.strokeStyle='#081623';ctx.lineWidth=Math.max(5,(p.bridge_width_m||3)*pxPerM()+3);ctx.lineCap='butt';ctx.stroke();ctx.strokeStyle='#d9dcd6';ctx.lineWidth=Math.max(3,(p.bridge_width_m||3)*pxPerM());ctx.stroke();ctx.lineCap='round';for(const q of [g.a,g.b]){const [qx,qy]=W2C(q);ctx.fillStyle=tool==='span'?'#ffcf5c':'#d9dcd6';ctx.beginPath();ctx.arc(qx,qy,5,0,7);ctx.fill()}if(pxPerM()>.3)label(`vão ${Math.round(p.bridge_span_m||38)} m`,g.b,'#eef')}
 for(const p of M.pois){const [x,y]=W2C(p);if(p.anchor){const [ax,ay]=W2C(p.anchor);ctx.strokeStyle='#86dce9';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(ax,ay);ctx.stroke();ctx.fillStyle='#86dce9';ctx.beginPath();ctx.moveTo(ax,ay-7);ctx.lineTo(ax+7,ay);ctx.lineTo(ax,ay+7);ctx.lineTo(ax-7,ay);ctx.closePath();ctx.fill()}ctx.beginPath();ctx.arc(x,y,7,0,7);ctx.fillStyle='#79e6d0';ctx.fill();ctx.strokeStyle='#081623';ctx.lineWidth=2;ctx.stroke();if(pxPerM()>.15)label(p.title,p,'#cff')}
 const res=alignResult?.residuals_m||[];M.dxf_alignment.pairs.forEach((p,i)=>{const r=editor?.alignment&&M.dxf_alignment.applied?editor.alignment:null;const shown=r?fwdAlign(p.dxf,r):p.dxf;poly([shown,p.image]);ctx.strokeStyle=p.enabled?'#4fa3ff':'#888';ctx.lineWidth=2;ctx.stroke();arrowHead(shown,p.image,10,ctx.strokeStyle);const [x,y]=W2C(shown);ctx.fillStyle='#4fa3ff';ctx.fillRect(x-4,y-4,8,8);const [u,v]=W2C(p.image);ctx.fillStyle='#ff5a5a';ctx.beginPath();ctx.arc(u,v,5,0,7);ctx.fill();label(`P${i+1}`+(res[i]!=null?` · ${res[i].toFixed(2)} m`:''),p.image,'#bcd')});
 if(M.cabin&&M.cabin.start){const [x,y]=W2C(M.cabin.start);ctx.fillStyle='#ffef7a';ctx.strokeStyle='#081623';ctx.lineWidth=2;ctx.beginPath();ctx.rect(x-7,y-5,14,10);ctx.fill();ctx.stroke();label('Cabine',M.cabin.start,'#ffef7a')}
 for(const h of M.highlights||[]){const st=HL_STYLE[h.category]||HL_STYLE.outro,col=h.color||st[0];const [x,y]=W2C(h.point);let [bx,by]=h.label?W2C(h.label):[x+60,y-60];ctx.strokeStyle=col;ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(bx,by);ctx.stroke();ctx.fillStyle=col;ctx.beginPath();ctx.arc(x,y,8,0,7);ctx.fill();ctx.fillStyle='#0a1620';ctx.font='bold 10px system-ui';ctx.fillText(st[1],x-3,y+4);ctx.font='bold 12px system-ui';const tw=ctx.measureText(h.name).width+16;ctx.fillStyle='#081623e6';ctx.fillRect(bx-tw/2,by-12,tw,24);ctx.strokeStyle=col;ctx.strokeRect(bx-tw/2,by-12,tw,24);ctx.fillStyle='#fff';ctx.fillText(h.name,bx-tw/2+8,by+4)}
 if(layerShow&&layerShow.p){ctx.save();ctx.strokeStyle='#ff4fd8';ctx.lineWidth=4;ctx.shadowColor='#000';ctx.shadowBlur=4;for(const q of layerShow.p){poly(q.map(v=>({x:v[0],y:v[1]})));ctx.stroke()}ctx.restore()}
 // rascunhos
 if(draft){const pts=draft.pts.slice();if(lastWorld&&['flowadd','exvert','noconnarea','oaepoly','block','hatch','lanes','crosswalk','access','lanerange','pavarea','shoulder'].includes(draft.type))pts.push(lastWorld);poly(pts,draft.type!=='flowadd');ctx.strokeStyle=draft.type==='flowadd'?'#e78bff':'#ffcf5c';ctx.lineWidth=2.5;ctx.setLineDash([6,4]);ctx.stroke();ctx.setLineDash([]);for(const p of draft.pts){const [x,y]=W2C(p);ctx.fillStyle='#fff';ctx.beginPath();ctx.arc(x,y,4,0,7);ctx.fill()}if(draft.fail){const [x,y]=W2C(P(draft.fail));ctx.strokeStyle='#ff3030';ctx.lineWidth=3;ctx.beginPath();ctx.arc(x,y,12,0,7);ctx.stroke()}}
 if(drag?.type==='chain'&&(drag.moved||0)>12){poly([drag.start,drag.end]);ctx.strokeStyle='#ffd56b';ctx.lineWidth=4;ctx.stroke();arrowHead(drag.start,drag.end,14,'#ffd56b')}
 if(drag?.type==='hlnew'&&(drag.moved||0)>12){poly([drag.start,drag.end]);ctx.strokeStyle='#ff8a3d';ctx.lineWidth=2;ctx.stroke()}
 if(drag?.type==='arrowrot'&&(drag.moved||0)>10){poly([drag.start,drag.end]);ctx.strokeStyle='#ffffff';ctx.lineWidth=3;ctx.stroke();arrowHead(drag.start,drag.end,14,'#ffffff')}
 if(drag?.type==='dir'){poly([drag.start,drag.end]);ctx.strokeStyle='#ffe14d';ctx.lineWidth=4;ctx.stroke();arrowHead(drag.start,drag.end,14,'#ffe14d')}
 if(drag?.type==='lasso'){poly(drag.pts);ctx.strokeStyle='#ffcf5c';ctx.lineWidth=2;ctx.stroke()}
 // escala gráfica
 const ppm=pxPerM();let len=[1,2,5,10,20,50,100,200,500,1000,2000,5000].find(v=>v*ppm>90)||5000;ctx.fillStyle='#081623cc';ctx.fillRect(10,canvas.height-34,len*ppm+20,24);ctx.fillStyle='#fff';ctx.fillRect(20,canvas.height-18,len*ppm,4);ctx.font='11px system-ui';ctx.fillText(len+' m',20,canvas.height-22);
 if(useGeo()&&baseMode==='map'){const wi=cfg.web_imagery||{},t='Imagem: '+(webSrc()==='wayback'?'Esri World Imagery Wayback '+(wi.wayback_label||''):webSrc()!=='esri'?(wi.attribution||'fonte indicada pelo usuário'):geo.attribution)+(tileState.fail&&!tileState.ok?' · sem internet/cache nesta área':'');ctx.font='11px system-ui';const w=ctx.measureText(t).width+12;ctx.fillStyle='#081623b0';ctx.fillRect(canvas.width-w-6,canvas.height-22,w,18);ctx.fillStyle='#dfe';ctx.fillText(t,canvas.width-w,canvas.height-9)}}

function drawSignIcon(p,code,text,dim){const [x,y]=W2C(p),st=SIGN_STYLE[code]||SIGN_STYLE.I,r=10;ctx.save();ctx.globalAlpha=dim?.45:1;ctx.strokeStyle='#081623';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x,y-14);ctx.stroke();const cy=y-14-r;ctx.beginPath();
 if(code==='R-1'){for(let k=0;k<8;k++){const a=Math.PI/8+k*Math.PI/4;ctx.lineTo(x+r*Math.cos(a),cy+r*Math.sin(a))}ctx.closePath()}else if(code==='R-2'){ctx.moveTo(x-r,cy-r*.8);ctx.lineTo(x+r,cy-r*.8);ctx.lineTo(x,cy+r);ctx.closePath()}else if(code==='R-19'){ctx.arc(x,cy,r,0,7)}else if(code==='A'||code==='OBRAS'){ctx.moveTo(x,cy-r);ctx.lineTo(x+r,cy);ctx.lineTo(x,cy+r);ctx.lineTo(x-r,cy);ctx.closePath()}else{ctx.rect(x-r*1.4,cy-r*.7,r*2.8,r*1.4)}
 ctx.fillStyle=st[0];ctx.fill();ctx.strokeStyle=code==='R-2'||code==='R-19'?'#c81e24':'#081623';ctx.lineWidth=2;ctx.stroke();ctx.fillStyle=st[1];ctx.font='bold 8px system-ui';ctx.textAlign='center';ctx.fillText(code==='R-1'?'PARE':code==='R-19'?(text||'80').slice(0,3):code==='A'?(text?'':'!'):'',x,cy+3);ctx.textAlign='start';if(text&&code!=='R-19')label(text,{x:p.x,y:p.y},'#fff');ctx.restore()}
/* ---------- Lista de marcações (editar / excluir) ---------- */
function refreshLists(){const L=[];const kmTxt=p=>{if(!axisData())return '';const k=kmOf(p);return k?formatKm(k.km):''};
 const row=(cells,key)=>`<tr data-key="${key}" class="${selected===key?'sel':''}">${cells}</tr>`;
 L.push('<div class="marks">');
 {const c=M.chainage,st=editor?station():null,diff=st?st.kmEndGeo-cfg.km_end_m:0;
  L.push(`<h3>Estaqueamento (km)</h3><div class="grid"><label>Modo<select data-f="chainage.mode"><option value="off" ${c.mode==='off'?'selected':''}>Desligado (km só quando digitado)</option><option value="auto" ${c.mode==='auto'?'selected':''}>Automático (início do eixo, sentido do eixo)</option><option value="manual" ${c.mode==='manual'?'selected':''}>Manual (início/fim/sentido no mapa)</option></select></label><label><input type="checkbox" data-f="chainage.calibrate" ${c.calibrate?'checked':''}> Ajuste proporcional ao km final (precisa de início e fim)</label></div>`);
  L.push(`<p class="muted">${c.mode==='manual'?(c.start?`Início: X ${c.start.x.toFixed(2)} Y ${c.start.y.toFixed(2)} = km ${formatKm(cfg.km_start_m)} <button data-act="chain-del">Excluir início</button> `:'Use a ferramenta “Início do km”. ')+(c.end?`Fim: X ${c.end.x.toFixed(2)} Y ${c.end.y.toFixed(2)} <button data-act="chain-end-del">Excluir fim</button> `:'Fim opcional: ferramenta “Fim do km”. '):c.mode==='auto'?'Km a partir do início geométrico do eixo (use “Inverter início e fim do eixo” na configuração se o km cresce no outro sentido). ':'Intervenções usam só o km digitado (comportamento da 1.2). '}${st&&c.mode!=='off'?`<br>Sentido: ${st.dir>0?'o do eixo':'contrário ao eixo'} · fator ${st.scale.toFixed(5)} · km no fim do trecho medido: <b>${formatKm(st.kmEndGeo)}</b> (informado ${formatKm(cfg.km_end_m)}, diferença ${diff>=0?'+':''}${diff.toFixed(1)} m) <button data-act="chain-flip">Inverter sentido</button> <button data-act="chain-kmend">Usar km final medido</button>`:''}</p>`)}
 if(M.oae_marks.length){L.push('<h3>OAE marcadas</h3><table>');M.oae_marks.forEach((o,i)=>{const ka=kmTxt(o.start),kb=kmTxt(o.end);L.push(row(`<td><input data-f="oae.${i}.name" value="${esc(o.name)}"></td><td>km ${ka}–${kb}<br><input data-f="oae.${i}.km_start_override_m" data-km placeholder="km inicial manual" value="${formatKm(o.km_start_override_m)}"><input data-f="oae.${i}.km_end_override_m" data-km placeholder="km final manual" value="${formatKm(o.km_end_override_m)}"></td><td>nível (m)<input type="number" step="0.5" data-f="oae.${i}.level_m" value="${o.level_m}">largura<input type="number" data-f="oae.${i}.width_m" value="${o.width_m}"></td><td><select data-f="oae.${i}.direction"><option value="both" ${(o.direction||'both')==='both'?'selected':''}>dois sentidos</option><option value="growing" ${o.direction==='growing'?'selected':''}>crescente</option><option value="decreasing" ${o.direction==='decreasing'?'selected':''}>decrescente</option></select><small>${o.polygon&&o.polygon.length>=4?o.polygon.length+' vértices <button data-act="editoae" data-i="'+i+'">Editar vértices</button>':'2 pontos'}</small><label><input type="checkbox" data-f="oae.${i}.callout" ${o.callout?'checked':''}> chamada</label><button data-act="del" data-list="oae_marks" data-i="${i}">Excluir</button></td>`,'oae'+i))});L.push('</table>')}
 if(M.direction_marks.length){L.push('<h3>Setas de sentido</h3><table>');M.direction_marks.forEach((d,i)=>L.push(row(`<td>Seta ${i+1} · km ${kmTxt({x:(d.start.x+d.end.x)/2,y:(d.start.y+d.end.y)/2})}</td><td><button data-act="flip-dir" data-i="${i}">Inverter seta</button> <button data-act="zoom" data-x="${d.start.x}" data-y="${d.start.y}">Ver</button> <button data-act="del" data-list="direction_marks" data-i="${i}">Excluir</button></td>`,'dir'+i)));L.push('</table>')}
 if(M.flow_overrides.length){L.push('<h3>Fluxos invertidos / desativados</h3><table>');M.flow_overrides.forEach((o,i)=>L.push(row(`<td>${o.action==='reverse'?'Inversão':'Desativação'} · km ${kmTxt(o)}</td><td><label><input type="checkbox" data-f="flow.${i}.enabled" ${o.enabled?'checked':''}> ativa</label> <button data-act="zoom" data-x="${o.x}" data-y="${o.y}">Ver</button> <button data-act="del" data-list="flow_overrides" data-i="${i}">Excluir</button></td>`,'fo'+i)));L.push('</table>')}
 if(M.traffic_paths.length){L.push('<h3>Fluxos incluídos</h3><table>');M.traffic_paths.forEach((p,i)=>L.push(row(`<td><input data-f="path.${i}.name" value="${esc(p.name)}"></td><td>${p.points.length} pontos · ${esc(p.kind)}</td><td><label><input type="checkbox" data-f="path.${i}.enabled" ${p.enabled!==false?'checked':''}> ativo</label> <button data-act="zoom" data-x="${p.points[0].x}" data-y="${p.points[0].y}">Ver</button> <button data-act="del" data-list="traffic_paths" data-i="${i}">Excluir</button></td>`,'tp'+i)));L.push('</table>')}
 if(M.exclusions.length){L.push('<h3>Áreas de exclusão</h3><table>');M.exclusions.forEach((a,i)=>L.push(row(`<td>Área ${i+1} · ${a.length} vértices</td><td><button data-act="editex" data-i="${i}">Editar vértices</button> <button data-act="zoom" data-x="${a[0].x}" data-y="${a[0].y}">Ver</button> <button data-act="del" data-list="exclusions" data-i="${i}">Excluir</button></td>`,'ex'+i)));L.push('</table>')}
 if((M.clean_areas||[]).length){L.push('<h3>Áreas sem sinalização (limpeza de pinturas e setas)</h3><table>');M.clean_areas.forEach((a,i)=>L.push(row(`<td>Área ${i+1} · ${a.length} vértices</td><td><button data-act="editca" data-i="${i}">Editar vértices</button> <button data-act="zoom" data-x="${a[0].x}" data-y="${a[0].y}">Ver</button> <button data-act="del" data-list="clean_areas" data-i="${i}">Excluir</button></td>`,'ca'+i)));L.push('</table>')}
 if((M.lane_blocks||[]).length){L.push('<h3>Interdições de faixa</h3><table>');M.lane_blocks.forEach((b,i)=>L.push(row(`<td><input data-f="blk.${i}.name" value="${esc(b.name)}"><select data-f="blk.${i}.mode"><option value="partial" ${b.mode==='partial'?'selected':''}>parcial</option><option value="total" ${b.mode==='total'?'selected':''}>total</option></select></td><td>km/h<input type="number" data-f="blk.${i}.speed_kmh" value="${b.speed_kmh}">início (s)<input type="number" data-f="blk.${i}.start_s" value="${b.start_s}">fim (s)<input type="number" data-f="blk.${i}.end_s" value="${b.end_s??''}" placeholder="até o fim"></td><td><label><input type="checkbox" data-f="blk.${i}.show" ${b.show!==false?'checked':''}> no vídeo</label><button data-act="editblk" data-i="${i}">Editar vértices</button> <button data-act="zoom" data-x="${b.points[0].x}" data-y="${b.points[0].y}">Ver</button> <button data-act="del" data-list="lane_blocks" data-i="${i}">Excluir</button></td>`,'blk'+i)));L.push('</table>')}
 if((M.crossing_zones||[]).length){L.push('<h3>Travessias do canteiro</h3><table>');M.crossing_zones.forEach((z,i)=>L.push(row(`<td><input data-f="cz.${i}.name" value="${esc(z.name)}"></td><td><select data-f="cz.${i}.mode"><option value="allow" ${z.mode==='allow'?'selected':''}>permitida</option><option value="deny" ${z.mode==='deny'?'selected':''}>proibida</option></select> raio <input type="number" data-f="cz.${i}.radius_m" value="${z.radius_m}"></td><td><button data-act="zoom" data-x="${z.point.x}" data-y="${z.point.y}">Ver</button> <button data-act="del" data-list="crossing_zones" data-i="${i}">Excluir</button></td>`,'cz'+i)));L.push('</table>')}
 if((M.signs||[]).length){L.push('<h3>Placas</h3><table>');M.signs.forEach((g,i)=>L.push(row(`<td><select data-f="sg.${i}.code">${Object.entries(SIGN_LABEL).map(([k,v])=>`<option value="${k}" ${g.code===k?'selected':''}>${v}</option>`).join('')}</select><input data-f="sg.${i}.text" maxlength="40" placeholder="texto" value="${esc(g.text||'')}"></td><td>km ${kmTxt(g.point)}</td><td><label><input type="checkbox" data-f="sg.${i}.show" ${g.show!==false?'checked':''}> no vídeo</label> <button data-act="zoom" data-x="${g.point.x}" data-y="${g.point.y}">Ver</button> <button data-act="del" data-list="signs" data-i="${i}">Excluir</button></td>`,'sg'+i)));L.push('</table>')}
 if((M.crosswalks||[]).length){L.push('<h3>Faixas de pedestre</h3><table>');M.crosswalks.forEach((c,i)=>L.push(row(`<td><input data-f="cw.${i}.name" value="${esc(c.name)}"></td><td>largura (m)<input type="number" step="0.5" data-f="cw.${i}.width_m" value="${c.width_m}"> km ${kmTxt(c.a)}</td><td><label><input type="checkbox" data-f="cw.${i}.show" ${c.show!==false?'checked':''}> no vídeo</label> <button data-act="zoom" data-x="${c.a.x}" data-y="${c.a.y}">Ver</button> <button data-act="del" data-list="crosswalks" data-i="${i}">Excluir</button></td>`,'cw'+i)));L.push('</table>')}
 if((M.hatch_areas||[]).length){L.push('<h3>Zebrados</h3><table>');M.hatch_areas.forEach((h,i)=>L.push(row(`<td><input data-f="ha.${i}.name" value="${esc(h.name)}"><select data-f="ha.${i}.color"><option value="white" ${h.color!=='yellow'?'selected':''}>branco</option><option value="yellow" ${h.color==='yellow'?'selected':''}>amarelo</option></select></td><td>ângulo (°)<input type="number" data-f="ha.${i}.angle_deg" value="${h.angle_deg??''}" placeholder="automático">espaçamento (m)<input type="number" step="0.1" data-f="ha.${i}.spacing_m" value="${h.spacing_m}"></td><td><button data-act="editha" data-i="${i}">Editar vértices</button> <button data-act="zoom" data-x="${h.points[0].x}" data-y="${h.points[0].y}">Ver</button> <button data-act="del" data-list="hatch_areas" data-i="${i}">Excluir</button></td>`,'ha'+i)));L.push('</table>')}
 if((M.pavement_areas||[]).length){L.push('<h3>Áreas de pista (hachura)</h3><table>');M.pavement_areas.forEach((a,i)=>L.push(row(`<td><input data-f="pav.${i}.name" value="${esc(a.name)}"><select data-f="pav.${i}.kind">${Object.entries(PAV_LABEL).map(([k,v])=>`<option value="${k}" ${a.kind===k?'selected':''}>${v}</option>`).join('')}</select><select data-f="pav.${i}.material">${Object.entries(MAT_LABEL).map(([k,v])=>`<option value="${k}" ${(a.material||'auto')===k?'selected':''}>${v}</option>`).join('')}</select></td><td>${a.points.length} vértices · ${a.source==='picked'?'selecionada':'desenhada'}</td><td><label><input type="checkbox" data-f="pav.${i}.enabled" ${a.enabled!==false?'checked':''}> ativa</label> <button data-act="editpav" data-i="${i}">Editar vértices</button> <button data-act="zoom" data-x="${a.points[0].x}" data-y="${a.points[0].y}">Ver</button> <button data-act="del" data-list="pavement_areas" data-i="${i}">Excluir</button></td>`,'pav'+i)));L.push('</table>')}
 if((M.shoulder_marks||[]).length){L.push('<h3>Acostamentos (início/fim)</h3><table>');M.shoulder_marks.forEach((m,i)=>L.push(row(`<td><input data-f="sh.${i}.name" value="${esc(m.name)}"></td><td>largura (m)<input type="number" min="0.5" max="6" step="0.1" data-f="sh.${i}.width_m" value="${m.width_m}"> km ${kmTxt(m.start)} a ${kmTxt(m.end)}</td><td><label><input type="checkbox" data-f="sh.${i}.enabled" ${m.enabled!==false?'checked':''}> ativo</label> <button data-act="zoom" data-x="${m.start.x}" data-y="${m.start.y}">Início</button> <button data-act="zoom" data-x="${m.end.x}" data-y="${m.end.y}">Fim</button> <button data-act="del" data-list="shoulder_marks" data-i="${i}">Excluir</button></td>`,'sh'+i)));L.push('</table>')}
 if((M.lane_ranges||[]).length){L.push('<h3>Faixas adicionais (início/fim)</h3><table>');M.lane_ranges.forEach((r,i)=>L.push(row(`<td><input data-f="lr.${i}.name" value="${esc(r.name)}"></td><td>faixas por sentido<input type="number" min="1" max="6" data-f="lr.${i}.lanes" value="${r.lanes}"> km ${kmTxt(r.start)} a ${kmTxt(r.end)}</td><td><button data-act="zoom" data-x="${r.start.x}" data-y="${r.start.y}">Início</button> <button data-act="zoom" data-x="${r.end.x}" data-y="${r.end.y}">Fim</button> <button data-act="del" data-list="lane_ranges" data-i="${i}">Excluir</button></td>`,'lr'+i)));L.push('</table>')}
 if((M.accesses||[]).length){L.push('<h3>Acessos com taper</h3><table>');M.accesses.forEach((a,i)=>L.push(row(`<td><input data-f="ac.${i}.name" value="${esc(a.name)}"><select data-f="ac.${i}.mode"><option value="both" ${a.mode==='both'?'selected':''}>entrada e saída</option><option value="in" ${a.mode==='in'?'selected':''}>só entrada</option><option value="out" ${a.mode==='out'?'selected':''}>só saída</option></select></td><td>largura<input type="number" step="0.5" data-f="ac.${i}.width_m" value="${a.width_m}">taper entrada<input type="number" data-f="ac.${i}.taper_in_m" value="${a.taper_in_m}">taper saída<input type="number" data-f="ac.${i}.taper_out_m" value="${a.taper_out_m}"></td><td><label><input type="checkbox" data-f="ac.${i}.enabled" ${a.enabled!==false?'checked':''}> ativo</label> <button data-act="zoom" data-x="${a.points[0].x}" data-y="${a.points[0].y}">Ver</button> <button data-act="del" data-list="accesses" data-i="${i}">Excluir</button></td>`,'ac'+i)));L.push('</table>')}
 if((M.lane_zones||[]).length){L.push('<h3>Faixas por trecho</h3><table>');M.lane_zones.forEach((z,i)=>L.push(row(`<td><input data-f="lz.${i}.name" value="${esc(z.name)}"></td><td>faixas<input type="number" min="1" max="6" data-f="lz.${i}.lanes" value="${z.lanes}"></td><td><button data-act="editlz" data-i="${i}">Editar vértices</button> <button data-act="zoom" data-x="${z.points[0].x}" data-y="${z.points[0].y}">Ver</button> <button data-act="del" data-list="lane_zones" data-i="${i}">Excluir</button></td>`,'lz'+i)));L.push('</table>')}
 L.push('<h3>Cidades próximas</h3><p class="muted">Aparecem no vídeo com o nome; fora do quadro, uma seta na borda indica a direção e a distância. <button data-act="city-auto">Buscar cidades próximas (OpenStreetMap)</button></p>');if((M.cities||[]).length){L.push('<table>');M.cities.forEach((c,i)=>L.push(row(`<td><input data-f="city.${i}.name" value="${esc(c.name)}"></td><td>${c.source==='auto'?'OSM'+(c.kind?' · '+esc(c.kind):''):'manual'}</td><td><label><input type="checkbox" data-f="city.${i}.show" ${c.show!==false?'checked':''}> no vídeo</label> <button data-act="zoom" data-x="${c.point.x}" data-y="${c.point.y}">Ver</button> <button data-act="del" data-list="cities" data-i="${i}">Excluir</button></td>`,'ci'+i)));L.push('</table>')}
 if(M.no_connection_zones.length){L.push('<h3>Cruzamentos sem conexão</h3><table>');M.no_connection_zones.forEach((z,i)=>L.push(row(`<td><input data-f="zone.${i}.name" value="${esc(z.name)}"></td><td>${z.kind==='point'?`raio <input type="number" data-f="zone.${i}.radius_m" value="${z.radius_m}">`:z.points.length+' vértices'}</td><td><button data-act="zoom" data-x="${z.kind==='point'?z.point.x:z.points[0].x}" data-y="${z.kind==='point'?z.point.y:z.points[0].y}">Ver</button> <button data-act="del" data-list="no_connection_zones" data-i="${i}">Excluir</button></td>`,'z'+i)));L.push('</table>')}
 if((M.highlights||[]).length){L.push('<h3>Destaques (pontos especiais)</h3><table>');M.highlights.forEach((h,i)=>L.push(row(`<td><input data-f="hl.${i}.name" value="${esc(h.name)}"><select data-f="hl.${i}.category">${Object.entries(HL_LABEL).map(([k,v])=>`<option value="${k}" ${h.category===k?'selected':''}>${v}</option>`).join('')}</select><input data-f="hl.${i}.description" placeholder="descrição" value="${esc(h.description)}"></td><td>km ${kmTxt(h.point)}<br><input type="color" data-f="hl.${i}.color" value="${h.color||(HL_STYLE[h.category]||HL_STYLE.outro)[0]}"></td><td><label><input type="checkbox" data-f="hl.${i}.show_in_video" ${h.show_in_video!==false?'checked':''}> no vídeo</label><label><input type="checkbox" data-f="hl.${i}.stop" ${h.stop?'checked':''}> parada da câmera</label><label><input type="checkbox" data-f="hl.${i}.show_km" ${h.show_km!==false?'checked':''}> mostrar km</label><button data-act="hl-auto" data-i="${i}">Caixa automática</button> <button data-act="zoom" data-x="${h.point.x}" data-y="${h.point.y}">Ver</button> <button data-act="del" data-list="highlights" data-i="${i}">Excluir</button></td>`,'hl'+i)));L.push('</table>')}
 const anch=M.pois.filter(p=>p.anchor);if(anch.length){L.push('<h3>Linhas de chamada</h3><table>');anch.forEach(p=>{const i=M.pois.indexOf(p);L.push(row(`<td>${esc(p.title)}</td><td><button data-act="zoom" data-x="${p.anchor.x}" data-y="${p.anchor.y}">Ver</button> <button data-act="anchor-del" data-i="${i}">Excluir âncora</button></td>`,'an'+i))});L.push('</table>')}
 L.push('</div>');$('markList').innerHTML=L.join('');
 $('pathList').innerHTML='';showPois();showPairs();$('alignState').value=M.dxf_alignment.applied?'Aplicado ao DXF (em memória)':'Não aplicado';if(typeof cabinUi==='function'&&$('cabinState'))try{cabinUi()}catch{}}
$('markList').addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;const i=Number(b.dataset.i),act=b.dataset.act;
 if(act==='del'){checkpoint();M[b.dataset.list].splice(i,1);selected=null;changed('Item excluído.')}
 else if(act==='flip-dir'){checkpoint();const d=M.direction_marks[i];[d.start,d.end]=[d.end,d.start];changed('Seta invertida.')}
 else if(act==='chain-del'){checkpoint();M.chainage={...M.chainage,start:null};changed('Início do estaqueamento removido.')}
 else if(act==='chain-end-del'){checkpoint();M.chainage={...M.chainage,end:null};changed('Fim do estaqueamento removido.')}
 else if(act==='chain-flip'){checkpoint();const c=M.chainage;if(c.end&&c.start)M.chainage={...c,start:c.end,end:c.start};else M.chainage={...c,direction:-(c.direction||1)};changed('Sentido do estaqueamento invertido.')}
 else if(act==='chain-kmend'){const st=station();$('km_end_m').value=formatKm(st.kmEndGeo);cfg.km_end_m=st.kmEndGeo;scheduleSave();refreshLists();msg('Km final preenchido pela distância medida no eixo: '+formatKm(st.kmEndGeo)+'.')}
 else if(act==='hl-auto'){checkpoint();M.highlights[i].label=null;changed('Caixa do destaque em posição automática.')}
 else if(act==='anchor-del'){checkpoint();M.pois[i].anchor=null;changed('Âncora removida: volta ao comportamento automático.')}
 else if(act==='editpav'){selected='pav'+i;setTool('exedit');zoomTo(M.pavement_areas[i].points[0])}
 else if(act==='editha'){selected='ha'+i;setTool('exedit');zoomTo(M.hatch_areas[i].points[0])}
 else if(act==='editlz'){selected='lz'+i;setTool('exedit');zoomTo(M.lane_zones[i].points[0])}
 else if(act==='editblk'){selected='blk'+i;setTool('exedit');zoomTo(M.lane_blocks[i].points[0])}
 else if(act==='editoae'){selected='oae'+i;setTool('exedit');zoomTo(M.oae_marks[i].polygon[0])}
 else if(act==='editca'){selected='ca'+i;setTool('exedit');zoomTo({x:M.clean_areas[i][0].x,y:M.clean_areas[i][0].y})}
 else if(act==='city-auto'){cityAuto()}
 else if(act==='editex'){selected='ex'+i;setTool('exedit');zoomTo({x:M.exclusions[i][0].x,y:M.exclusions[i][0].y})}
 else if(act==='zoom'){zoomTo({x:Number(b.dataset.x),y:Number(b.dataset.y)})}});
$('markList').addEventListener('change',e=>{const f=e.target.dataset.f;if(!f)return;const [kind,i,key]=f.split('.');if(kind==='chainage'){checkpoint();M.chainage={...M.chainage,[i]:e.target.type==='checkbox'?e.target.checked:e.target.value};changed();return}
 const list={oae:M.oae_marks,flow:M.flow_overrides,path:M.traffic_paths,zone:M.no_connection_zones,hl:M.highlights,city:M.cities,blk:M.lane_blocks,cz:M.crossing_zones,sg:M.signs,cw:M.crosswalks,ha:M.hatch_areas,lz:M.lane_zones,ac:M.accesses,lr:M.lane_ranges,pav:M.pavement_areas,sh:M.shoulder_marks}[kind];if(!list)return;checkpoint();let v=e.target.type==='checkbox'?e.target.checked:e.target.type==='number'?Number(e.target.value):e.target.value;if(e.target.dataset.km!==undefined){try{v=e.target.value.trim()?parseKm(e.target.value):null}catch(err){msg(err.message,true);return}}if(kind==='blk'&&key==='end_s'&&e.target.value==='')v=null;if(kind==='ha'&&key==='angle_deg'&&e.target.value==='')v=null;if((kind==='lz'||kind==='lr')&&key==='lanes')v=Math.max(1,Math.min(6,Math.round(v)||1));list[Number(i)][key]=v;setTimeout(()=>changed(),0)});
async function cityAuto(){try{requireProject();if(!analysis)throw Error('Analise os arquivos antes de buscar as cidades.');msg('Buscando cidades próximas no OpenStreetMap…');const r=await api(`/api/projects/${pid}/cities/auto?radius_km=${Number($('cities_radius_km')?.value||25)}`);
 const have=new Set((M.cities||[]).map(c=>c.name.toLowerCase()));const add=r.cities.filter(c=>!have.has(c.name.toLowerCase()));if(!add.length)return msg(r.cities.length?'As cidades encontradas já estão na lista.':'Nenhuma cidade encontrada no raio informado.');
 checkpoint();for(const c of add)M.cities.push({id:uid(),name:c.name,point:{x:c.x,y:c.y},kind:c.kind,population:c.population,source:'auto',show:true});changed(`${add.length} cidade(s) adicionada(s): ${add.map(c=>c.name).join(', ')}. Renomeie, oculte ou exclua na lista.`)}catch(e){msg(e.message,true)}}
function zoomTo(w){if(!ready())return;const [x,y]=worldToImg(w);const s=Math.max(view.s,useGeo()?canvas.width*geo.mpp_crs/150:2*canvas.width/baseImage.width);view.s=s;view.ox=canvas.width/2-x*s;view.oy=canvas.height/2-y*s;draw()}

/* ---------- Ajuste DXF × imagem ---------- */
function showPairs(){const res=alignResult?.residuals_m||[];$('pairList').innerHTML=M.dxf_alignment.pairs.length?'<table>'+M.dxf_alignment.pairs.map((p,i)=>`<tr><td>P${i+1}</td><td>DXF ${p.dxf.x.toFixed(2)}, ${p.dxf.y.toFixed(2)}<br>Imagem ${p.image.x.toFixed(2)}, ${p.image.y.toFixed(2)}</td><td>${res[i]!=null?'resíduo '+res[i].toFixed(3)+' m':''}</td><td><label><input type="checkbox" data-pair="${i}" ${p.enabled?'checked':''}> usar</label> <button data-pair-del="${i}">Excluir</button></td></tr>`).join('')+'</table>':'<p class="muted">Nenhum par cadastrado.</p>'}
$('pairList').addEventListener('change',e=>{if(e.target.dataset.pair===undefined)return;checkpoint();M.dxf_alignment.pairs[Number(e.target.dataset.pair)].enabled=e.target.checked;changed();fitAlign(false)});
$('pairList').addEventListener('click',e=>{if(e.target.dataset.pairDel===undefined)return;checkpoint();M.dxf_alignment.pairs.splice(Number(e.target.dataset.pairDel),1);changed('Par excluído.');fitAlign(false)});
async function fitAlign(report=true){try{alignResult=await api('/api/alignment/fit',json('POST',{mode:$('alignMode').value,pairs:M.dxf_alignment.pairs}));$('alignResult').textContent=`${alignResult.mode==='translation'?'Translação':'Similaridade'}: dx ${alignResult.tx.toFixed(3)} m, dy ${alignResult.ty.toFixed(3)} m`+(alignResult.mode==='similarity'?`, rotação ${alignResult.rotation_deg.toFixed(4)}°, escala ${alignResult.scale.toFixed(6)}`:'')+` · RMS ${alignResult.rms_m.toFixed(3)} m com ${alignResult.pairs_used} par(es).`}catch(e){alignResult=null;$('alignResult').textContent=e.message;if(report)throw e}showPairs();draw()}
$('alignFit').onclick=guard(()=>fitAlign(true));
$('alignMode').onchange=()=>{checkpoint();M.dxf_alignment.mode=$('alignMode').value;changed();fitAlign(false)};
$('alignApply').onclick=guard(async()=>{await fitAlign(true);checkpoint();M.dxf_alignment.applied=true;changed();await save();await start(useGeo()?'analyze':'preview');msg('Ajuste aplicado ao DXF (o arquivo original não é alterado).')});
$('alignRevert').onclick=guard(async()=>{checkpoint();M.dxf_alignment.applied=false;changed();await save();await start(useGeo()?'analyze':'preview');msg('Ajuste revertido: DXF na posição original.')});

/* ---------- Intervenções ---------- */
function showPois(){const kmauto=id=>editor?.pois?.find(p=>p.id===id)?.km_auto_m;$('poiList').innerHTML=M.pois.map((p,i)=>{const auto=axisData()&&M.chainage.mode!=='off'?kmOf(p)?.km:null;const k=p.km_mode==='manual'?(p.km_m!=null?'km '+formatKm(p.km_m)+' (manual)':''):(auto!=null?'km '+formatKm(auto)+' (calculado)':'');return `<tr><td>${esc(p.title)}<br><small>${esc(p.subtitle)} ${k?'· '+k:''}${p.anchor?' · com linha de chamada':''}</small></td><td><button data-edit="${i}">Editar</button> <button data-remove="${i}">Excluir</button></td></tr>`}).join('');draw()}
$('poiList').onclick=e=>{const rem=e.target.dataset.remove,ed=e.target.dataset.edit;if(rem!==undefined){checkpoint();M.pois.splice(Number(rem),1);changed('Intervenção excluída.')}if(ed!==undefined){editingPoi=Number(ed);const p=M.pois[editingPoi];$('addPoi').textContent='Salvar intervenção';$('poiTitle').value=p.title;$('poiKind').value=p.kind;$('poiSubtitle').value=p.subtitle;$('poiX').value=p.x;$('poiY').value=p.y;$('poiKmMode').value=p.km_mode||'auto';$('poiKm').value=p.km_m==null?'':formatKm(p.km_m);$('bridgeSpan').value=p.bridge_span_m??'';$('bridgeWidth').value=p.bridge_width_m??3;$('bridgeAccess').value=p.bridge_access??'ramps';$('rampFlight').value=p.ramp_flight_m??24;$('busLength').value=p.bus_length_m??30;$('busDepth').value=p.bus_depth_m??3;$('busSide').value=p.bus_side??'right'}};
$('addPoi').onclick=guard(async()=>{if(!$('poiTitle').value.trim()||!$('poiX').value||!$('poiY').value)throw Error('Informe nome e coordenadas da intervenção.');const mode=$('poiKmMode').value;const kmv=$('poiKm').value.trim()?parseKm($('poiKm').value):null;if(mode==='manual'&&kmv==null)throw Error('Informe o km manual ou escolha “Calculado pelo estaqueamento”.');const old=editingPoi===null?{}:M.pois[editingPoi];const entry={...old,bridge_span_m:$('bridgeSpan').value?Number($('bridgeSpan').value):null,bridge_width_m:Number($('bridgeWidth').value),bridge_access:$('bridgeAccess').value,ramp_flight_m:Number($('rampFlight').value),bus_length_m:Number($('busLength').value),bus_depth_m:Number($('busDepth').value),bus_side:$('busSide').value,id:old.id||uid(),title:$('poiTitle').value.trim(),kind:$('poiKind').value,subtitle:$('poiSubtitle').value,x:Number($('poiX').value),y:Number($('poiY').value),km_mode:mode,km_m:mode==='manual'?kmv:null,anchor:old.anchor??null};checkpoint();if(editingPoi===null)M.pois.push(entry);else M.pois[editingPoi]=entry;editingPoi=null;$('addPoi').textContent='Adicionar intervenção';changed('Intervenção salva.');toolOptions()});

/* ---------- Tarefas ---------- */
let lastPolled='';
async function poll(jid){task=jid;lastPolled=jid;localStorage.setItem('rodovia_job',jid);$('cancel').disabled=false;for(;;){const j=await api('/api/jobs/'+jid);$('progress').value=j.progress;msg(j.message,j.state==='failed');if(['done','failed','cancelled','interrupted'].includes(j.state)){task='';localStorage.removeItem('rodovia_job');$('cancel').disabled=true;if(j.state==='done'){const keep=j.kind==='preview'&&$('preview_mode').value==='custom'?null:true;await load(j.project);if(j.kind==='render'||j.kind==='reference'){$('download').href='/api/projects/'+pid+'/video.mp4';$('download').hidden=false;$('video').src=$('download').href+'?v='+Date.now();$('video').hidden=false;msg(j.kind==='reference'?'Referência TH57 exportada sem alterações.':('Novo vídeo concluído · '+(lastRender?.encoder||'H.264')+(lastRender?.total_seconds?' · '+Math.round(lastRender.total_seconds)+' s de processamento':'')))}}return}await new Promise(r=>setTimeout(r,1200))}}
async function start(kind){requireProject();clearTimeout(saveTimer);await save();if(kind==='render'||kind==='reference'){$('download').hidden=true;$('video').hidden=true}const r=await api('/api/projects/'+pid+'/'+kind,{method:'POST'});announce({t:'job',id:r.id});await poll(r.id)}
$('new').onclick=guard(async()=>{const r=await api('/api/projects',json('POST',{name:'Novo trecho'}));await list();await load(r.id);msg('Projeto criado. Envie os arquivos.')});
$('example').onclick=guard(async()=>{const r=await api('/api/example',{method:'POST'});await list();await load(r.id);msg('Exemplo TH57 carregado. Clique “Analisar arquivos” para editar sobre a imagem web, ou gere uma prévia; a ficha técnica do vídeo aprovado está na seção 5 para comparação.')});
$('projects').onchange=guard(async()=>{if($('projects').value){await load($('projects').value);announce({t:'project'})}});
$('upload').onclick=guard(async()=>{requireProject();if(!$('files').files.length)throw Error('Selecione DXF e/ou KMZ.');for(const f of $('files').files){const d=new FormData();d.append('file',f);await api('/api/projects/'+pid+'/files',{method:'POST',body:d})}await load(pid);msg('Arquivos recebidos. Analise o projeto.')});
$('save').onclick=guard(async()=>{await save();msg('Configuração salva.')});
for(const k of ['analyze','preview','render'])$(k).onclick=guard(()=>start(k));
$('openAtTime').onclick=guard(async()=>{$('preview_mode').value='video';await start('preview')});
$('preview_time_s').oninput=()=>{const fps=Number($('fps').value)||30;const f=Math.round(Number($('preview_time_s').value)*fps);$('timeLabel').textContent=(f/fps).toFixed(3)+' s · quadro '+f};
$('renderView').onclick=guard(async()=>{if(!ready())throw Error('Analise os arquivos ou gere uma prévia primeiro.');const c=C2W(canvas.width/2,canvas.height/2);const a=C2W(0,canvas.height/2),b=C2W(canvas.width,canvas.height/2);cfg.preview_center=c;cfg.preview_width_m=Math.max(5,Math.min(50000,Math.hypot(b.x-a.x,b.y-a.y)));$('preview_mode').value='custom';await start('preview')});
$('fitView').onclick=fitView;$('updFlows').onclick=guard(async()=>{await start('analyze');msg('Fluxos, sentidos e sinalização atualizados no editor.')});
$('baseMode').onchange=()=>{setBase($('baseMode').value);baseUi()};$('tileAlpha').oninput=()=>{tileAlpha=Number($('tileAlpha').value);saveBasePrefs();draw()};$('vecAlpha').oninput=()=>{vecAlpha=Number($('vecAlpha').value);saveBasePrefs();draw()};
$('vecLayers').onchange=e=>{const r=e.target.dataset.vrole;if(!r)return;vecOn[r]=e.target.checked;saveBasePrefs();draw()};$('undo').onclick=undo;$('redo').onclick=redo;
function toggleFullscreen(){const s=$('editorSection');if(document.fullscreenElement)document.exitFullscreen();else (s.requestFullscreen?.()||Promise.resolve()).catch(()=>msg('O navegador não permitiu a tela cheia.',true))}
$('fullscreen').onclick=toggleFullscreen;
$('toggleSide').onclick=()=>{document.querySelector('.editorSide').classList.toggle('hidden');document.querySelector('.editorBody').classList.toggle('noside');setTimeout(()=>{resizeCanvas();fitView()},30)};
document.addEventListener('fullscreenchange',()=>{$('fullscreen').textContent=document.fullscreenElement?'⛶ Sair da tela cheia':'⛶ Tela cheia';setTimeout(()=>{resizeCanvas();fitView();canvas.focus()},80)});
document.addEventListener('keydown',e=>{if(e.target.matches('input,select,textarea')||e.ctrlKey||e.metaKey||e.altKey)return;if(e.key==='f'||e.key==='F'){e.preventDefault();toggleFullscreen()}if((e.key==='l'||e.key==='L')&&document.fullscreenElement){$('toggleSide').click()}});
$('cancel').onclick=guard(async()=>{if(task)await api('/api/jobs/'+task+'/cancel',{method:'POST'})});
$('logs').onclick=guard(async()=>{requireProject();const r=await api('/api/projects/'+pid+'/log');$('logText').textContent=(r.error+'\n'+r.ffmpeg).trim()||'Nenhum erro registrado.';$('logDialog').showModal()});
$('import').onclick=()=>$('importFile').click();
$('importFile').onchange=guard(async()=>{requireProject();let s=JSON.parse(await $('importFile').files[0].text());await api('/api/projects/'+pid+'/config',json('PUT',s));await load(pid);msg('Configuração importada (migrada automaticamente se antiga).')});
$('cacheSize').onclick=guard(async()=>{const r=await api('/api/maintenance');$('cacheInfo').textContent=(r.bytes/1024/1024).toFixed(1)+' MB recuperáveis · '+r.items+' itens.'});
$('cacheClean').onclick=guard(async()=>{const r=await api('/api/maintenance/cleanup',{method:'POST'});$('cacheInfo').textContent=(r.bytes/1024/1024).toFixed(1)+' MB liberados.'+(r.errors.length?' Alguns itens estavam em uso: '+r.errors.join('; '):'');msg('Limpeza concluída. Projetos e vídeos preservados.')});
new ResizeObserver(resizeCanvas).observe(canvas);
buildToolbar();updateUndo();
(async()=>{try{const h=await api('/api/health');$('health').textContent=(h.ffmpeg?'Ambiente pronto · FFmpeg disponível':'FFmpeg indisponível')+' · v'+h.version;await list();const old=localStorage.getItem('rodovia_project');if(old)try{await load(old)}catch{}const jid=localStorage.getItem('rodovia_job');if(jid)await poll(jid)}catch(e){msg(e.message,true)}})();

/* ---------- Fase B: camadas DXF, imagem local, exportação/importação ---------- */
const ROLE_OPTS=[['','Desenho (estilo da camada)'],['ignore','Ignorar'],...Object.entries(roles)];
async function showOverlays(){const list=cfg.overlays||[];if(!list.length){$('overlayList').innerHTML='<p class="muted">Nenhuma camada adicional.</p>';return}
 const html=[];for(const [i,o] of list.entries()){let layers=[];try{layers=await api(`/api/projects/${pid}/overlays/${o.id}/layers`)}catch{}
  html.push(`<div class="marks" style="border:1px solid var(--border);border-radius:8px;padding:8px;margin:8px 0"><div class="row"><label style="flex:1">Nome<input data-ov="${i}" data-k="name" value="${esc(o.name)}"></label><label><input type="checkbox" data-ov="${i}" data-k="enabled" ${o.enabled?'checked':''}> ligada</label><button data-ovup="${i}">▲</button><button data-ovdown="${i}">▼</button><button data-ovdel="${i}">Excluir camada</button></div>
  <div class="grid"><label>Cor<input type="color" data-ov="${i}" data-k="color" value="${o.color}"></label><label>Opacidade<input type="number" min="0" max="1" step="0.05" data-ov="${i}" data-k="opacity" value="${o.opacity}"></label><label>Espessura (m)<input type="number" min="0.05" step="0.05" data-ov="${i}" data-k="line_width_m" value="${o.line_width_m}"></label><label><input type="checkbox" data-ov="${i}" data-k="fill" ${o.fill?'checked':''}> preencher polígonos</label><label>CRS próprio (vazio = do projeto)<input data-ov="${i}" data-k="crs" value="${esc(o.crs||'')}"></label><label>Offset dx / dy (m)<input data-ovoff="${i}" value="${esc(offsetText(o))}" placeholder="0;0"></label></div>
  <div class="scroll"><table>${layers.map(l=>`<tr><td>${esc(l.name)} <small>${l.count}</small></td><td><select data-ovrole="${i}" data-layer="${esc(l.name)}">${ROLE_OPTS.map(([k,v])=>`<option value="${k}" ${(o.roles[l.name]??'')===k?'selected':''}>${v}</option>`).join('')}</select></td></tr>`).join('')}</table></div></div>`)}
 $('overlayList').innerHTML=html.join('')}
function offsetText(o){const p=o.alignment?.pairs?.[0];return o.alignment?.applied&&p?`${(p.image.x-p.dxf.x).toFixed(3)};${(p.image.y-p.dxf.y).toFixed(3)}`:''}
function ovChanged(){scheduleSave()}
$('overlayList').addEventListener('change',e=>{const t=e.target,ov=cfg.overlays;
 if(t.dataset.ov!==undefined){const o=ov[Number(t.dataset.ov)],k=t.dataset.k;o[k]=t.type==='checkbox'?t.checked:t.type==='number'?Number(t.value):(k==='crs'?(t.value.trim()||null):t.value);ovChanged()}
 if(t.dataset.ovrole!==undefined){ov[Number(t.dataset.ovrole)].roles[t.dataset.layer]=t.value;ovChanged()}
 if(t.dataset.ovoff!==undefined){const o=ov[Number(t.dataset.ovoff)];const v=t.value.trim();if(!v){o.alignment={mode:'translation',pairs:[],applied:false}}else{const [dx,dy]=v.split(/[;\s]+/).map(x=>Number(x.replace(',','.')));if(!Number.isFinite(dx)||!Number.isFinite(dy))return msg('Offset inválido: use dx;dy em metros.',true);o.alignment={mode:'translation',pairs:[{id:'offset',dxf:{x:0,y:0},image:{x:dx,y:dy},enabled:true}],applied:true}}ovChanged()}});
$('overlayList').addEventListener('click',guard(async e=>{const t=e.target,ov=cfg.overlays;
 if(t.dataset.ovdel!==undefined){const o=ov[Number(t.dataset.ovdel)];if(!confirm(`Excluir a camada “${o.name}”? O arquivo DXF desta camada será removido do projeto.`))return;clearTimeout(saveTimer);await save();await api(`/api/projects/${pid}/overlays/${o.id}`,{method:'DELETE'});await load(pid);await showOverlays();msg('Camada excluída.')}
 const mv=(i,d)=>{const j=i+d;if(j<0||j>=ov.length)return;[ov[i],ov[j]]=[ov[j],ov[i]];ov.forEach((o,k)=>o.order=k);ovChanged();showOverlays()};
 if(t.dataset.ovup!==undefined)mv(Number(t.dataset.ovup),-1);if(t.dataset.ovdown!==undefined)mv(Number(t.dataset.ovdown),1)}));
$('overlayUpload').onclick=guard(async()=>{requireProject();const f=$('overlayFile').files[0];if(!f)throw Error('Selecione um DXF.');clearTimeout(saveTimer);await save();const d=new FormData();d.append('file',f);const r=await api(`/api/projects/${pid}/overlays`,{method:'POST',body:d});await load(pid);await showOverlays();msg(`Camada “${r.overlay.name}” adicionada com ${r.layers.length} layers. Confira as classes e atualize a prévia.`)});
$('imgUpload').onclick=guard(async()=>{requireProject();const fs=$('imgFiles').files;if(!fs.length)throw Error('Selecione a imagem e seus arquivos de georreferência.');clearTimeout(saveTimer);await save();const d=new FormData();for(const f of fs)d.append('files',f);d.append('crs',$('imgCrs').value);d.append('mode',$('imgMode').value);msg('Enviando e conferindo georreferência…');const r=await api(`/api/projects/${pid}/imagery`,{method:'POST',body:d});
 if(r.needs_conversion){$('imgConvert').hidden=false;msg(r.gdal?`Arquivo ${r.file} recebido. Clique “Converter ECW/MrSID com o QGIS” (GDAL encontrado em ${r.gdal_bin}).`:`Arquivo ${r.file} recebido, mas não foi encontrado um GDAL/QGIS neste computador. Instale o QGIS (com ECW) ou converta no QGIS para GeoTIFF e envie o resultado.`,!r.gdal);return}
 await load(pid);msg('Imagem local georreferenciada aceita. Ela entra no fundo, na aproximação do vídeo e no editor.');await localUi();await loadGeo();draw()});
$('imgConvert').onclick=guard(async()=>{requireProject();await start('imagery/convert');await load(pid);await localUi();await loadGeo();draw();$('imgConvert').hidden=true});
async function localUi(){if(!pid||!$('imgList'))return;const li=cfg.local_imagery||{};$('liDetail').checked=li.detail!==false;$('liEditor').checked=li.editor!==false;$('liBright').value=li.brightness||0;$('liContrast').value=li.contrast||0;$('liSat').value=li.saturation||0;$('liNodata').value=li.nodata||'auto';
 if(!li.image){$('imgList').innerHTML='';$('imgInfo').textContent='';return}
 try{localInfo=await api(`/api/projects/${pid}/local/info`)}catch(e){localInfo=null}
 if(!localInfo){return}if(localInfo.error){$('imgInfo').textContent='Imagem local com problema: '+localInfo.error;return}
 $('imgInfo').textContent=`${localInfo.sources.length} imagem(ns) · melhor resolução ${localInfo.pixel_m.toFixed(3)} m/px · zoom do editor até ${localInfo.max_zoom}`+(localInfo.gdal?' · GDAL/QGIS encontrado':' · GDAL/QGIS não encontrado (ECW/MrSID precisam de conversão externa)');
 $('imgList').innerHTML='<table>'+localInfo.sources.map(s=>`<tr><td>${s.index===0?'<b>principal</b>':'mosaico '+s.index}</td><td>${esc(s.name)}<br><small>${s.size[0]}×${s.size[1]} px · ${s.pixel_m} m/px · ${esc(s.crs)}</small></td><td class="nowrap"><button data-imgup="${s.index}" title="Mais prioridade (fica por cima nas sobreposições)" ${s.index===0?'disabled':''}>▲</button><button data-imgdown="${s.index}" title="Menos prioridade" ${s.index>=localInfo.count-1?'disabled':''}>▼</button> <button data-imgzoom="${s.index}">Ver</button> <button data-imgadj="${s.index}" title="Ajustar posição pelos grips no editor">Ajustar</button> <button data-imgdel="${s.index}">Retirar</button>${adjText(s.adjust)}</td></tr>`).join('')+'</table><p class="muted">A imagem de cima na lista tem prioridade onde as imagens se sobrepõem; onde nenhuma cobre, vale a imagem web (Esri ou a fonte escolhida).</p>'}
function adjText(a){if(!a||(!a.shift_x&&!a.shift_y&&!a.rotation_deg&&a.scale===1))return'';return `<br><small>ajuste: ${a.shift_x.toFixed(2)} / ${a.shift_y.toFixed(2)} m · ${a.rotation_deg.toFixed(3)}° · escala ${a.scale.toFixed(4)}</small>`}
$('imgList')?.addEventListener('click',guard(async e=>{const ds=e.target.dataset||{};
 if(ds.imgup!==undefined||ds.imgdown!==undefined){requireProject();const i=Number(ds.imgup??ds.imgdown),to=ds.imgup!==undefined?i-1:i+1;await api(`/api/projects/${pid}/imagery/order`,json('POST',{index:i,to}));await load(pid);localTiles.clear();await localUi();draw();msg('Prioridade das imagens atualizada.');return}
 if(ds.imgadj!==undefined){imgAdj.index=Number(ds.imgadj);const s=localInfo.sources.find(x=>x.index===imgAdj.index);if(s)zoomTo({x:(s.bounds[0]+s.bounds[2])/2,y:(s.bounds[1]+s.bounds[3])/2});setTool('imgadjust');return}
 const del=e.target.dataset?.imgdel,zm=e.target.dataset?.imgzoom;
 if(zm!==undefined){const s=localInfo.sources.find(x=>x.index===Number(zm));const b=s.bounds;zoomTo({x:(b[0]+b[2])/2,y:(b[1]+b[3])/2});return}
 if(del===undefined)return;requireProject();await api(`/api/projects/${pid}/imagery/${del}`,{method:'DELETE'});await load(pid);await localUi();await loadGeo();draw();msg('Imagem retirada do mosaico (o arquivo continua na pasta do projeto).')}));
for(const [id,key,num] of [['liDetail','detail'],['liEditor','editor'],['liBright','brightness',1],['liContrast','contrast',1],['liSat','saturation',1],['liNodata','nodata']])$(id)?.addEventListener('change',()=>{if(!cfg.local_imagery)return;const el=$(id);cfg.local_imagery={...cfg.local_imagery,[key]:el.type==='checkbox'?el.checked:num?Number(el.value):el.value};localTiles.clear();scheduleSave();setTimeout(async()=>{await localUi();draw()},1200)});
async function showExports(){if(!pid)return;try{const r=await api(`/api/projects/${pid}/exports`);$('exportList').innerHTML=(r.files.length?r.files.map(f=>`<a class="link" style="margin:3px" href="/api/projects/${pid}/exports/${encodeURIComponent(f.name)}">${esc(f.name)} · ${(f.bytes/1024).toFixed(0)} kB</a>`).join(''):'Nenhuma exportação gerada.')+(r.png_sequences.length?`<p>Sequências PNG: ${r.png_sequences.map(esc).join(', ')} (pasta quadros_png do projeto)</p>`:'')}catch(e){$('exportList').textContent=e.message}$('packageLink').href=`/api/projects/${pid}/package.zip`;$('packageLink').hidden=false}
$('exportRun').onclick=guard(async()=>{await start('export');await showExports()});
$('markImport').onclick=guard(async()=>{requireProject();const f=$('markFile').files[0];if(!f)throw Error('Selecione o arquivo.');clearTimeout(saveTimer);await save();const d=new FormData();d.append('file',f);const r=await api(`/api/projects/${pid}/import_markings`,{method:'POST',body:d});await load(pid);msg('Importado: '+Object.entries(r.imported).map(([k,v])=>k+' '+v).join(', ')+'. Clique “Atualizar fluxos”.')});
$('pkgImport').onclick=guard(async()=>{const f=$('pkgFile').files[0];if(!f)throw Error('Selecione o pacote .zip.');const d=new FormData();d.append('file',f);const r=await api('/api/import_package',{method:'POST',body:d});await list();await load(r.id);msg('Pacote aberto como novo projeto. Analise e gere a prévia.')});
$('pngRun').onclick=guard(async()=>{requireProject();cfg.png_export={start_s:Number($('pngStart').value),end_s:Number($('pngEnd').value),every_n_frames:Number($('pngEvery').value),rgba_layers:$('pngRgba').checked};await start('frames');await showExports()});
const _load=load;load=async id=>{await _load(id);const pe=cfg.png_export||{};$('pngStart').value=pe.start_s??0;$('pngEnd').value=pe.end_s??5;$('pngEvery').value=pe.every_n_frames??1;$('pngRgba').checked=!!pe.rgba_layers;if(cfg.local_imagery?.image&&!localInfo)$('imgInfo').textContent='Imagem local: '+cfg.local_imagery.name+(cfg.local_imagery.crs?' · '+cfg.local_imagery.crs:'');showOverlays();showExports()};
const _load2=load;load=async id=>{await _load2(id);try{await localUi()}catch{}try{webUi()}catch{}};

/* ---------- Fase D: vista da cabine ---------- */
const CAB={cabinEnabled:'enabled',cabinDuration:'duration_s',cabinHeight:'eye_height_m',cabinFov:'fov_deg',cabinPitch:'pitch_deg',cabinSmooth:'smoothing_s',cabinSpeed:'speed_kmh',cabinHood:'hood'};
function cabinUi(){const c=M.cabin||{};for(const [id,k] of Object.entries(CAB)){const el=$(id);if(el.type==='checkbox')el.checked=k==='hood'?c[k]!==false:!!c[k];else el.value=c[k]??''}$('cabinState').textContent=c.start?`Início: X ${c.start.x.toFixed(1)} Y ${c.start.y.toFixed(1)}`+(editor?` · km ${formatKm(kmOf(c.start)?.km)}`:''):'Início não definido.';
 const img=$('cabinPreview');if(pid&&c.enabled){img.src=`/api/projects/${pid}/preview_cabin.png?v=${Date.now()}`;img.onload=()=>img.hidden=false;img.onerror=()=>img.hidden=true}else img.hidden=true}
for(const [id,k] of Object.entries(CAB))$(id).addEventListener('change',()=>{const el=$(id);checkpoint();M.cabin={...M.cabin,[k]:el.type==='checkbox'?el.checked:(el.value===''?null:Number(el.value))};changed();cabinUi()});
const _loadD=load;load=async id=>{await _loadD(id);cabinUi()};

/* ---------- Ficha técnica de referência ---------- */
const fmtv=v=>v==null?'—':typeof v==='number'?(Math.abs(v)>=1000?v.toLocaleString('pt-BR'):String(v).replace('.',',')):esc(v);
async function showReference(){try{const r=await api('/api/reference/profile');const f=r.file||{};$('refInfo').innerHTML=`${esc(r.label||'Referência')} · ${f.width}×${f.height} · ${fmtv(f.fps)} q/s · ${fmtv(f.duration_s)} s · ${fmtv(f.bitrate_avg_mbps)} Mbit/s · ficha ${r.status==='completa'?'completa':'parcial (métricas de imagem ainda não medidas)'}`+(r.video_present?' · o arquivo referencia.mp4 ainda está na pasta':'');$('refProfile').hidden=!r.video_present}catch(e){$('refInfo').textContent=e.message}}
async function showComparison(){if(!pid)return;try{const c=await api(`/api/projects/${pid}/comparison`);if(!c.rows.length){$('compareTable').innerHTML='';return}$('compareTable').innerHTML=`<table><tr><th>Item</th><th>Referência</th><th>Vídeo gerado</th><th>Diferença</th></tr>${c.rows.map(r=>`<tr><td>${esc(r.label)}</td><td>${fmtv(r.reference)}</td><td>${fmtv(r.current)}</td><td>${r.delta_pct==null?'':(r.delta_pct>0?'+':'')+String(r.delta_pct).replace('.',',')+'%'}</td></tr>`).join('')}</table>`+(c.reference_status!=='completa'?'<p class="muted">A referência ainda não tem métricas de imagem: use “Medir referência…” enquanto o vídeo existir.</p>':'')}catch{$('compareTable').innerHTML=''}}
$('compareRun').onclick=guard(async()=>{requireProject();clearTimeout(saveTimer);await save();const r=await api(`/api/projects/${pid}/compare`,{method:'POST'});await poll(r.id);await showComparison()});
$('refProfile').onclick=guard(async()=>{requireProject();if(!confirm('Medir o vídeo TH57 aprovado, gravar a ficha técnica e REMOVER o arquivo referencia.mp4 (456 MB) da pasta do aplicativo? A remoção só acontece se a ficha for gravada.'))return;const r=await api(`/api/projects/${pid}/reference_profile?remove=true`,{method:'POST'});await poll(r.id);await showReference()});
const _loadR=load;load=async id=>{await _loadR(id);showComparison()};
showReference();

/* ---------- 1.7: elevação ---------- */
const EL={elSource:'source',elExag:'exaggeration',elHill:'hillshade',elHillOp:'hillshade_opacity',elCont:'contours',elInt:'contour_interval_m',elLevel:'level_road'};
function elUi(){const e=cfg.elevation||{};for(const [id,k] of Object.entries(EL)){const el=$(id);if(el.type==='checkbox')el.checked=k==='level_road'?e[k]!==false:!!e[k];else el.value=e[k]??el.value}$('elInfo').textContent=e.source==='local'?(e.file?'MDT local: '+e.file+(e.crs?' · '+e.crs:''):'Envie o MDT local.'):e.source==='web'?'Elevação web: requer internet na primeira geração; depois usa o cache do projeto.':''}
for(const [id,k] of Object.entries(EL))$(id).addEventListener('change',()=>{const el=$(id);cfg.elevation={...(cfg.elevation||{}),[k]:el.type==='checkbox'?el.checked:el.type==='number'?Number(el.value):el.value};elUi();scheduleSave()});
$('elUpload').onclick=guard(async()=>{requireProject();const fs=$('elFiles').files;if(!fs.length)throw Error('Selecione o MDT.');clearTimeout(saveTimer);await save();const d=new FormData();for(const f of fs)d.append('files',f);d.append('crs',$('elCrs').value);const r=await api(`/api/projects/${pid}/elevation`,{method:'POST',body:d});await load(pid);msg('MDT local aceito. Clique “Atualizar fluxos”.')});
let zTimer=null,zLast='';canvas.addEventListener('pointermove',e=>{if(!ready()||!pid||!(cfg.elevation&&cfg.elevation.source!=='none'))return;clearTimeout(zTimer);zTimer=setTimeout(async()=>{const w=lastWorld;if(!w)return;try{const r=await api(`/api/projects/${pid}/elevation_at?x=${w.x}&y=${w.y}`);if(r.z!=null){const c=$('cursor');c.textContent=c.textContent.replace(/ · cota .*$/,'')+` · cota ${r.z.toFixed(1)} m`}}catch{}},150)});
const _loadE=load;load=async id=>{await _loadE(id);elUi()};

/* ---------- 1.8: Como usar e dicas nos campos ---------- */
const HELP={
 projects:'Projetos já criados neste computador. Cada projeto guarda arquivos, configuração, marcações e vídeos na pasta “projetos”.',
 files:'DXF do projeto (obrigatório para pavimento, OAE etc.) e KMZ opcional (eixo e pontos). DWG deve ser salvo como DXF no CAD.',
 name:'Nome do trecho: aparece no cabeçalho do vídeo.',origin:'Cidade/ponto de origem, mostrado no cabeçalho.',destination:'Cidade/ponto de destino, mostrado no cabeçalho.',
 km_start_m:'Km do início do trecho (ex.: 325+850 ou 325,850). No estaqueamento manual, vale no ponto marcado com “Início do km”.',
 km_end_m:'Km do fim do trecho. Use “Usar km final medido” (Marcações do projeto) para preencher pela distância ao longo do eixo.',
 reference_length_m:'Extensão contratual mostrada no rodapé. Pode diferir do comprimento geométrico do desenho.',
 work_year:'Ano/etapa da obra mostrado no rodapé (ex.: Ano 4 do PER).',
 crs:'Sistema de coordenadas projetado do DXF, em metros (ex.: EPSG:31983 = SIRGAS 2000 / UTM 23S). Errado = desenho fora da imagem.',
 units_to_m:'Multiplicador para converter a unidade do DXF em metros: 1 para metros, 0,001 para milímetros.',
 imagery:'Fundo do vídeo: Esri online (baixa e guarda), cache TH57, fundo neutro (teste rápido) ou imagem local georreferenciada.',
 reverse_axis:'Inverte início e fim do eixo principal (sentido da câmera e do km automático).',
 coordinates_confirmed:'Confirme depois de conferir na prévia que o desenho está sobre a imagem. É exigido para gerar o vídeo.',
 preview_mode:'Vista geral: todo o trecho. Câmera do vídeo: o quadro no instante escolhido. Vista do editor: detalhe do enquadramento atual.',
 preview_time_s:'Instante do vídeo usado por “Abrir neste instante”.',
 poiTitle:'Nome da intervenção (aparece no cabeçalho na cena de detalhe).',poiKind:'Categoria: define símbolo e representação (passarela e baia são desenhadas).',
 poiSubtitle:'Texto complementar abaixo do nome no cabeçalho.',poiKmMode:'Calculado: km pelo estaqueamento a partir do ponto X/Y. Manual: km oficial digitado.',
 poiKm:'Km oficial da intervenção (usado quando o modo é Manual).',poiX:'Coordenada X (Este) no CRS do projeto. Use a ferramenta Intervenção para preencher.',poiY:'Coordenada Y (Norte) no CRS do projeto.',
 encoder:'Automática: testa a NVIDIA (NVENC) e usa a CPU se falhar. Somente CPU: mais compatível.',
 cpu_preset:'veryfast: mais rápido; fast: original, um pouco mais eficiente em tamanho.',
 width:'Resolução do vídeo. 720p é bom para testes; 1440p para a versão final.',fps:'Quadros por segundo (30 é mais fluido).',
 duration_s:'Duração do vídeo. Abaixo de 45 s, o modo curto usa vista estável (ver opção abaixo).',
 view_width_m:'Largura do terreno mostrada pela câmera durante o percurso (menor = mais perto).',
 imagery_pixels:'Resolução do mosaico de imagem. 8192 = mais nítido, mais memória e tempo.',
 render_workers:'Quantos processos montam quadros ao mesmo tempo. Automático usa os núcleos e a memória livres do seu PC.',
 render_profile:'Rápido: sem superamostragem da imagem aérea — bom para conferir antes do vídeo final.',
 visual_quality:'Aprimorada: asfalto com textura em metros, concreto nas OAE e veículos por tipo. Anterior: desenho da 1.4, mais rápido.',
 hydrography:'Rios e lagos de bases públicas (IBGE/OSM), com cache local.',water_texture:'Textura azul só dentro dos polígonos de água existentes.',
 water_names:'Nomes dos rios sobre o mapa.',water_animated:'Ondulação sutil animada na água (custa tempo de geração).',headlights:'Faróis acesos com feixe discreto em todos os veículos.',
 traffic:'Veículos em trajetórias validadas (ilustrativo, sem simulação de tráfego).',traffic_speed_kmh:'Velocidade dos veículos ilustrativos.',
 short_video_mode:'Para vídeos curtos: vista estável com aparecimento suave, ou o sobrevoo completo comprimido.',
 traffic_network_preview:'Desenha as trajetórias validadas na imagem da prévia.',
 cabinEnabled:'Gera o vídeo em primeira pessoa a partir do ponto escolhido com a ferramenta Cabine.',
 elSource:'Elevação do terreno: MDT local (GeoTIFF) ou web (~30 m). A imagem aérea não é deformada.',
 elHill:'Sombreamento do relevo sobre a imagem (só brilho; nada muda de lugar).',elCont:'Curvas de nível sobre a imagem, com o intervalo escolhido.',
 elLevel:'A pista segue o perfil suavizado do terreno sob o eixo (aproximação sem greide de projeto).',
 alignMode:'Translação: só desloca. Similaridade: desloca, gira e ajusta a escala (2 pares ou mais).',
 pngRgba:'Também salva cada quadro com fundo transparente para editores de vídeo.',
 overlayFile:'DXF extra sobreposto ao projeto (outro lote, interferências, cadastro). Não altera o DXF principal.',
 baseMode:'Imagem web: ladrilhos Esri World Imagery nítidos em qualquer zoom (guardados em cache para uso sem internet) com o DXF/KMZ simplificado por cima — use para posicionar marcações e pares de controle. Prévia renderizada: a imagem do vídeo. As marcações são as mesmas nos dois fundos (coordenadas do CRS).',
 tileAlpha:'Transparência da imagem web.',vecAlpha:'Transparência dos vetores do DXF/KMZ.',
 signage_style:'Limpa: remove pinturas que se cruzam, sobras de ramos curtos e marcas junto às junções. Anterior: como na 1.9.',flow_arrows:'Setas de sentido do tráfego: uma a cada km (espaçamento abaixo) e antes/depois de convergências, divergências e rotatórias.',flow_arrow_spacing_m:'Distância entre setas ao longo das vias principais.',cities_radius_km:'Distância máxima das cidades buscadas e das setas de borda.',
 km_markers:'Marcadores com o km inicial e o km final sobre o traçado.',direction_badge:'Seta no topo do vídeo indicando para onde o km cresce na posição da câmera.',median_grass:'Textura de grama nos canteiros (qualidade Aprimorada).',cities_show:'Nomes das cidades marcadas; fora do quadro aparece uma seta na borda com a distância.',
 imagery_detail:'Perto do chão, usa a imagem Esri de ~0,3 m (baixada antes da montagem e guardada). Desligada: só o mosaico da vista geral.',detail_textures:'Pavimento, canteiro, taludes e OAE desenhados a 0,2 m por pixel quando a câmera se aproxima (bordas e hachuras nítidas). Aumenta o tempo por quadro.',
 traffic_model:'Simulado: os veículos mantêm distância segura (sem batidas traseiras), cedem passagem nas convergências e formam fila em interdições e engarrafamentos. Anterior: movimento da 1.11.',traffic_density:'Quantidade de veículos: 1 normal; acima de 3 forma congestionamento.',median_crossing:'Onde os veículos podem passar de uma pista para a outra do canteiro central.',
 day_night:'Transição: o vídeo começa de dia e escurece no instante escolhido, com faróis, lanternas e sinalização refletiva em destaque. Noite: o vídeo todo à noite.',night_start_s:'Instante do vídeo em que começa a anoitecer.',night_transition_s:'Duração do anoitecer.',night_darkness:'Quanto a cena escurece (0,3 = entardecer; 0,95 = noite fechada).',night_signage_glow:'Faixas e setas brilham como tinta refletiva iluminada pelos faróis.',
 imgFiles:'GeoTIFF, ou JPG/PNG com o arquivo de mundo (.jgw/.pgw/.tfw) e o .prj. Arquivos sem georreferência são recusados.'};
function initHelp(){for(const [id,text] of Object.entries(HELP)){const el=$(id);if(!el)continue;const lab=el.closest('label');const host=lab||el.parentElement;if(!host||host.querySelector(':scope > .help'))continue;
 const b=document.createElement('span');b.className='help';b.tabIndex=0;b.textContent='?';b.dataset.help=text;b.setAttribute('aria-label','Ajuda: '+text);
 if(lab){const firstInput=lab.querySelector('input,select,textarea');if(firstInput&&firstInput.type==='checkbox')lab.appendChild(b);else lab.insertBefore(b,firstInput)}else host.appendChild(b)}
 const tip=$('tip');const show=e=>{const t=e.target.closest('.help');if(!t)return;tip.textContent=t.dataset.help;tip.hidden=false;const r=t.getBoundingClientRect();tip.style.left=Math.min(window.innerWidth-380,Math.max(8,r.left-10))+'px';tip.style.top=(r.bottom+8+tip.offsetHeight>window.innerHeight?r.top-tip.offsetHeight-8:r.bottom+8)+'px'};
 document.addEventListener('mouseover',show);document.addEventListener('focusin',show);document.addEventListener('mouseout',e=>{if(e.target.closest('.help'))tip.hidden=true});document.addEventListener('focusout',e=>{if(e.target.closest('.help'))tip.hidden=true});
 document.addEventListener('click',e=>{if(e.target.closest('.help'))e.preventDefault()},true);
 let on=true;try{on=localStorage.getItem('rodovia_help')!=='0'}catch{}$('helpToggle').checked=on;document.body.classList.toggle('nohelp',!on);
 $('helpToggle').onchange=()=>{document.body.classList.toggle('nohelp',!$('helpToggle').checked);try{localStorage.setItem('rodovia_help',$('helpToggle').checked?'1':'0')}catch{}}}
$('helpBtn').onclick=guard(async()=>{if(!$('helpBody').innerHTML){const r=await fetch('/ajuda');$('helpBody').innerHTML=await r.text()}$('helpDialog').showModal()});
initHelp();

/* ---------- 1.13: duas janelas sincronizadas (configuração | visualização e resultados) ---------- */
const JANELA=new URLSearchParams(location.search).get('janela')||'unica';const WIN_ID=Math.random().toString(36).slice(2);
document.body.dataset.janela=JANELA;
let bc=null;try{bc=new BroadcastChannel('rodovia_studio')}catch{}
function announce(m){if(!bc||!pid)return;try{bc.postMessage({...m,pid,from:WIN_ID,janela:JANELA})}catch{}}
async function remoteSaved(){
 const r=await api('/api/projects/'+pid);const s=r.config;
 if(JANELA==='visual'){ // a janela de visualização não edita os campos: assume os da configuração e mantém as marcações locais
  const marks={};for(const k of MARK_KEYS)marks[k]=M[k];const keepUndo=[undoStack,redoStack];
  if(savePending){cfg={...s,...marks}}else{fill(s);[undoStack,redoStack]=keepUndo;updateUndo()}
  if(!savePending)for(const k of MARK_KEYS)M[k]=JSON.parse(JSON.stringify(s[k]));
  refreshLists();draw();return}
 if(JANELA==='config'){ // a configuração não edita marcações: assume as da visualização
  for(const k of MARK_KEYS)if(s[k]!==undefined)M[k]=JSON.parse(JSON.stringify(s[k]));cfg={...cfg,...Object.fromEntries(MARK_KEYS.map(k=>[k,s[k]]))};refreshLists();return}
 if(!savePending)await load(pid)}
if(bc)bc.onmessage=async e=>{const m=e.data||{};if(m.from===WIN_ID)return;
 try{
  if(m.t==='project'&&m.pid!==pid){await load(m.pid);return}
  if(m.pid!==pid)return;
  if(m.t==='saved')await remoteSaved();
  else if(m.t==='job'&&!task)await poll(m.id);
  else if(m.t==='hello'&&pid)announce({t:'project'});
 }catch(err){msg(err.message,true)}};
function openTwoWindows(){const w=window.open('/?janela=visual','rodovia_visual','width=1500,height=950');if(!w)return msg('O navegador bloqueou a nova janela: permita pop-ups para 127.0.0.1.',true);
 const u=new URL(location.href);u.searchParams.set('janela','config');history.replaceState(null,'',u);document.body.dataset.janela='config';location.reload()}
$('twoWindows').onclick=openTwoWindows;$('oneWindow').onclick=()=>{const u=new URL(location.href);u.searchParams.delete('janela');location.href=u.toString()};
if(JANELA!=='unica'){$('winLabel').textContent=JANELA==='config'?'Janela de configuração':'Janela de visualização e resultados';setTimeout(()=>{try{bc&&bc.postMessage({t:'hello',from:WIN_ID})}catch{}},600)}

/* ---------- 1.14: setas giráveis, camadas reutilizáveis (perfis), cores por tipo ---------- */
function hitArrow(c,maxPx=16){if(!editor||!editor.arrows)return null;let best=null;
 for(const a of editor.arrows){const [x,y]=W2C({x:a[0],y:a[1]});const d=Math.hypot(x-c.cx,y-c.cy);if(d<=maxPx&&(!best||d<best.d))best={d,p:[a[0],a[1]],t:[a[2],a[3]],ref:a}}return best}
function rotateArrow(a,vec){
 // A seta se alinha à faixa: só pode apontar para um dos dois sentidos dela.
 const t=a.t;let sgn=-1;if(vec){const L=Math.hypot(vec.x,vec.y)||1;sgn=(vec.x*t[0]+vec.y*t[1])/L>=0?1:-1;if(sgn>0)return msg('A seta já aponta nesse sentido.')}
 const nt=[t[0]*sgn,t[1]*sgn];checkpoint();
 // 1.15: setas repetidas por faixa levam o ponto da trajetória da via (âncora) para o sentido valer na via toda.
 const P=a.ref.length>=6?[a.ref[4],a.ref[5]]:a.p;
 M.direction_marks=M.direction_marks.filter(m=>Math.hypot((m.start.x+m.end.x)/2-P[0],(m.start.y+m.end.y)/2-P[1])>4);
 M.direction_marks.push({id:uid(),start:{x:P[0]-nt[0]*3,y:P[1]-nt[1]*3},end:{x:P[0]+nt[0]*3,y:P[1]+nt[1]*3}});
 a.ref[2]=nt[0];a.ref[3]=nt[1];if(typeof buildSignage==='function')buildSignage();
 const seg=nearestSegment({x:P[0],y:P[1]},6);if(seg&&sgn<0){seg.forward=!seg.forward}
 changed('Seta girada: o fluxo da faixa passa a seguir a seta. Clique “⟳ Atualizar fluxos” para recalcular a rede (o vídeo usa o novo sentido).')}
let layerShow=null,layerPrev=null;
async function showLayer(name){
 if(layerShow&&layerShow.name===name){layerShow=null;draw();return}
 if(!layerPrev){try{layerPrev=await api('/api/projects/'+pid+'/layers_preview.json')}catch(e){return msg('Analise os arquivos para ver as camadas no editor.',true)}}
 const d=layerPrev[name];if(!d||!d.p.length)return msg('Camada sem geometria desenhável (texto, cota ou bloco vazio).',true);
 layerShow={name,p:d.p};let x0=Infinity,y0=Infinity,x1=-Infinity,y1=-Infinity;for(const q of d.p)for(const [x,y] of q){x0=Math.min(x0,x);y0=Math.min(y0,y);x1=Math.max(x1,x);y1=Math.max(y1,y)}
 if(ready()){const c={x:(x0+x1)/2,y:(y0+y1)/2};const [ix,iy]=worldToImg(c);const span=Math.max(40,Math.hypot(x1-x0,y1-y0));view.s=Math.max(minScale(),Math.min(useGeo()?240:60,canvas.width*mpp()/span*.8));view.ox=canvas.width/2-ix*view.s;view.oy=canvas.height/2-iy*view.s;draw()}
 msg(`Camada “${name}” destacada em magenta no editor${d.role?' ('+(roles[d.role]||d.role)+')':' (sem tipo)'}. Clique “Ver” de novo para apagar.`)}
document.addEventListener('click',e=>{const b=e.target.closest('[data-showlayer]');if(!b)return;e.preventDefault();const name=b.dataset.showlayer;if(JANELA==='config'){announce({t:'showLayer',name});msg('Camada destacada na janela de visualização.')}else showLayer(name)});
if(bc){const prev=bc.onmessage;bc.onmessage=async e=>{const m=e.data||{};if(m.t==='showLayer'&&m.pid===pid&&m.from!==WIN_ID){showLayer(m.name);return}if(m.t==='saved'&&m.pid===pid)layerPrev=null;return prev&&prev(e)}}
let profiles=[];
async function loadProfiles(){try{const r=await api('/api/layer_profiles');profiles=r.profiles;$('layerProfile').innerHTML=profiles.map(p=>`<option value="${esc(p.name)}">${esc(p.name)}${p.builtin?'':' ('+p.rules.length+' regras)'}</option>`).join('')}catch(e){}}
$('profileApply').onclick=guard(async()=>{requireProject();if(!analysis)throw Error('Analise os arquivos primeiro.');const r=await api(`/api/projects/${pid}/layer_profiles/apply`,json('POST',{name:$('layerProfile').value}));
 checkpointLayers();document.querySelectorAll('#layers select').forEach(el=>{const role=Object.entries(r.layers).find(([k,v])=>v.includes(el.dataset.layer))?.[0]||'';el.value=role});await save();msg(`Perfil aplicado: ${r.matched} de ${r.total} camadas reconhecidas. Confira a lista e clique “Analisar arquivos”.`)});
function checkpointLayers(){}
function currentRules(){const rules=[];document.querySelectorAll('#layers select').forEach(el=>{if(el.value)rules.push({pattern:el.dataset.layer,role:el.value})});return rules}
$('profileSave').onclick=guard(async()=>{const name=prompt('Nome do perfil (ex.: Padrão CAD da empresa):');if(!name)return;const rules=currentRules();if(!rules.length)throw Error('Nenhuma camada tem tipo definido.');await api('/api/layer_profiles',json('POST',{name,rules}));await loadProfiles();$('layerProfile').value=name;msg(`Perfil “${name}” salvo com ${rules.length} regras. Use-o em outros projetos (Aplicar perfil). Para generalizar nomes, use “Editar regras” com * e ?.`)});
$('profileEdit').onclick=guard(async()=>{const p=profiles.find(x=>x.name===$('layerProfile').value);const base=p&&!p.builtin?p:{name:'',rules:p?p.rules:currentRules()};
 $('ruleName').value=base.name;$('ruleText').value=base.rules.map(r=>`${r.pattern} => ${r.role}`).join('\n');$('ruleRoles').textContent=Object.entries(roles).map(([k,v])=>k+' = '+v).join(' · ');$('ruleDialog').showModal()});
$('ruleSave').onclick=guard(async e=>{e.preventDefault();const rules=$('ruleText').value.split('\n').map(l=>l.trim()).filter(Boolean).map(l=>{const m=l.split('=>');if(m.length!==2)throw Error('Use uma regra por linha: PADRÃO => tipo');const role=m[1].trim();const key=roles[role]?role:Object.entries(roles).find(([k,v])=>v.toLowerCase()===role.toLowerCase())?.[0];if(!key)throw Error('Tipo desconhecido: '+role);return {pattern:m[0].trim(),role:key}});
 const name=$('ruleName').value.trim();await api('/api/layer_profiles',json('POST',{name,rules}));$('ruleDialog').close();await loadProfiles();$('layerProfile').value=name;msg(`Perfil “${name}” salvo (${rules.length} regras).`)});
$('ruleCancel').onclick=e=>{e.preventDefault();$('ruleDialog').close()};
$('profileDelete').onclick=guard(async()=>{const name=$('layerProfile').value;const p=profiles.find(x=>x.name===name);if(!p||p.builtin)throw Error('O perfil padrão não pode ser excluído.');await api('/api/layer_profiles/'+encodeURIComponent(name),{method:'DELETE'});await loadProfiles();msg(`Perfil “${name}” excluído.`)});
function showRoleColors(){const rc=cfg.role_colors||{};$('roleColors').innerHTML=Object.entries(ROLE_COLOR).map(([k,c])=>`<label class="rc"><input type="color" data-rolecolor="${k}" value="${rc[k]||c}">${esc(roles[k]||k)}</label>`).join('')+'<button id="roleColorsReset" class="mini">Cores padrão</button>'}
document.addEventListener('change',e=>{const k=e.target.dataset?.rolecolor;if(!k)return;cfg.role_colors={...(cfg.role_colors||{}),[k]:e.target.value};scheduleSave();msg('Cor do tipo alterada: vale para a prévia e o vídeo.')});
document.addEventListener('click',e=>{if(e.target.id!=='roleColorsReset')return;e.preventDefault();cfg.role_colors={};showRoleColors();scheduleSave()});
loadProfiles();
// A lista de camadas do editor fecha ao clicar fora (não cobre a barra de ferramentas).
document.addEventListener('pointerdown',e=>{const d=document.querySelector('.vlist');if(d&&d.open&&!e.target.closest('.vlist'))d.open=false},true);

// ---------------- 1.19: fonte da imagem web ----------------
function webUi(){if(!$('webSource'))return;$('webSource').disabled=false;$('webApply').disabled=false;const w=cfg.web_imagery||{};if($('qmsId')){$('qmsId').value=w.qms_id||'';$('qmsInfo').textContent=w.source==='qms'?'Serviço salvo: '+w.qms_name+' · '+w.attribution:''}$('webSource').value=w.source||'esri';$('webUrl').value=w.url||'';$('webLayers').value=w.wms_layers||'';$('webMaxZoom').value=w.max_zoom||19;$('webAttr').value=w.attribution||'';
 if(w.wayback_release&&!$('wbRelease').querySelector(`option[value="${w.wayback_release}"]`))$('wbRelease').insertAdjacentHTML('beforeend',`<option value="${w.wayback_release}">${esc(w.wayback_label||('versão '+w.wayback_release))}</option>`);$('wbRelease').value=w.wayback_release||'';webVis();
 $('webInfo').textContent=(w.source&&w.source!=='esri')?'Fonte em uso: '+({qms:'QuickMapServices · '+(w.qms_name||''),wayback:'Esri Wayback '+(w.wayback_label||''),xyz:'XYZ',wms:'WMS'}[w.source])+(w.attribution?' · '+w.attribution:''):'Fonte em uso: Esri World Imagery atual.'}
function webVis(){const v=$('webSource').value;$('qmsBox').hidden=v!=='qms';$('wbBox').hidden=v!=='wayback';$('wbLoad').hidden=v!=='wayback';$('webCustom').hidden=!(v==='xyz'||v==='wms');$('webLayers').parentElement.hidden=v!=='wms'}
$('webSource')?.addEventListener('change',webVis);
$('wbLoad')?.addEventListener('click',guard(async()=>{const r=await api('/api/wayback/releases');const cur=$('wbRelease').value;$('wbRelease').innerHTML='<option value="">— escolha a data —</option>'+r.releases.map(x=>`<option value="${x.release}">${esc(x.date||x.title)}</option>`).join('');if(cur)$('wbRelease').value=cur;msg(r.releases.length+' datas disponíveis na Esri Wayback (a mais recente primeiro). Compare no editor antes de gerar o vídeo.')}));
$('webApply')?.addEventListener('click',guard(async()=>{if(!pid)throw Error('Abra um projeto.');const v=$('webSource').value,o=$('wbRelease').selectedOptions[0];
 const oldWeb=cfg.web_imagery,oldImagery=$('imagery').value;
 if(v==='wayback'&&!$('wbRelease').value)throw Error('Carregue a lista e escolha a data da Wayback.');
 if((v==='xyz'||v==='wms')&&!/^https?:\/\//i.test($('webUrl').value.trim()))throw Error('Informe o endereço http/https do serviço.');
 if(v==='qms'){const id=Number($('qmsId').value||$('qmsResults').value);if(!Number.isInteger(id)||id<1)throw Error('Busque e selecione uma fonte QuickMapServices.');cfg.web_imagery=await api('/api/qms/services/'+id);$('imagery').value='esri'}else cfg.web_imagery={source:v,wayback_release:v==='wayback'?Number($('wbRelease').value):null,wayback_label:v==='wayback'?(o?.textContent||''):'',url:$('webUrl').value.trim(),wms_layers:$('webLayers').value.trim(),attribution:$('webAttr').value.trim(),max_zoom:Number($('webMaxZoom').value)||19};
 try{await save()}catch(e){cfg.web_imagery=oldWeb;$('imagery').value=oldImagery;webUi();throw e}tiles.clear();webUi();draw();msg('Fonte da imagem web aplicada. O editor já usa a nova fonte; gere a prévia para atualizar o mosaico do vídeo.')}));

// ---------------- 1.19: ajuste da imagem local por grips (deslocar, girar, escalar) ----------------
const imgAdj={index:0,cur:null,undo:[],redo:[],t:null,k0:null};
function imgSrc(){return localInfo?.sources?.find(s=>s.index===imgAdj.index)}
function adjFwd(a,c,p){const r=a.rotation_deg*Math.PI/180,k=a.scale,ca=Math.cos(r)*k,sa=Math.sin(r)*k,u=p.x-c.x,v=p.y-c.y;return {x:c.x+ca*u-sa*v+a.shift_x,y:c.y+sa*u+ca*v+a.shift_y}}
function adjInv(a,c,p){const r=a.rotation_deg*Math.PI/180,k=a.scale,ca=Math.cos(r)/k,sa=Math.sin(r)/k,u=p.x-c.x-a.shift_x,v=p.y-c.y-a.shift_y;return {x:c.x+ca*u+sa*v,y:c.y-sa*u+ca*v}}
function imgCorners(){const s=imgSrc();if(!s)return null;if(!imgAdj.cur||imgAdj.curFor!==s.file+imgAdj.index){imgAdj.cur={...s.adjust};imgAdj.curFor=s.file+imgAdj.index}
 const c={x:s.center[0],y:s.center[1]};const raw=s.corners.map(q=>adjInv(s.adjust,c,{x:q[0],y:q[1]}));return {c,pts:raw.map(p=>adjFwd(imgAdj.cur,c,p))}}
function imgAdjHit(cp){const g=imgCorners();if(!g)return null;for(let i=0;i<4;i++){const [x,y]=W2C(g.pts[i]);if(Math.hypot(x-cp.cx,y-cp.cy)<12)return 'corner'}
 const P=g.pts.map(W2C);let inside=false;for(let i=0,j=3;i<4;j=i++){const [xi,yi]=P[i],[xj,yj]=P[j];if(((yi>cp.cy)!==(yj>cp.cy))&&cp.cx<(xj-xi)*(cp.cy-yi)/(yj-yi)+xi)inside=!inside}return inside?'move':null}
function imgAdjDrag(d,w){const s=imgSrc();if(!s)return;const a=imgAdj.cur,a0=d.a0;
 if(d.mode==='move'){a.shift_x=a0.shift_x+w.x-d.w0.x;a.shift_y=a0.shift_y+w.y-d.w0.y}
 else{const C={x:s.center[0]+a0.shift_x,y:s.center[1]+a0.shift_y},v0={x:d.w0.x-C.x,y:d.w0.y-C.y},v1={x:w.x-C.x,y:w.y-C.y};const L0=Math.hypot(v0.x,v0.y);if(L0<1e-6)return;
  if(!d.scl)a.rotation_deg=Math.max(-30,Math.min(30,a0.rotation_deg+(Math.atan2(v1.y,v1.x)-Math.atan2(v0.y,v0.x))*180/Math.PI));
  if(!d.rot)a.scale=Math.max(.8,Math.min(1.25,a0.scale*Math.hypot(v1.x,v1.y)/L0))}
 a.shift_x=Math.max(-2000,Math.min(2000,a.shift_x));a.shift_y=Math.max(-2000,Math.min(2000,a.shift_y))}
async function imgAdjSend(a){requireProject();await api(`/api/projects/${pid}/imagery/${imgAdj.index}/adjust`,json('PUT',{shift_x:a.shift_x,shift_y:a.shift_y,rotation_deg:a.rotation_deg,scale:a.scale}));await load(pid);localTiles.clear();await localUi();imgAdj.cur={...imgSrc().adjust};draw()}
const imgAdjCommit=guard(async a0=>{imgAdj.k0=null;imgAdj.undo.push({index:imgAdj.index,a:{...a0}});imgAdj.redo=[];await imgAdjSend(imgAdj.cur);toolOptions();const a=imgAdj.cur;msg(`Imagem ajustada: deslocamento ${a.shift_x.toFixed(2)} / ${a.shift_y.toFixed(2)} m, rotação ${a.rotation_deg.toFixed(3)}°, escala ${a.scale.toFixed(4)}. O arquivo original não é alterado.`)});
async function imgAdjStep(from,to){const h=from.pop();if(!h)return msg('Nada para desfazer/refazer no ajuste da imagem.',true);imgAdj.index=h.index;to.push({index:h.index,a:{...(imgSrc()?.adjust||h.a)}});imgAdj.cur={...h.a};await imgAdjSend(h.a);toolOptions()}
function imgAdjOptions(o){if(!localInfo?.sources?.length){o.innerHTML='<p class="muted">Envie uma imagem local (Camadas, imagem local e intercâmbio).</p>';return}
 o.innerHTML=`<div class="grid"><label>Imagem<select id="adjImg">${localInfo.sources.map(s=>`<option value="${s.index}" ${s.index===imgAdj.index?'selected':''}>${esc(s.name)}</option>`).join('')}</select></label></div><div class="row"><button id="adjUndo" type="button">↶ Desfazer ajuste</button><button id="adjRedo" type="button">↷ Refazer</button><button id="adjReset" type="button">Posição original</button></div>`;
 $('adjImg').onchange=()=>{imgAdj.index=Number($('adjImg').value);imgAdj.cur=null;draw()};$('adjUndo').onclick=guard(()=>imgAdjStep(imgAdj.undo,imgAdj.redo));$('adjRedo').onclick=guard(()=>imgAdjStep(imgAdj.redo,imgAdj.undo));
 $('adjReset').onclick=guard(async()=>{const a0={...(imgAdj.cur||imgSrc().adjust)};imgAdj.cur={shift_x:0,shift_y:0,rotation_deg:0,scale:1};await imgAdjCommit(a0)})}
function drawImgAdjust(){if(tool!=='imgadjust')return;const g=imgCorners();if(!g)return;poly(g.pts,true);ctx.strokeStyle='#ffd84d';ctx.lineWidth=2;ctx.setLineDash([8,5]);ctx.stroke();ctx.setLineDash([]);
 for(const p of g.pts){const [x,y]=W2C(p);ctx.fillStyle='#fff';ctx.strokeStyle='#b08a00';ctx.lineWidth=2;ctx.beginPath();ctx.rect(x-6,y-6,12,12);ctx.fill();ctx.stroke()}
 const a=imgAdj.cur,C={x:g.c.x+a.shift_x,y:g.c.y+a.shift_y},[x,y]=W2C(C);ctx.strokeStyle='#ffd84d';ctx.beginPath();ctx.moveTo(x-9,y);ctx.lineTo(x+9,y);ctx.moveTo(x,y-9);ctx.lineTo(x,y+9);ctx.stroke()}

// ---------------- 1.19: limpar trabalho / retirar projeto ----------------
$('resetWork')?.addEventListener('click',guard(async()=>{requireProject();const r=await api('/api/reset_groups');$('resetGroups').innerHTML=r.groups.map(g=>`<label><input type="checkbox" data-group="${g.id}" ${g.default?'checked':''}> ${esc(g.label)}</label>`).join('');$('resetOutputs').checked=false;$('resetDialog').showModal()}));
$('resetCancel')?.addEventListener('click',()=>$('resetDialog').close());
$('resetGo')?.addEventListener('click',guard(async()=>{const groups=[...document.querySelectorAll('#resetGroups input:checked')].map(i=>i.dataset.group);if(!groups.length)throw Error('Escolha ao menos um grupo.');
 const r=await api(`/api/projects/${pid}/reset_work`,json('POST',{groups,outputs:$('resetOutputs').checked}));$('resetDialog').close();await load(pid);
 const n=Object.values(r.cleared).reduce((a,b)=>a+b,0);msg(`Trabalho limpo (${n} item(ns)). Segmento mantido. Cópia da configuração anterior: ${r.backup}. Use “Desfazer limpeza” para voltar.`)}));
$('resetUndo')?.addEventListener('click',guard(async()=>{requireProject();const r=await api(`/api/projects/${pid}/reset_work/undo`,{method:'POST'});await load(pid);msg('Configuração anterior à limpeza restaurada ('+r.restored+').')}));
$('trashProject')?.addEventListener('click',guard(async()=>{requireProject();const name=cfg.name||pid;if(!confirm(`Retirar o projeto “${name}” da lista? A pasta vai para “_lixeira” dentro da pasta de projetos e pode ser recuperada manualmente.`))return;const r=await api(`/api/projects/${pid}`,{method:'DELETE'});pid='';cfg={};meta=null;geo=null;baseImage=null;editor=null;await list();draw();msg('Projeto retirado da lista (pasta '+r.trash+' em _lixeira).')}));

const _drawBase=draw;draw=function(){_drawBase();if(ready())drawImgAdjust()};
// 1.19: ícones nos títulos das seções.
(()=>{const P={'1.':'M3 7a2 2 0 012-2h4l2 2h8a2 2 0 012 2v8a2 2 0 01-2 2H5a2 2 0 01-2-2z','2.':'M12 9a3 3 0 100 6 3 3 0 000-6zM19 12l2-1-1-3-2 .3-1.3-1.3.3-2-3-1-1 2h-2L9 3 6 4l.3 2L5 7.3 3 7 2 10l2 1v2l-2 1 1 3 2-.3L6.3 18 6 20l3 1 1-2h2l1 2 3-1-.3-2 1.3-1.3 2 .3 1-3-2-1z',
 'Camadas':'M12 3l9 5-9 5-9-5zM3 13l9 5 9-5M3 17l9 5 9-5','5.':'M4 6h12v12H4zM16 10l5-3v10l-5-3','Manutenção':'M14.7 6.3a4 4 0 00-5.4 5.4L3 18l3 3 6.3-6.3a4 4 0 005.4-5.4l-2.5 2.5-2.5-.6-.6-2.5z',
 '3.':'M9 4L3 6v14l6-2 6 2 6-2V4l-6 2zM9 4v14M15 6v14','4.':'M12 21s-6-6-6-11a6 6 0 0112 0c0 5-6 11-6 11zM12 8a2 2 0 100 4 2 2 0 000-4z','Progresso':'M4 20V10M10 20V4M16 20v-7M22 20H2'};
 document.querySelectorAll('section>h2').forEach(h=>{const k=Object.keys(P).find(k=>h.textContent.trim().startsWith(k));if(k&&!h.querySelector('.ico'))h.insertAdjacentHTML('afterbegin',`<span class="ico"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="${P[k]}"/></svg></span>`)})})();

// ---------------- 1.20: áreas de pista e acostamentos ----------------
const PAV_LABEL={pavement:'Pista nova',existing_pavement:'Pista existente',shoulder:'Acostamento'};
const PAV_STYLE={pavement:['#3a414355','#d8b45acc',9],existing_pavement:['#8fa3b455','#9fb4c8cc',9],shoulder:['#85898355','#e8dcaacc',6]};
let pavKind='pavement',pavMat='auto';
const MAT_LABEL={auto:'Material padrão do projeto',flexivel:'Flexível (asfalto)',rigido:'Rígido (concreto)'};
function pickRing(w){if(!vec||!vec.layers)return null;let best=null;
 for(const [role,list] of Object.entries(vec.layers)){if(!Array.isArray(list))continue;for(const r of list){if(!r.c||!r.p||r.p.length<3)continue;const P=r.p;let inside=false;for(let i=0,j=P.length-1;i<P.length;j=i++){const [xi,yi]=P[i],[xj,yj]=P[j];if(((yi>w.y)!==(yj>w.y))&&w.x<(xj-xi)*(w.y-yi)/(yj-yi)+xi)inside=!inside}
  if(!inside)continue;let a=0;for(let i=0,j=P.length-1;i<P.length;j=i++)a+=(P[j][0]+P[i][0])*(P[j][1]-P[i][1]);a=Math.abs(a/2);if(!best||a<best.a)best={a,p:P}}}
 if(!best)return null;let P=best.p;if(P.length>1&&P[0][0]===P[P.length-1][0]&&P[0][1]===P[P.length-1][1])P=P.slice(0,-1);return P.length>=3?P:null}

// 1.20: perfil "Apresentação técnica" (alinhado à especificação de vídeo técnico): só altera campos da configuração.
$('presetTech')?.addEventListener('click',guard(async()=>{requireProject();const set={width:2560,fps:24,duration_s:96,style_profile:'tecnico',camera_mode:'continuo',flow_arrows:'off'};
 for(const [k,v] of Object.entries(set))if($(k))$(k).value=v;$('traffic').checked=false;$('progress_indicator').checked=true;await save();
 $('presetInfo').textContent='Aplicado: 2560×1440, 24 q/s, 96 s, hachuras técnicas, voo contínuo, sem setas de fluxo e sem veículos, indicador de progresso. Ajuste a duração à extensão do trecho e gere a prévia.';msg('Perfil “Apresentação técnica” aplicado.')}));

$('project_contrast')?.addEventListener('input',()=>{$('pcVal').textContent=Math.round(Number($('project_contrast').value)*100)+'%'});

// ---------------- 1.21: representação do pavimento (escolha e alteração) ----------------
const PAT_LABEL={auto:'Automática (material + montagem)',solido:'Sólido',diagonal:'Hachura diagonal',cruzada:'Hachura cruzada',pontilhado:'Pontilhado',placas:'Placas de concreto (juntas)'};
const ROLE_LABEL={pavement:'Pista nova',existing_pavement:'Pista existente',shoulder:'Acostamento'};
const PAV_DEF={pavement:['#2a3033','#c8a55a'],existing_pavement:['#6f8291','#b7c7d4'],shoulder:['#5f5b51','#d6cda4']};
function pavStylesUi(){const box=$('pavStyles');if(!box)return;const st=cfg.pavement_styles||{};
 box.innerHTML='<table class="pavst">'+Object.keys(ROLE_LABEL).map(r=>{const v={pattern:'auto',fill:'',hatch:'',spacing_m:3,angle_deg:45,line_m:.15,...(st[r]||{})};
  return `<tr data-role="${r}"><td><b>${ROLE_LABEL[r]}</b><br><canvas class="swatch" width="84" height="48"></canvas></td><td><select data-k="pattern">${Object.entries(PAT_LABEL).map(([k,l])=>`<option value="${k}" ${v.pattern===k?'selected':''}>${l}</option>`).join('')}</select>
  <div class="grid"><label>Preenchimento<input data-k="fill" type="color" value="${v.fill||PAV_DEF[r][0]}"></label><label>Hachura/juntas<input data-k="hatch" type="color" value="${v.hatch||PAV_DEF[r][1]}"></label><label>Espaçamento (m)<input data-k="spacing_m" type="number" min="0.3" max="20" step="0.1" value="${v.spacing_m}"></label><label>Ângulo (°)<input data-k="angle_deg" type="number" min="-90" max="90" step="1" value="${v.angle_deg}"></label><label>Espessura do traço (m)<input data-k="line_m" type="number" min="0.02" max="1" step="0.01" value="${v.line_m}"></label></div></td></tr>`}).join('')+'</table>';
 box.querySelectorAll('tr[data-role]').forEach(drawSwatch)}
function drawSwatch(tr){const c=tr.querySelector('canvas'),g=c.getContext('2d'),v=readStyle(tr),r=tr.dataset.role;g.fillStyle=v.pattern==='auto'?PAV_DEF[r][0]:v.fill;g.fillRect(0,0,c.width,c.height);g.strokeStyle=v.hatch;g.fillStyle=v.hatch;const k=6;// 6 px por metro na amostra
 const S=v.spacing_m*k,w=Math.max(1,v.line_m*k);g.lineWidth=w;const lines=a=>{const t=a*Math.PI/180;g.save();g.translate(c.width/2,c.height/2);g.rotate(-t);g.beginPath();for(let y=-120;y<=120;y+=S){g.moveTo(-120,y);g.lineTo(120,y)}g.stroke();g.restore()};
 if(v.pattern==='diagonal'||v.pattern==='auto')lines(v.angle_deg);if(v.pattern==='cruzada'){lines(v.angle_deg);lines(v.angle_deg+90)}
 if(v.pattern==='pontilhado')for(let x=S/4;x<c.width;x+=S/2)for(let y=S/4;y<c.height;y+=S/2){g.beginPath();g.arc(x,y,w,0,7);g.fill()}
 if(v.pattern==='placas'){g.lineWidth=Math.max(1,w);for(let x=0;x<c.width;x+=(cfg.joint_spacing_m||5)*k){g.beginPath();g.moveTo(x,0);g.lineTo(x,c.height);g.stroke()}}}
function readStyle(tr){const o={};tr.querySelectorAll('[data-k]').forEach(el=>{o[el.dataset.k]=el.type==='number'?Number(el.value):el.value});return o}
$('pavStyles')?.addEventListener('change',e=>{const tr=e.target.closest('tr[data-role]');if(!tr||!pid)return;const v=readStyle(tr),r=tr.dataset.role;const st={...(cfg.pavement_styles||{})};
 if(v.pattern==='auto')delete st[r];else st[r]={...v,fill:v.fill.toLowerCase()===PAV_DEF[r][0]?'':v.fill,hatch:v.hatch.toLowerCase()===PAV_DEF[r][1]?'':v.hatch};
 cfg.pavement_styles=st;drawSwatch(tr);scheduleSave();msg(`Representação de “${ROLE_LABEL[r]}”: ${PAT_LABEL[v.pattern]}. Gere a prévia para ver no vídeo.`)});
$('pavStyles')?.addEventListener('input',e=>{const tr=e.target.closest('tr[data-role]');if(tr)drawSwatch(tr)});
{const _l3=load;load=async id=>{await _l3(id);try{pavStylesUi()}catch{}}}

// =====================================================================================================
// 1.22 — Edição tipo CAD: seleção com grips, propriedades com Enter, linha de comando, snap, orto,
// alinhamento por cliques, mover/apagar, salvar/salvar como.
// =====================================================================================================

const OBJ_SPECS=[
 ['signs','Placa','pt',o=>[[o,'point']]],
 ['pois','Intervenção','pt',o=>[[o,null]].concat(o.anchor?[[o,'anchor']]:[])],
 ['highlights','Destaque','pt',o=>[[o,'point']].concat(o.label?[[o,'label']]:[])],
 ['cities','Cidade','pt',o=>[[o,'point']]],
 ['crosswalks','Faixa de pedestre','line',o=>[[o,'a'],[o,'b']]],
 ['lane_ranges','Faixa adicional','line',o=>[[o,'start'],[o,'end']]],
 ['shoulder_marks','Acostamento','line',o=>[[o,'start'],[o,'end']]],
 ['direction_marks','Seta de sentido','line',o=>[[o,'start'],[o,'end']]],
 ['accesses','Acesso','poly',o=>o.points.map((_,i)=>[o.points,i])],
 ['traffic_paths','Fluxo incluído','poly',o=>o.points.map((_,i)=>[o.points,i])],
 ['hatch_areas','Zebrado','area',o=>o.points.map((_,i)=>[o.points,i])],
 ['pavement_areas','Área de pista','area',o=>o.points.map((_,i)=>[o.points,i])],
 ['lane_zones','Faixas por trecho','area',o=>o.points.map((_,i)=>[o.points,i])],
 ['lane_blocks','Interdição','area',o=>o.points.map((_,i)=>[o.points,i])],
 ['clean_areas','Área sem sinalização','area',o=>o.map((_,i)=>[o,i])],
 ['exclusions','Área de exclusão','area',o=>o.map((_,i)=>[o,i])],
 ['crossing_zones','Travessia','auto',o=>o.kind==='point'?[[o,'point']]:o.points.map((_,i)=>[o.points,i])],
 ['no_connection_zones','Sem conexão','auto',o=>o.kind==='point'?[[o,'point']]:o.points.map((_,i)=>[o.points,i])],
 ['oae_marks','OAE','auto',o=>o.polygon&&o.polygon.length>=4?o.polygon.map((_,i)=>[o.polygon,i]):[[o,'start'],[o,'end']]],
];
const ENUMS={kind:{pavement_areas:PAV_LABEL},material:MAT_LABEL,color:{white:'Branco',yellow:'Amarelo'},code:SIGN_LABEL,mode:{both:'Entrada e saída',in:'Só entrada',out:'Só saída',partial:'Parcial',total:'Total',allow:'Permitida',deny:'Proibida'},category:HL_LABEL};
function gripGet([c,k]){return k===null?{x:c.x,y:c.y}:c[k]}
function gripSet([c,k],w){const p={x:+w.x,y:+w.y};if(k===null){c.x=p.x;c.y=p.y}else c[k]=p}
function objList(){const out=[];for(const [key,label,shape,fn] of OBJ_SPECS){const L=M[key];if(!Array.isArray(L))continue;L.forEach((o,i)=>{try{const g=fn(o).filter(r=>{const p=gripGet(r);return p&&isFinite(p.x)});if(g.length)out.push({key,i,label,shape:shape==='auto'?(g.length===1?'pt':g.length===2?'line':'area'):shape,o,grips:g})}catch{}})}
 if(M.custom_axis&&M.custom_axis.points?.length)out.push({key:'custom_axis',i:0,label:'Alinhamento',shape:'poly',o:M.custom_axis,grips:M.custom_axis.points.map((_,i)=>[M.custom_axis.points,i])});return out}
function objOf(s){return s?objList().find(o=>o.key===s.key&&o.i===s.i)||null:null}
function segDist(px,py,ax,ay,bx,by){const dx=bx-ax,dy=by-ay,L=dx*dx+dy*dy;let t=L?((px-ax)*dx+(py-ay)*dy)/L:0;t=Math.max(0,Math.min(1,t));return Math.hypot(px-ax-t*dx,py-ay-t*dy)}
function hitObject(c){let best=null;for(const o of objList()){const P=o.grips.map(g=>W2C(gripGet(g)));let d=Infinity;
  if(o.shape==='pt'){d=Math.min(...P.map(([x,y])=>Math.hypot(x-c.cx,y-c.cy)));if(o.key==='signs')d=Math.min(d,Math.max(0,Math.hypot(P[0][0]-c.cx,P[0][1]-24-c.cy)-10))}
  else{for(let k=0;k+1<P.length;k++)d=Math.min(d,segDist(c.cx,c.cy,...P[k],...P[k+1]));if(o.shape==='area'&&P.length>2){d=Math.min(d,segDist(c.cx,c.cy,...P[P.length-1],...P[0]));let inside=false;for(let i=0,j=P.length-1;i<P.length;j=i++){const [xi,yi]=P[i],[xj,yj]=P[j];if(((yi>c.cy)!==(yj>c.cy))&&c.cx<(xj-xi)*(c.cy-yi)/(yj-yi)+xi)inside=!inside}if(inside)d=Math.min(d,7)}}
  if(d<=9&&(!best||d<best.d))best={key:o.key,i:o.i,d}}return best}
function hitGrip(c){const o=objOf(sel);if(!o)return null;for(let k=0;k<o.grips.length;k++){const [x,y]=W2C(gripGet(o.grips[k]));if(Math.abs(x-c.cx)<=7&&Math.abs(y-c.cy)<=7)return {o,k}}return null}
function drawSelection(){if(nativeSel){poly(nativeSel.p.map(p=>({x:p[0],y:p[1]})));if(nativeSel.p.length===1){const [x,y]=W2C({x:nativeSel.p[0][0],y:nativeSel.p[0][1]});ctx.rect(x-18,y-40,36,46)}ctx.strokeStyle='#ff4fd8';ctx.lineWidth=4;ctx.stroke()}const o=objOf(sel);if(!o)return;const P=o.grips.map(g=>W2C(gripGet(g)));ctx.save();ctx.strokeStyle='#4fa3ff';ctx.lineWidth=2;ctx.setLineDash([6,4]);
 if(o.shape!=='pt'){ctx.beginPath();P.forEach(([x,y],k)=>k?ctx.lineTo(x,y):ctx.moveTo(x,y));if(o.shape==='area')ctx.closePath();ctx.stroke()}ctx.setLineDash([]);
 for(const [x,y] of P){ctx.fillStyle=drag?.type==='grip'?'#ff4d4d':'#2f7cf6';ctx.strokeStyle='#fff';ctx.lineWidth=1.5;ctx.fillRect(x-5,y-5,10,10);ctx.strokeRect(x-5,y-5,10,10)}ctx.restore()}
function drawSnap(){if(!snapMark||!lastWorld)return;const [x,y]=W2C(snapMark.w);ctx.save();ctx.strokeStyle='#ffd400';ctx.lineWidth=2;ctx.beginPath();
 if(snapMark.kind==='vértice')ctx.rect(x-6,y-6,12,12);else if(snapMark.kind==='ponto médio'){ctx.moveTo(x,y-7);ctx.lineTo(x+7,y+6);ctx.lineTo(x-7,y+6);ctx.closePath()}else{ctx.moveTo(x-6,y-6);ctx.lineTo(x+6,y+6);ctx.moveTo(x+6,y-6);ctx.lineTo(x-6,y+6)}
 ctx.stroke();ctx.fillStyle='#ffd400';ctx.font='11px system-ui';ctx.fillText(snapMark.kind,x+9,y-8);ctx.restore()}
// ---------- snap ----------
function buildSnap(){snapIndex=new Map();const B=5;const add=(x,y,kind)=>{const k=Math.floor(x/B)+','+Math.floor(y/B);let a=snapIndex.get(k);if(!a)snapIndex.set(k,a=[]);a.push([x,y,kind])};
 for(const list of Object.values(vec?.layers||{})){if(!Array.isArray(list))continue;for(const r of list){if((M.excluded_entities||[]).includes(r.entity_id))continue;const P=r.p||[];for(let i=0;i<P.length;i++){add(P[i][0],P[i][1],'vértice');if(i+1<P.length)add((P[i][0]+P[i+1][0])/2,(P[i][1]+P[i+1][1])/2,'ponto médio')}}}}
function snapPoint(c){const r=10/Math.max(pxPerM(),1e-9);let best=null;const B=5;const w=c.w;
 const cand=(x,y,kind,pri)=>{const d=Math.hypot(x-w.x,y-w.y);if(d<=r&&(!best||d+pri*r<best.score))best={w:{x,y},kind,score:d+pri*r}};
 if(!snapIndex)buildSnap();const n=Math.ceil(r/B);const bx=Math.floor(w.x/B),by=Math.floor(w.y/B);
 if(n<=40)for(let i=-n;i<=n;i++)for(let j=-n;j<=n;j++){const a=snapIndex.get((bx+i)+','+(by+j));if(a)for(const [x,y,k] of a)cand(x,y,k,0)}
 for(const o of objList())if(!(drag?.type==='grip'&&o.key===drag.g.o.key&&o.i===drag.g.o.i))for(const g of o.grips){const p=gripGet(g);cand(p.x,p.y,'vértice',0)}
 if(!best&&axisData()){const p=projectAxis(w);if(p&&p.dist<=r)best={w:p.point,kind:'eixo',score:p.dist+r}}
 return best}
function snapActive(){return $('snapOn')?.checked!==false&&ready()&&(tool!=='pan'||drag?.type==='grip'||drag?.type==='objmove'||!!cadCmd)}
function ortho(w){if(!$('orthoOn')?.checked)return w;const ref=draft?.pts?.length?draft.pts[draft.pts.length-1]:cadCmd?.base||null;if(!ref)return w;const dx=w.x-ref.x,dy=w.y-ref.y;return Math.abs(dx)>=Math.abs(dy)?{x:w.x,y:ref.y}:{x:ref.x,y:w.y}}
{const _cp=canvasPt;canvasPt=function(e){const c=_cp(e);if(c.w){snapMark=null;if(snapActive()){const s=snapPoint(c);if(s){c.w=s.w;snapMark=s}}c.w=ortho(c.w)}return c}}
// ---------- seleção, grips e mover ----------
canvas.addEventListener('pointerdown',e=>{if(!ready()||e.button!==0||spaceDown||cadCmd)return;if(tool!=='pan')return;const c=canvasPt(e);try{canvas.setPointerCapture(e.pointerId)}catch{};canvas.focus({preventScroll:true});
 const g=hitGrip(c);if(g){checkpoint();drag={type:'grip',g};e.stopImmediatePropagation();canvas.style.cursor='move';return}
 const h=hitObject(c);if(h){if(e.shiftKey){const k=multiSel.findIndex(s=>s.key===h.key&&s.i===h.i);if(k>=0)multiSel.splice(k,1);else multiSel.push({key:h.key,i:h.i});sel=multiSel.at(-1)||null;showProps();draw();e.stopImmediatePropagation();return}if(sel&&sel.key===h.key&&sel.i===h.i){checkpoint();const o=objOf(sel);drag={type:'objmove',w0:c.w,base:o.grips.map(gripGet),o}}else{sel={key:h.key,i:h.i};multiSel=[sel];nativeSel=null;showProps();draw();msg(`Selecionado: ${objOf(sel).label}. Arraste um grip ou o objeto; Delete apaga; edite as propriedades e confirme com Enter.`)}e.stopImmediatePropagation();return}
 if(sel){sel=null;multiSel=[];showProps();draw()}},true);
canvas.addEventListener('pointermove',e=>{if(!drag||(drag.type!=='grip'&&drag.type!=='objmove'))return;const c=canvasPt(e);lastWorld=c.w;
 if(drag.type==='grip'){gripSet(drag.g.o.grips[drag.g.k],c.w);drag.moved=true}else{const dx=c.w.x-drag.w0.x,dy=c.w.y-drag.w0.y;drag.o.grips.forEach((g,k)=>gripSet(g,{x:drag.base[k].x+dx,y:drag.base[k].y+dy}));drag.moved=true}
 e.stopImmediatePropagation();draw();cursorInfo(c.w)},true);
canvas.addEventListener('pointerup',e=>{if(!drag||(drag.type!=='grip'&&drag.type!=='objmove'))return;const d=drag;drag=null;canvas.style.cursor='grab';e.stopImmediatePropagation();
 if(d.moved){afterGeomEdit(d.o||d.g.o);changed(d.type==='grip'?'Grip movido.':'Objeto movido.')}else undoStack.pop();showProps();draw()},true);
function afterGeomEdit(o){if(o&&o.key==='oae_marks'&&typeof oaeEnds==='function')try{oaeEnds(o.o)}catch{}}
function deleteSel(){
 if(nativeSel){checkpoint();const list=nativeSel.sign_id?M.excluded_signs:M.excluded_entities;const id=nativeSel.sign_id||nativeSel.entity_id;if(!list.includes(id))list.push(id);nativeSel=null;sel=null;multiSel=[];showProps();buildVectorPaths();changed('Entidade DXF excluída deste projeto. Atualize os fluxos ou a prévia para recalcular o vídeo. O DXF original foi preservado.');return true}
 const objects=(multiSel.length?multiSel:[sel]).map(objOf).filter(Boolean);if(!objects.length)return false;checkpoint();
 objects.sort((a,b)=>b.i-a.i).forEach(o=>{if(o.key==='custom_axis')M.custom_axis=null;else M[o.key].splice(o.i,1)});
 sel=null;multiSel=[];showProps();changed(`${objects.length} objeto(s) apagado(s). Ctrl+Z desfaz.`);return true}
// ---------- propriedades ----------
function propInput(path,v,key,listKey){const id='pp_'+path.replace(/\W/g,'_');
 const en=ENUMS[key]&&(ENUMS[key][listKey]||(!Object.values(ENUMS[key]).some(x=>typeof x==='object')&&ENUMS[key]));
 if(en&&typeof en==='object')return `<select id="${id}" data-pp="${path}">${Object.entries(en).map(([k,l])=>`<option value="${k}" ${String(v)===k?'selected':''}>${esc(l)}</option>`).join('')}</select>`;
 if(typeof v==='boolean')return `<input id="${id}" data-pp="${path}" type="checkbox" ${v?'checked':''}>`;
 if(typeof v==='number')return `<input id="${id}" data-pp="${path}" type="number" step="any" value="${v}">`;
 return `<input id="${id}" data-pp="${path}" value="${esc(v??'')}">`}
function showProps(){const box=$('propPanel');if(!box)return;
 if(nativeSel){box.hidden=false;box.innerHTML=`<h3>${nativeSel.sign_id?'Placa':'Entidade DXF'}</h3><p>Layer: ${esc(nativeSel.layer)} · ID: ${esc(nativeSel.entity_id)}</p><button type="button" data-ppact="del" class="danger">Excluir do projeto (Del)</button><p>O arquivo DXF original é preservado. Ctrl+Z restaura a entidade.</p>`;return}
 const o=objOf(sel);if(!o){box.hidden=true;box.innerHTML='';return}box.hidden=false;
 if(multiSel.length>1){box.innerHTML=`<h3>${multiSel.length} objetos selecionados</h3><button type="button" data-ppact="del" class="danger">Apagar seleção (Del)</button><p>Shift+clique inclui ou retira um objeto. Esc limpa a seleção.</p>`;return}
 const fields=Object.entries(o.key==='clean_areas'||o.key==='exclusions'?{}:o.o).filter(([k,v])=>!['id','points','polygon','x','y'].includes(k)&&(v===null||['string','number','boolean'].includes(typeof v)));
 box.innerHTML=`<h3>Propriedades · ${esc(o.label)}</h3><table>`+fields.map(([k,v])=>`<tr><td>${esc(k)}</td><td>${propInput(k,v,k,o.key)}</td></tr>`).join('')+'</table>'+
  `<h4>Grips (coordenadas ${esc(cfg.crs||'')}, m)</h4><table>`+o.grips.map((g,k)=>{const p=gripGet(g);return `<tr><td>${k+1}</td><td>X<input data-grip="${k}" data-ax="x" type="number" step="0.001" value="${p.x.toFixed(3)}"></td><td>Y<input data-grip="${k}" data-ax="y" type="number" step="0.001" value="${p.y.toFixed(3)}"></td></tr>`}).join('')+'</table>'+
  `<div class="row"><button type="button" data-ppact="move">Mover (M)</button><button type="button" data-ppact="del" class="danger">Apagar (Del)</button><button type="button" data-ppact="zoom">Ver</button><button type="button" data-ppact="close">Fechar</button></div><p class="muted">Altere um valor e pressione Enter para confirmar (Esc desfaz a digitação).</p>`}
function commitProp(el){const o=objOf(sel);if(!o)return;checkpoint();
 if(el.dataset.grip!==undefined){const g=o.grips[Number(el.dataset.grip)],p=gripGet(g);const v=Number(String(el.value).replace(',','.'));if(String(el.value).trim()===''||!isFinite(v)){undoStack.pop();return msg('Coordenada inválida.',true)}gripSet(g,{...p,[el.dataset.ax]:v});afterGeomEdit(o)}
 else{const k=el.dataset.pp,old=o.o[k];let v=el.type==='checkbox'?el.checked:el.type==='number'?Number(String(el.value).replace(',','.')):el.value;
  if(typeof old==='string'&&old.trim()!==''&&String(v).trim()===''&&['name','title'].includes(k)){undoStack.pop();showProps();return msg(`O campo “${k}” não pode ficar vazio.`,true)}
  if(el.type==='number'&&String(el.value).trim()===''&&old!==null){undoStack.pop();showProps();return msg(`O campo “${k}” não pode ficar vazio.`,true)}if(typeof old==='number'&&!isFinite(v)){undoStack.pop();return msg('Valor numérico inválido.',true)}if(old===null&&el.value==='')v=null;o.o[k]=v}
 changed('Propriedade alterada.');showProps()}
document.addEventListener('keydown',e=>{const el=e.target;if(!el.closest||!el.closest('#propPanel'))return;if(e.key==='Enter'&&(el.dataset.pp!==undefined||el.dataset.grip!==undefined)){e.preventDefault();commitProp(el)}if(e.key==='Escape'){e.preventDefault();showProps()}});
document.addEventListener('change',e=>{const el=e.target;if(el.closest&&el.closest('#propPanel')&&(el.tagName==='SELECT'||el.type==='checkbox'))commitProp(el)});
document.addEventListener('click',e=>{const b=e.target.closest&&e.target.closest('#propPanel [data-ppact]');if(!b)return;const a=b.dataset.ppact;
 if(a==='del')deleteSel();else if(a==='close'){sel=null;showProps();draw()}else if(a==='zoom'){const o=objOf(sel);if(o)zoomTo(gripGet(o.grips[0]))}else if(a==='move')runCommand('MOVER')});
// ---------- linha de comando ----------
const CMD_ALIAS={M:'MOVER',MOVE:'MOVER',MOVER:'MOVER',E:'APAGAR',DEL:'APAGAR',ERASE:'APAGAR',APAGAR:'APAGAR',EXCLUIR:'APAGAR',PR:'PROPRIEDADES',PROPRIEDADES:'PROPRIEDADES',
 AL:'tool:align',ALINHAMENTO:'tool:align',ALIGN:'tool:align',PLACA:'tool:sign',ZEBRADO:'tool:hatch',AREA:'tool:pavarea',ÁREA:'tool:pavarea',ACOSTAMENTO:'tool:shoulder',ACESSO:'tool:access',
 KM:'tool:chain',KMINI:'tool:chain',KMFIM:'tool:chainend',PASSARELA:'tool:span',CHAMADA:'tool:anchor',DESTAQUE:'tool:highlight',OAE:'tool:oaepoly',FAIXA:'tool:crosswalk',
 P:'tool:pan',PAN:'tool:pan',NAVEGAR:'tool:pan',SEL:'tool:pan',ZOOM:'ZOOM',Z:'ZOOM',SALVAR:'SALVAR',SAVE:'SALVAR',SNAP:'SNAP',ORTO:'ORTO',ORTHO:'ORTO',DIST:'DIST',DI:'DIST',ID:'ID'};
function prompt_(t){$('cmdPrompt').textContent=t}
function parsePoint(txt){const t=txt.trim();const rel=t.startsWith('@');const s=(rel?t.slice(1):t).replace(/\s*[;\s]\s*/,'|').replace(/^([^,|]+),([^,|]+)$/,'$1|$2');const m=s.split('|');if(m.length!==2)return null;const a=Number(m[0].replace(',','.')),b=Number(m[1].replace(',','.'));if(!isFinite(a)||!isFinite(b))return null;
 if(rel){const r=lastPick||cadCmd?.base;if(!r)return null;return {x:r.x+a,y:r.y+b}}return {x:a,y:b}}
function feedPoint(w){lastPick=w;if(cadCmd){cadCmd.step(w);return}if(tool==='pan')return msg('Ponto digitado: escolha antes uma ferramenta ou comando.',true);click(w,{shiftKey:false,ctrlKey:false});draw()}
function runCommand(raw){const t=raw.trim();if(!t){if(cadCmd){cadCmd=null;prompt_('Comando:');msg('Comando encerrado.');draw();return}endCommand();return}
 const pt=parsePoint(t);if(pt){feedPoint(pt);return}
 const c=CMD_ALIAS[t.toUpperCase()];if(!c)return msg(`Comando desconhecido: ${t}. Exemplos: MOVER (M), APAGAR (E), PROPRIEDADES (PR), ALINHAMENTO (AL), PLACA, AREA, ACOSTAMENTO, KMINI, KMFIM, SALVAR, DIST, ID, ou coordenadas X,Y e @dx,dy.`,true);
 if(!c.startsWith('tool:')&&!['SNAP','ORTO','SALVAR'].includes(c)){draft=null;cadCmd=null;if(tool!=='pan')setTool('pan')}
 if(c.startsWith('tool:')){setTool(c.slice(5));prompt_(TOOLS.find(x=>x[0]===c.slice(5))?.[1]+':');return}
 if(c==='APAGAR'){if(!deleteSel())msg('Selecione um objeto (clique nele com Navegar) e use APAGAR ou a tecla Delete.',true);return}
 if(c==='PROPRIEDADES'){if(!sel)return msg('Selecione um objeto para ver as propriedades.',true);showProps();$('propPanel').scrollIntoView({block:'nearest'});return}
 if(c==='SALVAR'){$('saveProject')?.click();return}
 if(c==='SNAP'){$('snapOn').checked=!$('snapOn').checked;return msg('Snap '+($('snapOn').checked?'ligado':'desligado')+'.')}
 if(c==='ORTO'){$('orthoOn').checked=!$('orthoOn').checked;return msg('Orto '+($('orthoOn').checked?'ligado':'desligado')+'.')}
 if(c==='ZOOM'){fitView();return}
 if(c==='ID'){cadCmd={step(w){msg(`X ${w.x.toFixed(3)} · Y ${w.y.toFixed(3)}`+(axisData()?` · km ${formatKm(kmOf(w).km)}`:''));cadCmd=null;prompt_('Comando:')}};prompt_('ID — clique ou digite o ponto:');return}
 if(c==='DIST'){cadCmd={pts:[],step(w){this.pts.push(w);this.base=w;if(this.pts.length===1)return prompt_('DIST — segundo ponto:');const [a,b]=this.pts;const d=Math.hypot(b.x-a.x,b.y-a.y),az=(Math.atan2(b.x-a.x,b.y-a.y)*180/Math.PI+360)%360;msg(`Distância ${d.toFixed(3)} m · ΔX ${(b.x-a.x).toFixed(3)} · ΔY ${(b.y-a.y).toFixed(3)} · azimute ${az.toFixed(4)}°`);cadCmd=null;prompt_('Comando:')}};prompt_('DIST — primeiro ponto:');return}
 if(c==='MOVER'){const o=objOf(sel);if(!o)return msg('Selecione o objeto (clique nele com Navegar) e use MOVER.',true);
  cadCmd={step(w){if(!this.base){this.base=w;prompt_('MOVER — segundo ponto (ou @dx,dy):');return}const dx=w.x-this.base.x,dy=w.y-this.base.y;checkpoint();o.grips.forEach(g=>{const p=gripGet(g);gripSet(g,{x:p.x+dx,y:p.y+dy})});afterGeomEdit(o);cadCmd=null;prompt_('Comando:');changed(`${o.label} movido(a) ${Math.hypot(dx,dy).toFixed(3)} m.`);showProps()}};prompt_('MOVER — ponto base:');return}}
$('cmdLine')?.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();const v=e.target.value;e.target.value='';runCommand(v)}if(e.key==='Escape'){e.target.value='';cancelCommand()}});
// Cliques na tela durante um comando da linha de comando.
canvas.addEventListener('pointerdown',e=>{if(!cadCmd||e.button!==0||!ready())return;const c=canvasPt(e);e.stopImmediatePropagation();feedPoint(c.w);draw()},true);
// Atalhos: Delete apaga a seleção; Ctrl+S salva; F3 snap; F8 orto; teclas digitadas no editor vão para a linha de comando.
document.addEventListener('keydown',e=>{const t=e.target;const typing=t&&(t.tagName==='INPUT'||t.tagName==='TEXTAREA'||t.tagName==='SELECT');
 if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='s'){e.preventDefault();$('saveProject')?.click();return}
 if(e.key==='F3'){e.preventDefault();$('snapOn').checked=!$('snapOn').checked;msg('Snap '+($('snapOn').checked?'ligado':'desligado')+' (F3).');return}
 if(e.key==='F8'){e.preventDefault();$('orthoOn').checked=!$('orthoOn').checked;msg('Orto '+($('orthoOn').checked?'ligado':'desligado')+' (F8).');return}
 if(typing)return;
 if(e.key==='Delete'&&(sel||nativeSel)){e.preventDefault();deleteSel();return}
});
// Com a tela do editor em foco, letras e números vão para a linha de comando (como no CAD).
document.addEventListener('keydown',e=>{if(e.target!==canvas||e.key.length!==1||e.ctrlKey||e.altKey||e.metaKey||e.key===' '||!$('cmdLine'))return;if(!/[A-Za-zÀ-ú@0-9.,;\-]/.test(e.key))return;e.preventDefault();e.stopImmediatePropagation();const c=$('cmdLine');c.focus();c.value+=e.key},true);
// ---------- alinhamento por cliques ----------
TOOLS.splice(TOOLS.findIndex(t=>t[0]==='chain'),0,['align','⟋ Alinhamento (cliques)','Clique dois ou mais pontos sobre o eixo da via (o snap atrai para vértices e para o eixo do DXF) e pressione Enter: o alinhamento vira o eixo de referência do estaqueamento, da câmera e do sentido. Edite os grips depois (Navegar + clique na linha).']);
ICON_PATHS.align='M3 19C8 18 9 6 14 5s5 3 7 2M3 19h.01M14 5h.01M21 7h.01';
{const _click=click;click=function(w,e){if(tool==='align'){if(!draft||draft.type!=='align')draft={type:'align',pts:[]};draft.pts.push(w);draw();return msg(`Alinhamento: ${draft.pts.length} ponto(s). Continue clicando sobre o eixo; Enter conclui.`)}return _click(w,e)}}
{const _fin=finishDraft;finishDraft=async function(){const d=draft;if(d&&d.type==='align'){if(d.pts.length<2)return msg('Marque pelo menos dois pontos sobre o eixo.',true);draft=null;checkpoint();
  let L=0;for(let i=1;i<d.pts.length;i++)L+=Math.hypot(d.pts[i].x-d.pts[i-1].x,d.pts[i].y-d.pts[i-1].y);M.custom_axis={name:'Alinhamento do editor',points:d.pts,smooth:true,enabled:true};
  changed(`Alinhamento com ${d.pts.length} pontos (${L.toFixed(3)} m em linha reta entre os pontos). Clique “Analisar arquivos” para usá-lo como eixo de referência.`);return}return _fin()}}
function drawCustomAxis(){const a=M.custom_axis;if(!a||!a.points||a.points.length<2)return;poly(a.points);ctx.strokeStyle=a.enabled===false?'#9aa3a8':'#ff4fd8';ctx.lineWidth=2.5;ctx.setLineDash([12,5,3,5]);ctx.stroke();ctx.setLineDash([]);
 for(const p of a.points){const [x,y]=W2C(p);ctx.strokeStyle='#ff4fd8';ctx.lineWidth=2;ctx.beginPath();ctx.arc(x,y,4,0,7);ctx.stroke()}label('⟋ '+a.name,a.points[0],'#ffc6f4')}
{const _d=draw;draw=function(){_d();if(!ready())return;try{drawCustomAxis();drawSelection();drawSnap();if(draft&&draft.type==='align'){const pts=draft.pts.slice();if(lastWorld)pts.push(lastWorld);poly(pts);ctx.strokeStyle='#ff4fd8';ctx.lineWidth=2;ctx.setLineDash([6,4]);ctx.stroke();ctx.setLineDash([])}}catch(err){}}}
// ---------- precisão milimétrica no cursor ----------
{const _ci=cursorInfo;cursorInfo=function(w){_ci(w);if(!w)return;const c=$('cursor');c.textContent=c.textContent.replace(/X [-\d.]+ · Y [-\d.]+/,`X ${w.x.toFixed(3)} · Y ${w.y.toFixed(3)}`);
 const ref=draft?.pts?.length?draft.pts[draft.pts.length-1]:cadCmd?.base;if(ref){const d=Math.hypot(w.x-ref.x,w.y-ref.y),az=(Math.atan2(w.x-ref.x,w.y-ref.y)*180/Math.PI+360)%360;c.textContent+=` · Δ ${d.toFixed(3)} m · azimute ${az.toFixed(3)}°`}if(snapMark)c.textContent+=` · snap: ${snapMark.kind}`}}
// ---------- salvar / salvar como / excluir ----------
$('saveProject')?.addEventListener('click',guard(async()=>{requireProject();await save();$('saveState').textContent='salvo '+new Date().toLocaleTimeString();msg('Projeto salvo.')}));
$('saveAsProject')?.addEventListener('click',guard(async()=>{requireProject();await save();const name=prompt('Nome da cópia do projeto:',(cfg.name||'Projeto')+' (cópia)');if(!name)return;const r=await api(`/api/projects/${pid}/save_as`,json('POST',{name}));await list();await load(r.id);msg(`Projeto salvo como “${r.name}”. Você está trabalhando na cópia.`)}));
{const _l4=load;load=async id=>{snapIndex=null;sel=null;multiSel=[];nativeSel=null;layerCatalog=null;layerPrev=null;layerShow=null;showProps();await _l4(id);try{layerCatalog=analysis?{layers:analysis.layers}:await api(`/api/projects/${pid}/dxf_layers`);showLayers();updateDxfLayers()}catch(e){msg('Não foi possível listar os layers: '+e.message,true)}}}
{const _lg=loadGeo;loadGeo=async(...a)=>{snapIndex=null;return _lg(...a)}}
buildToolbar();

// Snap/orto lembrados por usuário (padrão: desligados, como nas versões anteriores).
try{for(const id of ['snapOn','orthoOn']){const v=localStorage.getItem('rodovia_'+id);if(v!==null&&$(id))$(id).checked=v==='1';$(id)?.addEventListener('change',()=>{try{localStorage.setItem('rodovia_'+id,$(id).checked?'1':'0')}catch{}})}}catch{}

// 1.24 — consistent command lifecycle, layer selection and non-destructive DXF deletion.
function cancelCommand(){
 clearTimeout(imgAdj.t);if(imgAdj.k0){imgAdj.cur={...imgAdj.k0};imgAdj.k0=null}
 if(drag&&['grip','objmove'].includes(drag.type)&&undoStack.length){M=JSON.parse(undoStack.pop());updateUndo()}
 if(drag?.type==='imgadj'&&drag.a0)imgAdj.cur={...drag.a0};
 drag=null;draft=null;cadCmd=null;spaceDown=false;snapMark=null;lastPick=null;
 sel=null;multiSel=[];nativeSel=null;$('cmdLine').value='';prompt_('Comando:');showProps();setTool('pan');
 msg('Comando cancelado. Seleção limpa.');canvas.focus({preventScroll:true})
}
document.addEventListener('keydown',e=>{
 if(e.isComposing||e.key!=='Escape'&&e.key!=='Enter')return;
 const el=e.target;if(el.closest?.('dialog[open]'))return;
 const inEditor=el.closest?.('#editorSection');if(!inEditor&&tool==='pan'&&!cadCmd&&!draft)return;
 if(el.closest?.('#propPanel')&&(el.dataset.pp!==undefined||el.dataset.grip!==undefined))return;
 if(e.key==='Escape'){e.preventDefault();e.stopImmediatePropagation();cancelCommand();return}
 if(el.id==='cmdLine')return;
 if(el.tagName==='TEXTAREA'||el.isContentEditable)return;
 e.preventDefault();e.stopImmediatePropagation();
 if(cadCmd){cadCmd=null;prompt_('Comando:')}
 guard(endCommand)().then(()=>canvas.focus({preventScroll:true}));
},true);
function filterLayers(){const query=($('layerSearch')?.value||'').trim().toLocaleLowerCase();for(const tr of $('layers').rows)tr.hidden=!tr.textContent.toLocaleLowerCase().includes(query)}
$('layerSearch')?.addEventListener('input',filterLayers);
$('ignoreLayers')?.addEventListener('click',()=>{for(const row of $('layers').rows)if(!row.hidden)row.querySelector('select').value='';scheduleSave();msg('Layers visíveis na lista marcados para ignorar. Clique Analisar arquivos para aplicar.')});
function updateDxfLayers(){const el=$('selectionLayer');if(!el)return;const prev=el.value;el.innerHTML='<option value="">Todos os layers</option>'+(analysis?.layers||layerCatalog?.layers||[]).map(l=>`<option value="${esc(l.name)}">${esc(l.name)}</option>`).join('');if([...el.options].some(o=>o.value===prev))el.value=prev}
TOOLS.splice(1,0,['dxfselect','Selecionar entidade DXF','Clique numa entidade para ver o layer e excluir do projeto com Delete. Use o filtro de layer. O DXF original permanece intacto.']);
ICON_PATHS.dxfselect='M4 3l5 17 3-6 7-2z';
$('deleteSelection')?.addEventListener('click',()=>{if(!deleteSel())msg('Selecione uma placa, objeto ou entidade DXF para excluir.',true)});
$('restoreDxf')?.addEventListener('click',()=>{if(!M.excluded_entities.length&&!M.excluded_signs.length)return;checkpoint();M.excluded_entities=[];M.excluded_signs=[];nativeSel=null;showProps();buildVectorPaths();changed('Entidades DXF restauradas. Atualize os fluxos ou a prévia.')});
canvas.addEventListener('pointerdown',e=>{
 if(tool!=='dxfselect'||e.button!==0||spaceDown||!ready())return;
 e.stopImmediatePropagation();canvas.focus({preventScroll:true});const c=canvasPt(e),layer=$('selectionLayer').value;let best=null;
 for(const [role,list] of Object.entries(vec?.layers||{})){
  if(vecOn[role]===false)continue;
  for(const r of list){if(!r.entity_id||layer&&r.layer!==layer||M.excluded_entities.includes(r.entity_id))continue;
   const P=r.p.map(p=>W2C({x:p[0],y:p[1]}));let d=Infinity;
   if(P.length===1)d=Math.hypot(c.cx-P[0][0],c.cy-P[0][1]);
   for(let i=1;i<P.length;i++)d=Math.min(d,segDist(c.cx,c.cy,...P[i-1],...P[i]));
   if(r.c&&P.length>2)d=Math.min(d,segDist(c.cx,c.cy,...P.at(-1),...P[0]));
   if(d<=10&&(!best||d<best.d))best={...r,d};
  }
 }
 for(const g of editor?.signs||[]){if(g.source==='manual'||!g.sign_id||M.excluded_signs.includes(g.sign_id)||layer)continue;const [x,y]=W2C({x:g.x,y:g.y});const d=Math.min(Math.hypot(c.cx-x,c.cy-y),Math.hypot(c.cx-x,c.cy-(y-24)));if(d<14&&(!best||d<best.d))best={sign_id:g.sign_id,entity_id:g.sign_id,layer:g.source||'automática',p:[[g.x,g.y]],d}}
 nativeSel=best;sel=null;multiSel=[];showProps();draw();msg(best?`Layer ${best.layer} · entidade ${best.entity_id}. Delete exclui; Ctrl+Z desfaz.`:'Nenhuma entidade encontrada neste layer. Clique próximo ao traço.');
},true);
buildToolbar();
// Show every selected object, not just the primary object's grips.
{const drawOne=drawSelection;drawSelection=function(){const primary=sel;if(multiSel.length>1){try{for(const s of multiSel){sel=s;drawOne()}}finally{sel=primary}}else drawOne()}}
{const listLayers=showLayers;showLayers=function(){listLayers();filterLayers();updateDxfLayers()}}
canvas.addEventListener('pointercancel',()=>{if(drag)cancelCommand()});
$('markClipStart').onclick=()=>{$('export_start_s').value=Number($('preview_time_s').value).toFixed(3);scheduleSave()};
$('markClipEnd').onclick=()=>{$('export_end_s').value=Number($('preview_time_s').value).toFixed(3);scheduleSave()};
$('clearClip').onclick=()=>{$('export_start_s').value=0;$('export_end_s').value='';scheduleSave()};
$('fps').addEventListener('change',()=>{$('preview_time_s').step=1/(Number($('fps').value)||30)});

$('qmsResults').onchange=()=>{$('qmsId').value=$('qmsResults').value};
$('qmsSearch').onclick=guard(async()=>{const q=$('qmsQuery').value.trim();if(!q)throw Error('Digite o nome da base de imagem.');$('qmsInfo').textContent='Consultando QuickMapServices…';try{const r=await api('/api/qms/search?q='+encodeURIComponent(q));$('qmsResults').innerHTML='<option value="">— selecione o serviço —</option>'+r.services.map(s=>`<option value="${s.id}">${esc(s.name)} · QMS ${s.id}</option>`).join('');$('qmsInfo').textContent=r.services.length+' serviços compatíveis encontrados. Escolha um e clique Aplicar fonte.'}catch(e){$('qmsInfo').textContent=e.message;throw e}});
