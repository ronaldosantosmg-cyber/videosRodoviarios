import json,sys,traceback,shutil
import numpy as np
from pathlib import Path
from . import store
from .models import Settings
from .geometry import analyze
from .render import Scene,render,ASSETS
from PIL import Image

def run(jid):
    j=store.job(jid);d=store.directory(j['project']);s=Settings.model_validate(json.loads((d/'config.json').read_text(encoding='utf-8')))
    def status(p,msg):store.update(jid,progress=float(p),message=msg)
    def cancel():return store.job(jid)['state']=='cancel_requested'
    end_message='Concluído'
    try:
        if j['kind']=='analyze':
            unmapped=[];items,axis,_,_,r=analyze(d,s,preview=unmapped);store.write_json(d/'analysis.json',r)
            try:
                from .geometry import write_layer_preview
                write_layer_preview(d,items,unmapped)
            except Exception as exc:r['warnings'].append('Prévia das camadas não gerada: '+str(exc)[:120])
            from .webmap import write_vectors
            try:write_vectors(d,items,axis,s.crs)
            except Exception as exc:r['warnings'].append('Vetores do editor não gerados: '+str(exc)[:160])
            # 1.11: fluxos, sentidos e sinalização para o editor, sem precisar da prévia.
            try:
                status(.4,'Calculando fluxos e sinalização para o editor')
                lt=Scene.light(d,s,lambda p,m:status(.4+.55*p,m));store.write_json(d/'editor.json',lt.editor_data())
            except Exception as exc:r['warnings'].append('Fluxos do editor não calculados: '+str(exc)[:160])
            store.write_json(d/'analysis.json',r)
            status(1,'Análise concluída')
        elif j['kind']=='preview':
            sc=Scene(d,s,status)
            view=None
            if s.preview_mode=='custom' and s.preview_center is not None:view=((s.preview_center.x,s.preview_center.y),s.preview_width_m or s.view_width_m)
            if s.cabin.enabled and s.preview_mode=='video':
                from .cabin import CabinView
                cab=CabinView(sc);cim,cm=cab.frame(min(s.cabin.duration_s-1/s.fps,s.preview_time_s))
                tmp=d/'preview_cabin.tmp.png';Image.fromarray(cim).save(tmp);store.replace(tmp,d/'preview_cabin.png')
                # O editor continua na vista geral (coordenadas em planta) para posicionar marcações.
                im,meta=sc.frame(0,overview=True);meta={**meta,'cabin':cm}
            else:
                if s.preview_mode!='overview' and getattr(sc,'detail',None) is not None:
                    cw=(np.asarray(view[0],float),float(view[1])) if view else sc.pose(min(s.duration_s-1/s.fps,s.preview_time_s))[:2]
                    try:sc.detail.prefetch([cw],status)
                    except Exception:pass
                im,meta=sc.frame(min(s.duration_s-1/s.fps,s.preview_time_s),overview=s.preview_mode=='overview',view=view)
            tmp=d/'preview.tmp.png';Image.fromarray(im).save(tmp);store.replace(tmp,d/'preview.png')
            store.write_json(d/'preview.json',meta);store.write_json(d/'analysis.json',sc.report);store.write_json(d/'editor.json',sc.editor_data())
            from .webmap import write_vectors
            try:write_vectors(d,sc.items,sc.axis,s.crs)
            except Exception:pass
            status(1,'Prévia pronta')
        elif j['kind']=='reference':
            source=ASSETS/'th57/referencia.mp4';tmp=d/'video.partial.mp4'
            if not source.exists():raise FileNotFoundError('O vídeo de referência foi substituído pela ficha técnica; não há cópia para exportar.')
            with source.open('rb') as fi,tmp.open('wb') as fo:
                done=0
                while b:=fi.read(4*1024*1024):
                    if cancel():raise InterruptedError('Exportação cancelada.')
                    fo.write(b);done+=len(b);status(done/source.stat().st_size,'Exportando o arquivo aprovado sem alterações')
            store.replace(tmp,d/'video.mp4');store.write_json(d/'video.json',{'mode':'reference','note':'Cópia binária do vídeo aprovado; não é uma nova renderização.'})
        elif j['kind'] in ('reference_profile','reference_profile_remove'):
            from .video_profile import profile
            source=ASSETS/'th57/referencia.mp4';target=ASSETS/'th57/referencia_ficha.json'
            if not source.exists():raise FileNotFoundError('O vídeo de referência já não está na pasta do aplicativo; a ficha técnica existente continua valendo.')
            status(.05,'Medindo o vídeo de referência (dados do arquivo, SHA-256 e quadros amostrados)')
            old=json.loads(target.read_text(encoding='utf-8')) if target.exists() else {}
            prof=profile(source,label='Vídeo TH57 aprovado (referência histórica)')
            prof['status']='completa';prof['note']='Ficha medida a partir do arquivo referencia.mp4. Comparação relativa: mesmo método aplicado aos vídeos gerados.'
            known=old.get('file',{}).get('sha256')
            prof['sha256_matches_1_0']=(known==prof['file'].get('sha256')) if known else None
            store.write_json(target,prof);status(.95,'Ficha técnica gravada')
            if j['kind']=='reference_profile_remove':
                if json.loads(target.read_text(encoding='utf-8')).get('status')!='completa':raise RuntimeError('Ficha não confirmada; o vídeo não foi removido.')
                source.unlink();end_message='Ficha técnica gravada e vídeo de referência removido (456 MB liberados)'
            else:end_message='Ficha técnica da referência gravada'
        elif j['kind']=='compare':
            from .video_profile import profile,compare
            video=d/'video.mp4'
            if not video.exists():raise FileNotFoundError('Gere um vídeo antes de comparar.')
            status(.1,'Medindo o vídeo gerado');cur=profile(video,label='Vídeo gerado',sha=False)
            ref=json.loads((ASSETS/'th57/referencia_ficha.json').read_text(encoding='utf-8'))
            store.write_json(d/'video_ficha.json',cur);store.write_json(d/'comparacao.json',{'reference':ref.get('label'),'reference_status':ref.get('status'),'rows':compare(ref,cur)})
            end_message='Comparação com a referência pronta'
        elif j['kind']=='export':
            from .exports_job import run_export
            run_export(d,s,status);end_message='Exportação concluída'
        elif j['kind']=='convert_imagery':
            # 1.17: ECW/MrSID/... -> GeoTIFF em blocos com o GDAL do computador (QGIS/OSGeo4W).
            from .local_tiles import find_gdal,convert
            from .local_imagery import georef
            from .models import LocalImagery,LocalSource
            req=json.loads((d/'imagem_local'/'_converter.json').read_text(encoding='utf-8'))
            g=find_gdal()
            if not g:raise ValueError('GDAL não encontrado neste computador. Instale o QGIS (com suporte a ECW) ou converta o arquivo para GeoTIFF/JPEG2000 no QGIS e envie o resultado.')
            src=d/'imagem_local'/req['file'];dst=src.with_name(src.stem+'_convertido.tif')
            convert(g,src,dst,status)
            info=georef(dst,None,None,req.get('crs') or None)
            s=Settings.model_validate(json.loads((d/'config.json').read_text(encoding='utf-8')))
            if req.get('mode')=='add' and s.local_imagery.image:
                s.local_imagery.others.append(LocalSource(name=req['file'],image=dst.name,crs=req.get('crs') or None))
            else:
                s.local_imagery=LocalImagery(name=req['file'],image=dst.name,crs=req.get('crs') or None,others=s.local_imagery.others)
                s.imagery='local'
            store.write_json(d/'config.json',s.model_dump());end_message=f'Convertido: {dst.name} ({info["size"][0]}×{info["size"][1]} px)'
        elif j['kind']=='frames':
            from .exports_job import run_frames
            out=run_frames(d,s,status,cancel);end_message='Sequência PNG pronta em '+str(out)
        else:
            render(d,s,status,cancel)
            info=json.loads((d/'video.json').read_text(encoding='utf-8'));end_message='Concluído · '+info.get('encoder','H.264')
        store.update(jid,state='done',progress=1,message=end_message)
    except BaseException as e:
        (d/'video.partial.mp4').unlink(missing_ok=True)
        (d/'error.log').write_text(traceback.format_exc(),encoding='utf-8')
        store.update(jid,state='cancelled' if isinstance(e,InterruptedError) else 'failed',message=str(e)[:400],error=type(e).__name__)
        if not isinstance(e,InterruptedError):return 1
    return 0
if __name__=='__main__':raise SystemExit(run(sys.argv[1]))
