﻿// Rodovia Studio — iniciador para Windows (.exe).
//
// O executável é pequeno e quase nunca muda: ele só prepara, atualiza, inicia e encerra o aplicativo.
// Os comandos e todo o programa continuam em arquivos separados (suporte\sistema\app, .py/.js/.html),
// trocados pelos ZIPs de atualização. Assim não é preciso refazer o .exe a cada versão.
//
// Compilado no próprio Windows pelo compilador do .NET Framework 4 (COMPILAR INICIADOR.cmd), sem
// administrador. Escrito em C# 5 (o csc.exe do .NET Framework não aceita recursos mais novos).
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Net;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Windows.Forms;

namespace RodoviaStudioLauncher
{
    static class Program
    {
        public const string Version = "1.0";

        [STAThread]
        static void Main(string[] args)
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            bool created;
            using (Mutex mutex = new Mutex(true, "RodoviaStudio_Iniciador_v1", out created))
            {
                Launcher l = new Launcher();
                if (!l.FindRoot())
                {
                    MessageBox.Show("Não encontrei a pasta suporte\\sistema do Rodovia Studio.\n\nO arquivo \"Rodovia Studio.exe\" deve ficar na pasta principal do aplicativo (a mesma de ABRIR RODOVIA STUDIO.cmd).",
                        "Rodovia Studio", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                if (!created)
                {
                    // Já aberto: só mostra a janela.
                    if (!l.OpenExisting())
                        MessageBox.Show("O Rodovia Studio já está sendo iniciado. Aguarde alguns segundos.", "Rodovia Studio", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
                if (l.Start()) Application.Run(l);
                l.StopServer();
            }
        }
    }

    class Splash : Form
    {
        Label status;
        public Splash(Icon icon)
        {
            Text = "Rodovia Studio";
            FormBorderStyle = FormBorderStyle.FixedDialog;
            StartPosition = FormStartPosition.CenterScreen;
            MaximizeBox = false; MinimizeBox = true;
            ClientSize = new Size(460, 120);
            BackColor = Color.FromArgb(8, 22, 35);
            if (icon != null) Icon = icon;
            Label title = new Label();
            title.Text = "Rodovia Studio";
            title.Font = new Font("Segoe UI", 15, FontStyle.Bold);
            title.ForeColor = Color.FromArgb(134, 220, 233);
            title.SetBounds(20, 14, 420, 34);
            status = new Label();
            status.Font = new Font("Segoe UI", 10);
            status.ForeColor = Color.White;
            status.SetBounds(20, 56, 420, 50);
            Controls.Add(title); Controls.Add(status);
        }
        public void Status(string text)
        {
            status.Text = text;
            Refresh();
            Application.DoEvents();
        }
    }

    class Launcher : ApplicationContext
    {
        public string Root, Sys, Logs, Py;
        Process server;
        int port = 8765;
        NotifyIcon tray;
        Splash splash;
        Icon icon;
        readonly object logLock = new object();
        bool stopping;

        public bool FindRoot()
        {
            string d = AppDomain.CurrentDomain.BaseDirectory;
            for (int i = 0; i < 4 && d != null; i++)
            {
                if (File.Exists(Path.Combine(d, "suporte\\sistema\\run.py")))
                {
                    Root = d.TrimEnd('\\');
                    Sys = Path.Combine(Root, "suporte\\sistema");
                    Logs = Path.Combine(Root, "suporte\\logs");
                    Directory.CreateDirectory(Logs);
                    Py = Path.Combine(Sys, "runtime\\python.exe");
                    return true;
                }
                DirectoryInfo p = Directory.GetParent(d.TrimEnd('\\'));
                d = p == null ? null : p.FullName;
            }
            return false;
        }

        string PortFile { get { return Path.Combine(Logs, "porta.txt"); } }
        string Url { get { return "http://127.0.0.1:" + port; } }

        void Log(string file, string text)
        {
            try
            {
                lock (logLock)
                {
                    File.AppendAllText(Path.Combine(Logs, file), DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss ") + text + Environment.NewLine, Encoding.UTF8);
                }
            }
            catch { }
        }

        // ---------------------------------------------------------------- já aberto
        public bool OpenExisting()
        {
            int p;
            if (File.Exists(PortFile) && int.TryParse(File.ReadAllText(PortFile).Trim(), out p)) port = p;
            if (!Healthy()) return false;
            OpenWindow();
            return true;
        }

        // ---------------------------------------------------------------- início
        public bool Start()
        {
            try { icon = Icon.ExtractAssociatedIcon(Application.ExecutablePath); } catch { icon = SystemIcons.Application; }
            splash = new Splash(icon);
            splash.Show();
            try
            {
                if (!Prepare()) return false;
                ApplyUpdates(false);
                if (!Prepare()) return false;            // uma atualização pode trazer novas dependências
                if (!StartServer()) return false;
                splash.Close(); splash = null;
                CreateTray();
                OpenWindow();
                CheckLauncherVersion();
                MakeShortcut();
                return true;
            }
            catch (Exception ex)
            {
                Log("iniciador.log", "ERRO: " + ex);
                MessageBox.Show("O Rodovia Studio não iniciou:\n\n" + ex.Message + "\n\nDetalhes em suporte\\logs\\iniciador.log.", "Rodovia Studio", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            finally
            {
                if (splash != null) { splash.Close(); splash = null; }
            }
        }

        void Say(string t) { if (splash != null) splash.Status(t); Log("iniciador.log", t); }

        static string Sha256Upper(string file)
        {
            using (SHA256 h = SHA256.Create())
            using (FileStream f = File.OpenRead(file))
            {
                byte[] b = h.ComputeHash(f);
                StringBuilder sb = new StringBuilder();
                foreach (byte x in b) sb.Append(x.ToString("X2"));
                return sb.ToString();
            }
        }

        bool NeedsPreparation()
        {
            if (!File.Exists(Py)) return true;
            string stamp = Path.Combine(Sys, "runtime\\dependencias.ok");
            string req = Path.Combine(Sys, "requirements.txt");
            if (!File.Exists(stamp) || !File.Exists(req)) return true;
            return File.ReadAllText(stamp).Trim().ToUpperInvariant() != Sha256Upper(req);
        }

        // Primeira vez (ou dependências novas): usa o mesmo preparo do ABRIR RODOVIA STUDIO.cmd, numa janela visível.
        bool Prepare()
        {
            if (!NeedsPreparation()) return true;
            Say("Preparando Python, bibliotecas e FFmpeg (primeira vez ou dependências novas).\nAcompanhe na janela que vai abrir.");
            ProcessStartInfo si = new ProcessStartInfo("powershell.exe",
                "-NoProfile -ExecutionPolicy Bypass -File \"" + Path.Combine(Sys, "iniciar.ps1") + "\" -PrepararApenas");
            si.WorkingDirectory = Sys;
            si.UseShellExecute = false;
            Process p = Process.Start(si);
            while (!p.WaitForExit(200)) Application.DoEvents();
            if (p.ExitCode != 0 || NeedsPreparation())
            {
                MessageBox.Show("A preparação não terminou. Confira a mensagem na janela do PowerShell e suporte\\logs\\instalacao.log.\n\nSe a empresa bloqueia downloads ou PowerShell, peça a liberação ao suporte de TI.",
                    "Rodovia Studio", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            return true;
        }

        // ---------------------------------------------------------------- atualizações
        bool HasUpdateZip()
        {
            Regex re = new Regex("RodoviaStudio_.*atualiza.*\\.zip$", RegexOptions.IgnoreCase);
            List<string> places = new List<string>();
            places.Add(Path.Combine(Root, "atualizacoes"));
            places.Add(Root);
            places.Add(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads"));
            foreach (string d in places)
            {
                if (!Directory.Exists(d)) continue;
                foreach (string f in Directory.GetFiles(d, "*.zip"))
                    if (re.IsMatch(Path.GetFileName(f))) return true;
            }
            return false;
        }

        // Usa o atualizador do próprio programa (atualizar.ps1 + atualizador.py). Retorna true se aplicou.
        bool ApplyUpdates(bool interactive)
        {
            if (!HasUpdateZip() || !File.Exists(Py)) { if (interactive) Info("Nenhum ZIP de atualização encontrado em \"atualizacoes\" ou em Downloads."); return false; }
            Say("Procurando e aplicando atualização…");
            ProcessStartInfo si = new ProcessStartInfo("powershell.exe",
                "-NoProfile -ExecutionPolicy Bypass -File \"" + Path.Combine(Sys, "atualizar.ps1") + "\" -Raiz \"" + Root + "\"");
            si.WorkingDirectory = Root;
            si.UseShellExecute = false;
            si.CreateNoWindow = true;
            si.RedirectStandardOutput = true;
            si.RedirectStandardError = true;
            si.StandardOutputEncoding = Encoding.UTF8;
            Process p = Process.Start(si);
            StringBuilder outText = new StringBuilder();
            p.OutputDataReceived += delegate(object s, DataReceivedEventArgs e) { if (e.Data != null) lock (outText) outText.AppendLine(e.Data); };
            p.ErrorDataReceived += delegate(object s, DataReceivedEventArgs e) { if (e.Data != null) lock (outText) outText.AppendLine(e.Data); };
            p.BeginOutputReadLine(); p.BeginErrorReadLine();
            while (!p.WaitForExit(200)) Application.DoEvents();
            p.WaitForExit();
            string text;
            lock (outText) text = outText.ToString().Trim();
            Log("iniciador.log", "Atualizador: " + text);
            bool applied = text.IndexOf("aplicada", StringComparison.OrdinalIgnoreCase) >= 0 && p.ExitCode == 0;
            if (p.ExitCode != 0)
                MessageBox.Show("A atualização não foi aplicada:\n\n" + Tail(text, 900) + "\n\nO Rodovia Studio continua na versão instalada.", "Rodovia Studio", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            else if (applied) Notify("Atualização aplicada", Tail(text, 250));
            else if (interactive) Info(Tail(text, 500));
            return applied;
        }

        static string Tail(string t, int n) { return t.Length <= n ? t : "…" + t.Substring(t.Length - n); }

        // ---------------------------------------------------------------- servidor
        public bool StartServer()
        {
            Say("Iniciando o Rodovia Studio…");
            try { File.Delete(PortFile); } catch { }
            ProcessStartInfo si = new ProcessStartInfo(Py, "-X utf8 \"" + Path.Combine(Sys, "run.py") + "\"");
            si.WorkingDirectory = Sys;
            si.UseShellExecute = false;
            si.CreateNoWindow = true;
            si.RedirectStandardOutput = true;
            si.RedirectStandardError = true;
            si.StandardOutputEncoding = Encoding.UTF8;
            si.StandardErrorEncoding = Encoding.UTF8;
            si.EnvironmentVariables["RODOVIA_NO_BROWSER"] = "1";
            si.EnvironmentVariables["RODOVIA_PORT_FILE"] = PortFile;
            si.EnvironmentVariables["PYTHONIOENCODING"] = "utf-8";
            server = Process.Start(si);
            server.OutputDataReceived += delegate(object s, DataReceivedEventArgs e) { if (e.Data != null) Log("servidor.log", e.Data); };
            server.ErrorDataReceived += delegate(object s, DataReceivedEventArgs e) { if (e.Data != null) Log("servidor.log", e.Data); };
            server.BeginOutputReadLine(); server.BeginErrorReadLine();
            DateTime limit = DateTime.Now.AddSeconds(120);
            while (DateTime.Now < limit)
            {
                Application.DoEvents();
                int p;
                if (File.Exists(PortFile))
                {
                    try { if (int.TryParse(File.ReadAllText(PortFile).Trim(), out p)) port = p; } catch { }
                    if (Healthy()) return true;
                }
                if (server.HasExited)
                {
                    // run.py encerra com 0 quando outro Rodovia Studio já está aberto: usa aquele.
                    if (server.ExitCode == 0 && File.Exists(PortFile) && Healthy()) { server = null; return true; }
                    MessageBox.Show("O servidor do Rodovia Studio encerrou ao iniciar.\n\nVeja suporte\\logs\\servidor.log e suporte\\sistema\\servidor_erro.log.",
                        "Rodovia Studio", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }
                Thread.Sleep(150);
            }
            MessageBox.Show("O Rodovia Studio demorou demais para iniciar (2 min). Veja suporte\\logs\\servidor.log.", "Rodovia Studio", MessageBoxButtons.OK, MessageBoxIcon.Error);
            StopServer();
            return false;
        }

        bool Healthy()
        {
            try
            {
                HttpWebRequest r = (HttpWebRequest)WebRequest.Create(Url + "/api/health");
                r.Timeout = 1500; r.Proxy = null;
                using (HttpWebResponse resp = (HttpWebResponse)r.GetResponse())
                using (StreamReader sr = new StreamReader(resp.GetResponseStream()))
                    return sr.ReadToEnd().Contains("ok");
            }
            catch { return false; }
        }

        public void StopServer()
        {
            stopping = true;
            if (server == null) return;
            try
            {
                if (!server.HasExited)
                {
                    // Encerra também os processos auxiliares (geração de vídeo, prévia).
                    ProcessStartInfo k = new ProcessStartInfo("taskkill", "/PID " + server.Id + " /T /F");
                    k.CreateNoWindow = true; k.UseShellExecute = false;
                    Process kp = Process.Start(k); kp.WaitForExit(10000);
                }
            }
            catch { }
            server = null;
            try { File.Delete(PortFile); } catch { }
        }

        // ---------------------------------------------------------------- janela
        public void OpenWindow()
        {
            string[] browsers = new string[] {
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), "Microsoft\\Edge\\Application\\msedge.exe"),
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "Microsoft\\Edge\\Application\\msedge.exe"),
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "Google\\Chrome\\Application\\chrome.exe"),
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), "Google\\Chrome\\Application\\chrome.exe"),
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Google\\Chrome\\Application\\chrome.exe") };
            foreach (string b in browsers)
            {
                if (!File.Exists(b)) continue;
                try { Process.Start(b, "--app=" + Url + " --new-window"); return; } catch { }
            }
            try { Process.Start(Url); } catch (Exception ex) { Info("Abra no navegador: " + Url + "\n\n" + ex.Message); }
        }

        // ---------------------------------------------------------------- bandeja
        void CreateTray()
        {
            tray = new NotifyIcon();
            tray.Icon = icon;
            tray.Text = "Rodovia Studio";
            ContextMenuStrip m = new ContextMenuStrip();
            m.Items.Add("Abrir Rodovia Studio", null, delegate { OpenWindow(); });
            m.Items.Add("Abrir pasta de projetos", null, delegate { OpenFolder(Path.Combine(Root, "projetos")); });
            m.Items.Add("Procurar e aplicar atualização", null, delegate { UpdateNow(); });
            m.Items.Add("Reiniciar o aplicativo", null, delegate { Restart(); });
            m.Items.Add("Ver registro (logs)", null, delegate { OpenFolder(Logs); });
            m.Items.Add(new ToolStripSeparator());
            m.Items.Add("Encerrar o Rodovia Studio", null, delegate { Quit(); });
            tray.ContextMenuStrip = m;
            tray.DoubleClick += delegate { OpenWindow(); };
            tray.Visible = true;
            Notify("Rodovia Studio aberto", "O aplicativo fica no ícone perto do relógio. Clique com o botão direito para atualizar ou encerrar.");
            System.Windows.Forms.Timer t = new System.Windows.Forms.Timer();
            t.Interval = 5000;
            t.Tick += delegate
            {
                if (stopping || server == null) return;
                if (server.HasExited)
                {
                    t.Stop();
                    Log("iniciador.log", "Servidor encerrou com código " + server.ExitCode);
                    if (MessageBox.Show("O servidor do Rodovia Studio encerrou. Reiniciar?", "Rodovia Studio", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                    { if (StartServer()) { OpenWindow(); t.Start(); } }
                    else Quit();
                }
            };
            t.Start();
        }

        void OpenFolder(string d) { try { Directory.CreateDirectory(d); Process.Start("explorer.exe", "\"" + d + "\""); } catch { } }

        void Notify(string title, string text)
        {
            if (tray == null) return;
            try { tray.ShowBalloonTip(6000, title, text.Length > 250 ? text.Substring(0, 250) : text, ToolTipIcon.Info); } catch { }
        }

        static void Info(string text) { MessageBox.Show(text, "Rodovia Studio", MessageBoxButtons.OK, MessageBoxIcon.Information); }

        void UpdateNow()
        {
            if (!HasUpdateZip()) { Info("Nenhum ZIP de atualização encontrado.\n\nSalve o arquivo RodoviaStudio_<versão>_atualizacao.zip na pasta \"atualizacoes\" (ou em Downloads)."); return; }
            if (MessageBox.Show("Para atualizar, o Rodovia Studio será fechado e aberto de novo.\nSe houver vídeo sendo gerado, espere terminar.\n\nContinuar?", "Rodovia Studio", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
            StopServer();
            stopping = false;
            ApplyUpdates(true);
            if (!Prepare()) { Quit(); return; }
            if (StartServer()) { OpenWindow(); CheckLauncherVersion(); } else Quit();
        }

        void Restart()
        {
            StopServer(); stopping = false;
            if (StartServer()) OpenWindow(); else Quit();
        }

        void Quit()
        {
            StopServer();
            if (tray != null) { tray.Visible = false; tray.Dispose(); tray = null; }
            ExitThread();
        }

        // Se uma atualização trouxe um iniciador mais novo, avisa para recompilar (o .exe em uso não se troca sozinho).
        void CheckLauncherVersion()
        {
            try
            {
                string src = Path.Combine(Sys, "iniciador\\RodoviaStudio.cs");
                if (!File.Exists(src)) return;
                Match m = Regex.Match(File.ReadAllText(src), "Version\\s*=\\s*\"([^\"]+)\"");
                if (m.Success && m.Groups[1].Value != Program.Version)
                    Notify("Nova versão do iniciador", "Feche o Rodovia Studio e execute \"COMPILAR INICIADOR.cmd\" para atualizar o .exe (" + Program.Version + " → " + m.Groups[1].Value + ").");
            }
            catch { }
        }

        // Atalho "Rodovia Studio" na Área de Trabalho apontando para o .exe (uma vez).
        void MakeShortcut()
        {
            string flag = Path.Combine(Logs, "atalho_exe.ok");
            if (File.Exists(flag)) return;
            try
            {
                Type t = Type.GetTypeFromProgID("WScript.Shell");
                object sh = Activator.CreateInstance(t);
                string lnkPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory), "Rodovia Studio.lnk");
                object lnk = t.InvokeMember("CreateShortcut", BindingFlags.InvokeMethod, null, sh, new object[] { lnkPath });
                Type lt = lnk.GetType();
                lt.InvokeMember("TargetPath", BindingFlags.SetProperty, null, lnk, new object[] { Application.ExecutablePath });
                lt.InvokeMember("WorkingDirectory", BindingFlags.SetProperty, null, lnk, new object[] { Root });
                lt.InvokeMember("IconLocation", BindingFlags.SetProperty, null, lnk, new object[] { Application.ExecutablePath + ",0" });
                lt.InvokeMember("Description", BindingFlags.SetProperty, null, lnk, new object[] { "Rodovia Studio" });
                lt.InvokeMember("Save", BindingFlags.InvokeMethod, null, lnk, null);
                File.WriteAllText(flag, "ok");
            }
            catch (Exception ex) { Log("iniciador.log", "Atalho não criado: " + ex.Message); }
        }
    }
}
