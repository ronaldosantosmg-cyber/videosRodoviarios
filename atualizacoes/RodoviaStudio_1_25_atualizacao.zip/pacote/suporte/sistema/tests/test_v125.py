"""QMS adapter, shared image source, project persistence and browser chooser.
Catalog and provider responses are simulated: no claim of live Google/QMS access.
"""
import os,json,socket,threading,time,urllib.parse
from pathlib import Path
import cv2,numpy as np,pytest,httpx
from fastapi.testclient import TestClient
from test_workflow import drawing,settings,wait
from app.models import Settings,WebImagery
from app import qms

SERVICE={'id':12345,'name':'Google Satellite (fixture)','type':'tms','epsg':3857,'url':'https://imagery.example.test/{z}/{x}/{y}.png','z_min':2,'z_max':18,'y_origin_top':True,'copyright_text':'Crédito do provedor de teste'}

def fetch_catalog(url):
    if '?' in url:return {'results':[SERVICE]}
    return dict(SERVICE)


def image():
    a=np.zeros((256,256,3),np.uint8);a[:,:,1]=np.arange(256,dtype=np.uint8)[:,None];a[:,:,0]=80;a[:,:,2]=140
    return cv2.imencode('.png',a)[1].tobytes()


def test_qms_search_and_definition_match_upstream_contract():
    urls=[]
    def fetch(url):urls.append(url);return fetch_catalog(url)
    rows=qms.search('Google Satellite',fetch);assert rows[0]['id']==12345
    params=urllib.parse.parse_qs(urllib.parse.urlsplit(urls[0]).query);assert params['type']==['tms'] and params['epsg']==['3857']
    w=qms.service(12345,fetch);assert w.source=='qms' and w.qms_name==SERVICE['name']
    assert urls[-1].endswith('/geoservices/12345/')
    with pytest.raises(ValueError):qms.service(-1,fetch)
    with pytest.raises(ValueError):qms.service(12346,fetch)


def test_qms_origin_url_tms_and_quadkey():
    from app.webmap import web_source
    w=qms.definition({**SERVICE,'origin_url':'https://imagery.example.test/{z}/{x}/{y}.png','y_origin_top':0})
    s=Settings(web_imagery=w);src=web_source(s)
    assert src.tile_url(3,2,1).endswith('/3/1/5.png')
    w=qms.definition({**SERVICE,'url':'https://imagery.example.test/{q}.png'})
    assert web_source(Settings(web_imagery=w)).tile_url(3,2,1).endswith('/021.png')


@pytest.mark.parametrize('changes',[{'type':'wfs'},{'epsg':4326},{'url':'file:///tmp/x'},{'url':'https://host/{token}/{z}/{x}/{y}'},{'url':'https://host/map'},{'z_min':20,'z_max':15}])
def test_incompatible_catalog_services_rejected(changes):
    with pytest.raises(ValueError):qms.definition({**SERVICE,**changes})


def test_separate_provider_cache_and_no_catalog_needed_after_save(tmp_path):
    from app.webmap import web_source,tile
    a=web_source(Settings(web_imagery=qms.definition(SERVICE)))
    b=web_source(Settings(web_imagery=qms.definition({**SERVICE,'id':12346,'url':'https://other.example.test/{z}/{x}/{y}'})))
    assert a.key!=b.key and a.key!='esri'
    raw=image();assert tile(tmp_path,5,3,4,fetch=lambda *args:raw,source=a)==raw
    assert tile(tmp_path,5,3,4,fetch=lambda *args:pytest.fail('cached tile must work offline'),source=a)==raw
    with pytest.raises(ValueError):tile(tmp_path,19,1,1,source=a)
    s=Settings(web_imagery=qms.definition(SERVICE));restored=Settings.model_validate_json(s.model_dump_json())
    assert web_source(restored).tile_url(5,3,4)==a.tile_url(5,3,4)


def test_catalog_api_error_does_not_modify_project(monkeypatch):
    from app.server import app
    monkeypatch.setattr(qms,'request_json',fetch_catalog)
    with TestClient(app) as c:
        assert c.get('/api/qms/search',params={'q':'Google'}).json()['services'][0]['id']==12345
        w=c.get('/api/qms/services/12345').json();assert w['url']==SERVICE['url']
        pid=c.post('/api/projects',json=settings().model_dump()).json()['id']
        cfg=c.get(f'/api/projects/{pid}').json()['config'];cfg['web_imagery']=w;c.put(f'/api/projects/{pid}/config',json=cfg).raise_for_status()
        def fail(url):raise OSError('offline')
        monkeypatch.setattr(qms,'request_json',fail)
        assert c.get('/api/qms/search',params={'q':'Google'}).status_code==503
        assert c.get(f'/api/projects/{pid}').json()['config']['web_imagery']==w


def test_editor_mosaic_detail_and_mp4_share_provider(drawing,tmp_path,monkeypatch):
    from app.server import app
    from app import webmap
    from app.render import Scene,render
    from app.imagery import mosaic
    seen=[];raw=image()
    def provider(root,z,y,x,**kwargs):
        src=kwargs['source'];seen.append((src.key,src.tile_url(z,y,x)));return raw
    monkeypatch.setattr(webmap,'tile',provider)
    s=Settings(**{**settings().model_dump(),'imagery':'esri','imagery_pixels':2048,'web_imagery':qms.definition(SERVICE).model_dump(),'encoder':'cpu','render_workers':1,'export_end_s':1})
    key=webmap.web_source(s).key
    with TestClient(app) as c:
        pid=c.post('/api/projects',json=s.model_dump()).json()['id']
        assert c.get(f'/api/projects/{pid}/web_tiles/5/3/4').content==raw
    assert seen[-1][0]==key
    sc=Scene(drawing,s);assert sc.detail.web.key==key and sc.detail.web.kind=='qms'
    # The full render, including close-up texture requests, uses the same provider function.
    p=render(drawing,s);assert p.stat().st_size>1000
    meta=json.loads((drawing/'video.json').read_text());assert meta['validation']['ok'] and meta['frames']==30
    assert seen and {k for k,u in seen}=={key}
    assert all(urllib.parse.urlsplit(u).hostname=='imagery.example.test' for k,u in seen)


def test_qms_chooser_in_browser(drawing,monkeypatch):
    pw=pytest.importorskip('playwright.sync_api')
    import uvicorn
    from app.server import app
    from app import webmap
    monkeypatch.setattr(qms,'request_json',fetch_catalog)
    monkeypatch.setattr(webmap,'tile',lambda *a,**kw:image())
    with socket.socket() as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
    server=uvicorn.Server(uvicorn.Config(app,host='127.0.0.1',port=port,log_level='warning'));th=threading.Thread(target=server.run,daemon=True);th.start();base=f'http://127.0.0.1:{port}'
    try:
        with httpx.Client(base_url=base,timeout=60) as c:
            for _ in range(100):
                try:c.get('/api/health').raise_for_status();break
                except httpx.HTTPError:time.sleep(.1)
            pid=c.post('/api/projects',json=settings().model_dump()).json()['id']
            c.post(f'/api/projects/{pid}/files',files={'file':('input.dxf',(drawing/'input.dxf').read_bytes())}).raise_for_status()
            job=c.post(f'/api/projects/{pid}/analyze').json();assert wait(c,job['id'])['state']=='done'
            with pw.sync_playwright() as p:
                b=p.chromium.launch(executable_path=os.environ.get('CHROMIUM','/usr/bin/chromium'));page=b.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
                page.add_init_script(f"localStorage.setItem('rodovia_project','{pid}')");page.route('**/tiles/esri/**',lambda r:r.fulfill(status=200,body=image(),content_type='image/png'))
                page.goto(base);page.wait_for_function('typeof cfg!=="undefined" && cfg.name && pid')
                page.locator('#webBox').evaluate('(el)=>el.open=true');page.locator('#webSource').select_option('qms')
                page.locator('#qmsQuery').fill('Google Satellite');page.locator('#qmsSearch').click();page.wait_for_function("document.getElementById('qmsResults').options.length===2")
                page.locator('#qmsResults').select_option('12345');page.locator('#webApply').click()
                page.wait_for_function("cfg.web_imagery?.source==='qms' && document.getElementById('webInfo').textContent.includes('Google Satellite')")
                page.wait_for_function('savePending===false')
                conf=c.get(f'/api/projects/{pid}').json()['config'];assert conf['web_imagery']['qms_id']==12345 and conf['imagery']=='esri'
                page.reload();page.wait_for_function("cfg.web_imagery?.qms_id===12345")
                assert page.locator('#webSource').input_value()=='qms'
                assert not errors,errors;b.close()
    finally:server.should_exit=True;th.join(timeout=10)
