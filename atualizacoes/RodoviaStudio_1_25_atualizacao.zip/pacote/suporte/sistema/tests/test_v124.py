"""Regression coverage for continuous motion, CAD commands and DXF selection."""
import os,socket,threading,time
from pathlib import Path
import cv2,ezdxf,httpx,numpy as np,pytest
from fastapi.testclient import TestClient
from shapely.geometry import box
from test_workflow import drawing,settings,wait
from test_v110 import junction
from app.models import Settings


def test_motion_between_samples_is_continuous():
    from app.traffic import path_pose,TrafficNetwork
    from app.simulation import TrafficSim
    p=np.array([[0.,0.],[10.,0.],[20.,0.]])
    path={'p':p,'d':np.array([0.,10.,20.]),'t':np.tile([1.,0.],(3,1)),'length':20.,'kinds':['main']}
    positions=np.array([path_pose(path,s)[0] for s in np.arange(0,20,.1)])
    assert np.allclose(np.diff(positions[:,0]),.1)  # no quantized 10 m jumps/pauses
    assert np.allclose(positions[:,1],0)
    net=TrafficNetwork.__new__(TrafficNetwork);net.paths=[path]
    a=next(net.vehicles_ex(0,5));b=next(net.vehicles_ex(1/30,5))
    assert np.linalg.norm(b[0]-a[0])==pytest.approx(5/30)
    sim=TrafficSim.__new__(TrafficSim);sim.paths=[path];sim.info={7:(0,'car',(0,7,0))}
    sim.frames=[(np.array([7]),np.array([1.]),np.array([0])),(np.array([7]),np.array([3.]),np.array([0]))];sim.t_first=0
    assert next(sim.vehicles_ex(.1))[0][0]==pytest.approx(2.)


def test_camera_boundaries_have_no_cuts_or_velocity_jumps(drawing):
    from app.render import Scene
    s=Settings(**{**settings().model_dump(),'duration_s':120,'short_video_mode':'tour','pois':[{'title':'A','x':500050,'y':7800000},{'title':'B','x':500250,'y':7800000}]})
    sc=Scene(drawing,s)
    # intro=8, outro=10, details=48, tour=54: boundaries at 8, 62, 86, 110.
    for boundary in [8,62,86,110]:
        a=sc.pose(boundary-1e-4);b=sc.pose(boundary);c=sc.pose(boundary+1e-4)
        assert np.linalg.norm(a[0]-c[0])<.001
        assert abs(a[1]-c[1])<.001
        assert np.linalg.norm((b[0]-a[0])/1e-4-(c[0]-b[0])/1e-4)<.05
    assert np.allclose(sc.pose(120)[0],sc.center)


def test_dxf_ids_blocks_arrays_and_non_destructive_exclusion(drawing):
    from app.geometry import analyze,walk
    f=drawing/'input.dxf';doc=ezdxf.readfile(f);block=doc.blocks.new('CUT-BLOCK');block.add_line((0,0),(20,0))
    insert=doc.modelspace().add_blockref('CUT-BLOCK',(500020,7800020),dxfattribs={'layer':'OFFSET-CORTE','column_count':2,'column_spacing':30})
    doc.saveas(f);original=f.read_bytes()
    first=[getattr(e,'_studio_id') for e in walk(ezdxf.readfile(f).modelspace())]
    assert first==[getattr(e,'_studio_id') for e in walk(ezdxf.readfile(f).modelspace())]
    ids=[x for x in first if x.startswith(insert.dxf.handle+'/')];assert len(set(ids))==2
    cfg=settings();es,*_=analyze(drawing,cfg);assert all('entity_id' in e for e in es)
    es2,*_=analyze(drawing,cfg.model_copy(update={'excluded_entities':[ids[0]]}))
    assert ids[0] not in [e['entity_id'] for e in es2] and ids[1] in [e['entity_id'] for e in es2]
    assert f.read_bytes()==original


def test_ignored_layers_override_automatic_classification(drawing):
    from app.geometry import analyze
    cfg=settings(ignored_layers=['PAVIMENTO'])
    es,*_=analyze(drawing,cfg);assert not any(e['layer']=='PAVIMENTO' for e in es)
    with pytest.raises(ValueError,match='Nenhum eixo'):
        analyze(drawing,settings(ignored_layers=['EIXO']))


def test_layers_available_before_analysis_and_exclusions_persist(drawing):
    from app.server import app
    with TestClient(app) as c:
        pid=c.post('/api/projects',json=settings().model_dump()).json()['id']
        c.post(f'/api/projects/{pid}/files',files={'file':('a.dxf',(drawing/'input.dxf').read_bytes())}).raise_for_status()
        r=c.get(f'/api/projects/{pid}/dxf_layers');assert r.status_code==200
        assert 'EIXO' in [x['name'] for x in r.json()['layers']]
        cfg=c.get(f'/api/projects/{pid}').json()['config'];cfg.update(ignored_layers=['PAVIMENTO'],excluded_entities=['AA/0/2'])
        c.put(f'/api/projects/{pid}/config',json=cfg).raise_for_status()
        restored=c.get(f'/api/projects/{pid}').json()['config'];assert restored['excluded_entities']==['AA/0/2'] and restored['ignored_layers']==['PAVIMENTO']


def test_vehicle_not_discarded_before_image_edge(junction,monkeypatch):
    from app.render import Scene
    from app import visual
    sc=Scene(junction,settings());sc.reveal_opacity=1.;sc._night=0
    path=sc.network.paths[0];pt=path['p'][len(path['p'])//2];tan=path['t'][len(path['p'])//2]
    monkeypatch.setattr(sc,'traffic_iter',lambda t:iter([(pt,tan,0,(0,1,0),0)]))
    # Put its center in the former hidden 5px left margin, still well inside the image.
    width=80.;cam=pt+sc.right*(width/2-width/sc.W*2)
    calls=[];monkeypatch.setattr(visual,'draw_vehicle',lambda im,p,t,vt,*a,**kw:calls.append((p,vt)))
    sc.draw_vehicles(np.zeros((sc.H,sc.W,3),np.uint8),1,cam,width,1)
    assert len(calls)==1


def test_editor_enter_escape_multiselect_and_dxf_deletion(drawing):
    pw=pytest.importorskip('playwright.sync_api')
    import uvicorn
    from app.server import app
    with socket.socket() as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
    server=uvicorn.Server(uvicorn.Config(app,host='127.0.0.1',port=port,log_level='warning'));thread=threading.Thread(target=server.run,daemon=True);thread.start()
    base=f'http://127.0.0.1:{port}'
    try:
        with httpx.Client(base_url=base,timeout=60) as c:
            for _ in range(100):
                try:c.get('/api/health').raise_for_status();break
                except httpx.HTTPError:time.sleep(.1)
            cfg=settings(signs=[{'id':'s1','code':'R-1','point':{'x':500100,'y':7800005}},{'id':'s2','code':'R-19','point':{'x':500130,'y':7800005}}]).model_dump()
            pid=c.post('/api/projects',json=cfg).json()['id'];c.post(f'/api/projects/{pid}/files',files={'file':('x.dxf',(drawing/'input.dxf').read_bytes())}).raise_for_status()
            job=c.post(f'/api/projects/{pid}/analyze').json();assert wait(c,job['id'])['state']=='done'
            errors=[]
            with pw.sync_playwright() as p:
                browser=p.chromium.launch(executable_path=os.environ.get('CHROMIUM','/usr/bin/chromium'))
                page=browser.new_page(viewport={'width':1500,'height':1100});page.on('pageerror',lambda e:errors.append(str(e)))
                page.add_init_script(f"localStorage.setItem('rodovia_project','{pid}')")
                tile=cv2.imencode('.jpg',np.full((256,256,3),70,np.uint8))[1].tobytes()
                page.route('**/tiles/**',lambda r:r.fulfill(status=200,body=tile,content_type='image/jpeg'))
                page.goto(base);page.wait_for_function('typeof geo!=="undefined" && geo && vec && ready() && axisData()',timeout=20000)
                ev=page.evaluate
                ev("(()=>{const [x,y]=worldToImg({x:500150,y:7800000});view.s=canvas.width*mpp()/200;view.ox=canvas.width/2-x*view.s;view.oy=canvas.height/2-y*view.s;draw()})()")
                page.locator('#canvas').scroll_into_view_if_needed()
                def screen(x,y):return ev('([x,y])=>{const p=W2C({x,y}),r=canvas.getBoundingClientRect();return [r.left+p[0]*r.width/canvas.width,r.top+p[1]*r.height/canvas.height]}',[x,y])
                page.mouse.click(*screen(500100,7800005));page.keyboard.down('Shift');page.mouse.click(*screen(500130,7800005));page.keyboard.up('Shift')
                assert ev('multiSel.length')==2
                page.keyboard.press('Delete');assert ev('M.signs.length')==0
                ev('undo()');assert ev('M.signs.length')==2
                # Enter completes polygon even with focus in the tool selector; no duplicate execution.
                ev("setTool('pavarea')")
                for x,y in [(500160,7800015),(500180,7800015),(500180,7800020)]:page.mouse.click(*screen(x,y))
                page.locator('#pavMat').focus();page.keyboard.press('Enter');page.wait_for_function("tool==='pan' && M.pavement_areas.length===1")
                # Escape clears a draft while command input owns focus.
                ev("setTool('align')");page.mouse.click(*screen(500100,7800000));page.locator('#cmdLine').focus();page.keyboard.press('Escape')
                assert ev("draft===null && tool==='pan' && cadCmd===null && sel===null")
                # Escape rolls back an in-progress grip drag, rather than leaving half an edit.
                page.mouse.click(*screen(500100,7800005));page.mouse.move(*screen(500100,7800005));page.mouse.down();page.mouse.move(*screen(500105,7800006),steps=4);page.keyboard.press('Escape');page.mouse.up()
                assert ev('M.signs[0].point.x')==500100
                # Native DXF selection is constrained by layer and deletion is undoable.
                ev("setTool('dxfselect')");page.locator('#selectionLayer').select_option('PAVIMENTO');page.mouse.click(*screen(500150,7800009))
                assert ev("nativeSel && nativeSel.layer")=='PAVIMENTO'
                count_snaps="buildSnap();[...snapIndex.values()].reduce((n,a)=>n+a.length,0)"
                snap_before=ev(count_snaps)
                page.keyboard.press('Delete');assert ev('M.excluded_entities.length')==1
                assert ev(count_snaps)<snap_before
                ev('undo()');assert ev('M.excluded_entities.length')==0
                page.keyboard.press('Control+s');page.wait_for_function('savePending===false')
                # A delayed validation response cannot resurrect a command cancelled with Escape.
                pending=[]
                page.route('**/validate_path',lambda route:pending.append(route))
                ev("setTool('flowadd');draft={type:'flowadd',pts:[{x:500100,y:7800005},{x:500150,y:7800005}]};void endCommand()")
                for _ in range(50):
                    page.wait_for_timeout(20)
                    if pending:break
                assert pending
                page.locator('#cmdLine').focus();page.keyboard.press('Escape')
                pending[0].fulfill(status=200,json={'ok':True,'length_m':50})
                page.wait_for_timeout(150)
                assert ev("M.traffic_paths.length===0 && draft===null && tool==='pan'")
                assert not errors,errors
                browser.close()
    finally:server.should_exit=True;thread.join(timeout=10)


def test_structurally_damaged_dxf_recovered_without_rewriting(tmp_path):
    from app.geometry import read_dxf
    path=tmp_path/'damaged.dxf';doc=ezdxf.new();doc.modelspace().add_line((0,0),(100,0));doc.saveas(path)
    text=path.read_text().replace('  0\nENDSEC\n  0\nEOF\n','  0\nEOF\n');path.write_text(text);before=path.read_bytes()
    warnings=[];loaded=read_dxf(path,warnings)
    assert len(loaded.modelspace())==1 and any('recuperado' in w for w in warnings)
    assert path.read_bytes()==before


def test_generated_sign_can_be_deleted_and_restored(junction):
    from app.render import Scene
    cfg=settings();sc=Scene(junction,cfg)
    signs=[g for g in sc.network.signs if g.get('auto')];assert signs
    sid=signs[0]['sign_id']
    hidden=Scene(junction,cfg.model_copy(update={'excluded_signs':[sid]}))
    assert sid not in [g['sign_id'] for g in hidden.network.signs]
    assert sid in [g['sign_id'] for g in Scene(junction,cfg).network.signs]


def test_worker_budget_respects_container_quota(monkeypatch):
    from app.parallel import available_cores,available_memory,plan_workers
    from app.encoding import options
    read=Path.read_text
    def fake(p,*a,**kw):
        if str(p)=='/sys/fs/cgroup/cpu.max':return '400000 100000'
        return read(p,*a,**kw)
    monkeypatch.setattr(Path,'read_text',fake);monkeypatch.setattr(os,'cpu_count',lambda:128)
    assert available_cores()<=4
    args=options('libx264');assert int(args[args.index('-threads')+1])<=4
    assert plan_workers(0,1920,1080,1000,True)[0]<=3


def test_export_range_validation():
    for changes in [{'export_start_s':3,'export_end_s':2},{'export_end_s':5},{'export_start_s':3},{'export_start_s':1,'export_end_s':1.001}]:
        with pytest.raises(ValueError):Settings(**{**settings().model_dump(),**changes})
    cfg=Settings(**{**settings().model_dump(),'export_start_s':1,'export_end_s':2});assert cfg.export_end_s==2


def test_trimmed_export_uses_original_timeline_and_exact_frames(drawing,tmp_path,monkeypatch):
    from app.render import render
    import json
    cfg=Settings(**{**settings().model_dump(),'duration_s':10,'short_video_mode':'tour','export_start_s':4,'export_end_s':5,'encoder':'cpu'})
    logs={}
    for workers in (1,2):
        log=tmp_path/f'clip{workers}.txt';monkeypatch.setenv('RODOVIA_FRAME_LOG',str(log))
        render(drawing,cfg.model_copy(update={'render_workers':workers}))
        info=json.loads((drawing/'video.json').read_text());assert info['frames']==30 and info['export_start_s']==4 and info['export_end_s']==5
        assert info['validation']['ok'] and info['validation']['frames_decoded']==30
        logs[workers]=log.read_text()
    assert logs[1]==logs[2]


def test_vehicles_wait_at_visible_route_exit_instead_of_disappearing(junction):
    from app.render import Scene
    from app.simulation import TrafficSim
    from app import visual
    sc=Scene(junction,settings());cfg=Settings(**{**settings().model_dump(),'duration_s':30,'traffic_density':2})
    sim=TrafficSim(sc.network,cfg,visual.vehicle_type,30,exit_visible=lambda i,t:True)
    assert sim.spawned>0 and sim.collisions==0
    initial={v for v,_,_ in sim.state(0)};final={v for v,_,_ in sim.state(29.9)}
    assert initial and initial.issubset(final)
    for vid,i,s in sim.state(29.9):assert s<sim.paths[i]['length']


def test_waiting_vehicles_leave_when_exit_moves_offscreen(junction):
    from app.render import Scene
    from app.simulation import TrafficSim
    from app import visual
    sc=Scene(junction,settings());cfg=Settings(**{**settings().model_dump(),'duration_s':60})
    sim=TrafficSim(sc.network,cfg,visual.vehicle_type,60,exit_visible=lambda i,t:t<5)
    initial={v for v,_,_ in sim.state(0)};final={v for v,_,_ in sim.state(59.9)}
    assert initial and not initial.intersection(final)
    assert sim.collisions==0 and sim.exit_visible is None


def test_custom_alignment_can_replace_excluded_native_axis(drawing):
    from app.geometry import analyze
    doc=ezdxf.readfile(drawing/'input.dxf');eid=next(e.dxf.handle for e in doc.modelspace() if e.dxf.layer=='EIXO')
    cfg=settings(excluded_entities=[eid],custom_axis={'points':[{'x':500000,'y':7800003},{'x':500300,'y':7800003}]})
    _,axis,ds,_,_=analyze(drawing,cfg)
    assert ds[-1]==pytest.approx(300) and np.allclose(axis[:,1],7800003)
