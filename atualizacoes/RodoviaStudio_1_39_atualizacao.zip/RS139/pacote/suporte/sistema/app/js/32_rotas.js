// ---------- Rotas de veículos (vários alinhamentos; pista simples, dupla ou sentido único por trecho) ----------
MARK_KEYS.push('route_alignments');estender('emptyMarks',_em=>function(){return {..._em(),route_alignments:[]}},'Rotas de veículos (vários alinhamentos; pista simples, dupla ou sentid');if(!M.route_alignments)M.route_alignments=[];
OBJ_SPECS.push(['route_alignments','Rota de veículos','poly',o=>o.points.map((_,i)=>[o.points,i])]);
const ROUTE_TYPE={simples:'Pista simples (um sentido de cada lado)',dupla:'Pista dupla (faixas por sentido + canteiro)',unico:'Sentido único (no sentido do desenho)'};
Object.assign(ALL_LABELS,{simples:ROUTE_TYPE.simples,dupla:ROUTE_TYPE.dupla,unico:ROUTE_TYPE.unico});
Object.assign(PROP_LABEL,{lanes:['Faixas por sentido','Pista simples/dupla: faixas em cada sentido. Sentido único: total de faixas.'],median_m:['Canteiro central (m)','Largura do canteiro entre os sentidos (pista dupla).'],lane_width_m:['Largura da faixa (m)',''],taper_m:['Transição (m)','Comprimento da transição entre trechos de tipos diferentes.'],outside_pavement:['Fora do pavimento','Os veículos andam mesmo onde o desenho não tem pavimento.'],type:['Tipo de pista','Tipo fora dos trechos. Cada trecho pode ter o seu.']});
if(!PROP_LABEL.level)PROP_LABEL.level=['Nível','0 = solo; 1, 2… viadutos; −1… passagens inferiores.'];
let routeMode='cliques';try{routeMode=localStorage.getItem('rodovia_routemode')||'cliques'}catch{}
const routeOpt={type:'simples',lanes:1,median_m:0,speed:'',secType:'dupla',secLanes:2,secMedian:6};
try{Object.assign(routeOpt,JSON.parse(localStorage.getItem('rodovia_routeopt')||'{}'))}catch{}
function saveRouteOpt(){try{localStorage.setItem('rodovia_routeopt',JSON.stringify(routeOpt))}catch{}}
const typeOpts=v=>Object.entries(ROUTE_TYPE).map(([k,l])=>`<option value="${k}" ${k===v?'selected':''}>${esc(l)}</option>`).join('');
function routeOptions(o){o.innerHTML=`<div class="grid"><label>Como desenhar<select id="rtMode"><option value="cliques">Cliques (dois ou mais pontos)</option><option value="linha">Selecionar uma linha do desenho</option><option value="continua">Seleção contínua (linhas conectadas)</option></select></label><label>Tipo de pista<select id="rtType">${typeOpts(routeOpt.type)}</select></label><label>Faixas por sentido<input id="rtLanes" type="number" min="1" max="6" value="${routeOpt.lanes}"></label><label>Canteiro (m)<input id="rtMedian" type="number" min="0" max="60" step="0.5" value="${routeOpt.median_m}"></label><label>Velocidade (km/h, vazio = normal)<input id="rtSpeed" type="number" min="5" max="130" step="5" value="${routeOpt.speed}"></label></div><p class="muted">Enter confirma · Esc cancela · Backspace desfaz o último ponto. O sentido do desenho é o “sentido 1” (fica à direita do alinhamento).</p>`;
  $('rtMode').value=routeMode;$('rtMode').onchange=()=>{routeMode=$('rtMode').value;try{localStorage.setItem('rodovia_routemode',routeMode)}catch{};draft=null;draw()};
  const sync=()=>{routeOpt.type=$('rtType').value;routeOpt.lanes=Math.max(1,Math.min(6,Number($('rtLanes').value)||1));routeOpt.median_m=Math.max(0,Math.min(60,Number($('rtMedian').value)||0));routeOpt.speed=$('rtSpeed').value;saveRouteOpt()};
  ['rtType','rtLanes','rtMedian','rtSpeed'].forEach(id=>$(id).addEventListener('change',sync))}
function routeSecOptions(o){o.innerHTML=`<div class="grid"><label>Tipo de pista no trecho<select id="rsType">${typeOpts(routeOpt.secType)}</select></label><label>Faixas por sentido<input id="rsLanes" type="number" min="1" max="6" value="${routeOpt.secLanes}"></label><label>Canteiro (m)<input id="rsMedian" type="number" min="0" max="60" step="0.5" value="${routeOpt.secMedian}"></label></div><p class="muted">Clique o início e o fim do trecho sobre a rota (linha laranja). Enter ou Esc encerra.</p>`;
  const sync=()=>{routeOpt.secType=$('rsType').value;routeOpt.secLanes=Math.max(1,Math.min(6,Number($('rsLanes').value)||1));routeOpt.secMedian=Math.max(0,Math.min(60,Number($('rsMedian').value)||0));saveRouteOpt()};
  ['rsType','rsLanes','rsMedian'].forEach(id=>$(id).addEventListener('change',sync))}
function projOnPolyline(pts,w){let best={d:Infinity,s:0,p:null},acc=0;for(let i=1;i<pts.length;i++){const a=pts[i-1],b=pts[i],dx=b.x-a.x,dy=b.y-a.y,L2=dx*dx+dy*dy,L=Math.sqrt(L2);let t=L2?((w.x-a.x)*dx+(w.y-a.y)*dy)/L2:0;t=Math.max(0,Math.min(1,t));const p={x:a.x+dx*t,y:a.y+dy*t},d=Math.hypot(w.x-p.x,w.y-p.y);if(d<best.d)best={d,s:acc+L*t,p};acc+=L}return best}
function pointAtS(pts,s){let acc=0;for(let i=1;i<pts.length;i++){const a=pts[i-1],b=pts[i],L=Math.hypot(b.x-a.x,b.y-a.y);if(acc+L>=s||i===pts.length-1){const t=L?Math.max(0,Math.min(1,(s-acc)/L)):0;return {x:a.x+(b.x-a.x)*t,y:a.y+(b.y-a.y)*t}}acc+=L}return pts[0]}
function subPolyline(pts,s0,s1){const out=[pointAtS(pts,s0)];let acc=0;for(let i=1;i<pts.length;i++){acc+=Math.hypot(pts[i].x-pts[i-1].x,pts[i].y-pts[i-1].y);if(acc>s0&&acc<s1)out.push(pts[i])}out.push(pointAtS(pts,s1));return out}
async function pickRouteLine(w){try{requireProject();const tol=Math.max(.2,12/Math.max(pxPerM(),1e-9));
 const r=await api(`/api/projects/${pid}/linha?x=${w.x}&y=${w.y}&tol=${tol.toFixed(3)}&continua=${routeMode==='continua'?1:0}`);const pts=r.points.map(([x,y])=>({x,y}));
 if(!draft||draft.type!=='route'||draft.src!==routeMode)draft={type:'route',pts:[],src:routeMode,hist:[]};draft.hist.push(draft.pts.slice());
 if(routeMode==='linha'||!draft.pts.length)draft.pts=pts;
 else{const d=(p,q)=>Math.hypot(p.x-q.x,p.y-q.y),E=draft.pts[draft.pts.length-1],S=draft.pts[0],A=pts[0],B=pts[pts.length-1];
  const opt=[[d(E,A),'E',pts],[d(E,B),'E',pts.slice().reverse()],[d(S,B),'S',pts],[d(S,A),'S',pts.slice().reverse()]].sort((a,b)=>a[0]-b[0])[0];let add=opt[2];
  if(opt[1]==='E'){if(d(E,add[0])<.05)add=add.slice(1);draft.pts=draft.pts.concat(add)}else{if(d(S,add[add.length-1])<.05)add=add.slice(0,-1);draft.pts=add.concat(draft.pts)}}
 draw();msg(`Rota: ${draft.pts.length} vértices, ${polyLen(draft.pts).toFixed(1)} m (camada ${(r.layers||[r.layer]).join(', ')}). ${routeMode==='continua'?'Clique a próxima linha ou ':''}Enter confirma; Esc cancela.`)}catch(e){msg(e.message,true)}}
let rsDraft=null;
function nearestRoute(w){let best=null;(M.route_alignments||[]).forEach((r,i)=>{const p=projOnPolyline(r.points,w);if(!best||p.d<best.d)best={...p,i}});return best}
function routeSecClick(w){if(!(M.route_alignments||[]).length)return msg('Crie uma rota de veículos primeiro (ferramenta “Rota de veículos”).',true);
 const tol=Math.max(2,14/Math.max(pxPerM(),1e-9));
 if(!rsDraft){const n=nearestRoute(w);if(!n||n.d>tol)return msg('Clique sobre a linha laranja de uma rota.',true);rsDraft={i:n.i,s0:n.s,p:n.p};draw();return msg(`Início do trecho a ${n.s.toFixed(1)} m do começo da rota “${M.route_alignments[n.i].name}”. Clique o fim do trecho.`)}
 const r=M.route_alignments[rsDraft.i];const p=projOnPolyline(r.points,w);if(p.d>tol)return msg('Clique o fim do trecho sobre a mesma rota.',true);
 const a=Math.min(rsDraft.s0,p.s),b=Math.max(rsDraft.s0,p.s);if(b-a<5){rsDraft=null;draw();return msg('Trecho muito curto (mínimo 5 m). Clique o início de novo.',true)}
 checkpoint();r.sections=r.sections||[];const k=r.sections.length+1;r.sections.push({id:uid(),name:'Trecho '+k,start_m:+a.toFixed(2),end_m:+b.toFixed(2),type:routeOpt.secType,lanes:routeOpt.secLanes,median_m:routeOpt.secType==='dupla'?routeOpt.secMedian:0});rsDraft=null;
 changed(`Trecho ${k} da rota “${r.name}”: ${a.toFixed(1)}–${b.toFixed(1)} m, ${ROUTE_TYPE[routeOpt.secType].toLowerCase()}. Clique “Atualizar fluxos” para os veículos usarem.`)}
async function concluirRota(d){if(d.pts.length<2)return msg('Marque pelo menos dois pontos (ou selecione uma linha).',true);if(d.pts.length>20000)return msg('Mais de 20 000 vértices: selecione um trecho menor.',true);
  draft=null;checkpoint();const n=M.route_alignments.length+1,sp=Number(routeOpt.speed);
  M.route_alignments.push({id:uid(),name:'Rota '+n,points:d.pts.map(p=>({x:+p.x,y:+p.y})),enabled:true,type:routeOpt.type,lanes:routeOpt.lanes,median_m:routeOpt.type==='dupla'?routeOpt.median_m:0,lane_width_m:3.5,taper_m:40,speed_kmh:routeOpt.speed!==''&&isFinite(sp)&&sp>=5?Math.min(130,sp):null,level:0,outside_pavement:false,source:d.src||'cliques',sections:[]});
  changed(`Rota ${n} criada (${polyLen(d.pts).toFixed(0)} m, ${ROUTE_TYPE[routeOpt.type].toLowerCase()}). Use “Trecho da rota” para outro tipo num trecho; clique “Atualizar fluxos” para os veículos usarem.`);refreshRouteLanes(true);}
// Faixas calculadas no servidor (mesmo cálculo da rede de tráfego).
let routeLanes=[],routeSig='',routeTimer=null;
function routeSignature(){return JSON.stringify((M.route_alignments||[]).map(r=>{let sx=0,sy=0;for(const p of r.points){sx+=p.x;sy+=p.y}return [r.points.length,sx.toFixed(3),sy.toFixed(3),r.enabled,r.type,r.lanes,r.median_m,r.lane_width_m,r.taper_m,r.sections]}))}
function refreshRouteLanes(now){const sig=routeSignature();if(sig===routeSig&&!now)return;routeSig=sig;clearTimeout(routeTimer);
 if(!(M.route_alignments||[]).length){routeLanes=[];return}
 routeTimer=setTimeout(async()=>{try{const r=await api('/api/rotas_previa',json('POST',{route_alignments:M.route_alignments}));routeLanes=r.lanes||[];draw()}catch(e){}},now?0:250)}
const RT_COL={simples:'#4fa3ff',dupla:'#b67cff',unico:'#ffd166'};
estender('draw',_d=>function(){_d();if(!ready())return;try{refreshRouteLanes();
 if(draft&&draft.type==='route'&&draft.pts.length){const pts=draft.pts.slice();if(routeMode==='cliques'&&typeof lastWorld!=='undefined'&&lastWorld)pts.push(lastWorld);poly(pts);ctx.strokeStyle='#ff9f1c';ctx.lineWidth=4;ctx.setLineDash([8,5]);ctx.stroke();ctx.setLineDash([])}
 if(vecOn.flows===false&&tool!=='route'&&tool!=='routesec')return;
 (M.route_alignments||[]).forEach((r,i)=>{if(r.points.length<2)return;poly(r.points);ctx.strokeStyle=r.enabled?'#ff9f1c':'#888';ctx.lineWidth=2;ctx.setLineDash([10,6]);ctx.stroke();ctx.setLineDash([]);
  for(const s of r.sections||[]){const sp=subPolyline(r.points,s.start_m,s.end_m);poly(sp);ctx.strokeStyle=(RT_COL[s.type]||'#fff')+'88';ctx.lineWidth=10;ctx.stroke();label(`${s.name} · ${s.type==='dupla'?s.lanes+'+'+s.lanes:s.type==='unico'?s.lanes+' (único)':s.lanes+'+'+s.lanes} faixas`,sp[Math.floor(sp.length/2)],RT_COL[s.type])}
  label(`${r.name} · ${r.type==='unico'?'sentido único':r.type==='dupla'?'pista dupla':'pista simples'}`,r.points[0],'#ff9f1c')});
 for(const l of routeLanes){if(l.points.length<2)continue;const pts=l.points.map(([x,y])=>({x,y}));poly(pts);const c=!l.enabled?'#777':l.dir==='f'?'#46e0a0':'#ff8a4c';ctx.strokeStyle=c;ctx.lineWidth=1.6;ctx.stroke();arrowsAlong(pts,true,false,c,110)}
 if(rsDraft){const r=M.route_alignments[rsDraft.i];if(r){const [x,y]=W2C(rsDraft.p);ctx.fillStyle='#ffd166';ctx.beginPath();ctx.arc(x,y,7,0,7);ctx.fill();if(typeof lastWorld!=='undefined'&&lastWorld){const p=projOnPolyline(r.points,lastWorld);poly(subPolyline(r.points,Math.min(rsDraft.s0,p.s),Math.max(rsDraft.s0,p.s)));ctx.strokeStyle='#ffd16699';ctx.lineWidth=10;ctx.stroke()}}}}catch(err){}},'Faixas calculadas no servidor (mesmo cálculo da rede de tráfego).');
// Propriedades da rota: trechos editáveis.
estender('showProps',_sp=>function(){_sp();const box=$('propPanel');const L=selObjs();if(!box||box.hidden||L.length!==1||L[0].key!=='route_alignments')return;const r=L[0].o,len=polyLen(r.points);
 const rows=(r.sections||[]).map((s,k)=>`<tr><td><input data-rs="${k}:start_m" type="number" step="1" min="0" value="${(+s.start_m).toFixed(1)}"></td><td><input data-rs="${k}:end_m" type="number" step="1" min="0" value="${(+s.end_m).toFixed(1)}"></td><td><select data-rs="${k}:type">${typeOpts(s.type).replace(/ \([^)]*\)/g,'')}</select></td><td><input data-rs="${k}:lanes" type="number" min="1" max="6" value="${s.lanes}"></td><td><input data-rs="${k}:median_m" type="number" min="0" max="60" step="0.5" value="${s.median_m}"></td><td><button type="button" data-rsdel="${k}" title="Apagar o trecho">✕</button></td></tr>`).join('');
 const html=`<div class="rtSecBox"><h4>Trechos da rota (${len.toFixed(0)} m)</h4><table class="rtSec"><tr><th>Início (m)</th><th>Fim (m)</th><th>Tipo</th><th>Faixas</th><th>Canteiro</th><th></th></tr>${rows||'<tr><td colspan="6" class="muted">Sem trechos: vale o tipo da rota em toda a extensão.</td></tr>'}</table><div class="row"><button type="button" data-rsadd="map">+ Trecho no mapa</button><button type="button" data-rsadd="num">+ Trecho por distância</button></div></div>`;
 const h4=[...box.querySelectorAll('h4')].find(h=>/Grips/.test(h.textContent));if(h4)h4.insertAdjacentHTML('beforebegin',html);else box.insertAdjacentHTML('beforeend',html)},'Propriedades da rota: trechos editáveis.');
function rsCommit(el){const o=objOf(sel);if(!o||o.key!=='route_alignments')return;const [k,f]=el.dataset.rs.split(':');const s=o.o.sections[Number(k)];if(!s)return;let v=el.tagName==='SELECT'?el.value:Number(String(el.value).replace(',','.'));
 if(el.tagName!=='SELECT'&&!isFinite(v))return msg('Valor numérico inválido.',true);if(f==='lanes')v=Math.max(1,Math.min(6,Math.round(v)));if(f==='median_m')v=Math.max(0,Math.min(60,v));if(['start_m','end_m'].includes(f))v=Math.max(0,Math.min(polyLen(o.o.points),v));
 checkpoint();s[f]=v;if(s.end_m<s.start_m){const t=s.start_m;s.start_m=s.end_m;s.end_m=t}if(f==='type'&&v!=='dupla')s.median_m=0;if(f==='type'&&v==='dupla'&&!s.median_m)s.median_m=6;changed('Trecho da rota alterado. Clique “Atualizar fluxos” para os veículos usarem.');showProps()}
document.addEventListener('keydown',e=>{const el=e.target;if(!el.dataset||!el.dataset.rs)return;if(e.key==='Enter'){e.preventDefault();e.stopPropagation();rsCommit(el)}else if(e.key==='Escape'){e.preventDefault();e.stopPropagation();showProps()}},true);
document.addEventListener('change',e=>{const el=e.target;if(!el.dataset||!el.dataset.rs)return;e.stopPropagation();rsCommit(el)},true);
document.addEventListener('click',e=>{const b=e.target.closest&&e.target.closest('#propPanel [data-rsdel],#propPanel [data-rsadd]');if(!b)return;const o=objOf(sel);if(!o||o.key!=='route_alignments')return;
 if(b.dataset.rsdel!==undefined){checkpoint();o.o.sections.splice(Number(b.dataset.rsdel),1);changed('Trecho apagado.');showProps();return}
 if(b.dataset.rsadd==='map'){setTool('routesec');return msg('Clique o início e o fim do trecho sobre a rota.')}
 const len=polyLen(o.o.points),last=(o.o.sections||[]).reduce((m,s)=>Math.max(m,s.end_m),0),a=Math.min(last,Math.max(0,len-10));checkpoint();o.o.sections=o.o.sections||[];o.o.sections.push({id:uid(),name:'Trecho '+(o.o.sections.length+1),start_m:+a.toFixed(1),end_m:+Math.min(len,a+100).toFixed(1),type:routeOpt.secType,lanes:routeOpt.secLanes,median_m:routeOpt.secType==='dupla'?routeOpt.secMedian:0});changed('Trecho acrescentado: ajuste início e fim na tabela.');showProps()});



// Registro das ferramentas (1.31): clique, Enter, opções e Esc num lugar só.
ferramenta('route',{rotulo:'🛣 Rota de veículos',dica:'Desenhe o alinhamento da rota (cliques, linha do desenho ou seleção contínua) e pressione Enter. As faixas são geradas dos dois lados (pista simples), por sentido com canteiro (pista dupla) ou num sentido só. Depois use “Trecho da rota” para mudar o tipo num trecho.',antesDe:'linkforce',icone:'M4 21c2-6 4-9 8-10s6-4 8-9M7 21c2-5 4-7 8-8M3 14l2 1M20 5l-2-1',
 clique(w){if(routeMode==='cliques'){if(!draft||draft.type!=='route')draft={type:'route',pts:[]};draft.pts.push(w);draw();return}pickRouteLine(w)},
 concluir:concluirRota,opcoes:routeOptions});
ferramenta('routesec',{rotulo:'⇶ Trecho da rota',dica:'Clique o INÍCIO e depois o FIM do trecho sobre uma rota: nele vale o tipo de pista escolhido nas opções (simples, dupla por sentido ou sentido único). Repita para outros trechos; Enter ou Esc encerra.',antesDe:'linkforce',icone:'M3 18h18M7 14v8M17 14v8M5 10l2-3 2 3M15 10l2-3 2 3',
 clique:routeSecClick,opcoes:routeSecOptions,
 esc(){if(rsDraft){rsDraft=null;draw();msg('Início do trecho descartado.');return}setTool('pan');msg('Trecho da rota encerrado.')},
 sair(){rsDraft=null}});
itemFaixa('Fluxos','Rotas',['Rota de veículos','🛣',()=>setTool('route'),1]);itemFaixa('Fluxos','Rotas',['Trecho da rota','⇶',()=>setTool('routesec'),1]);
{const F=RIBBON.find(t=>t[0]==='Fluxos');const k=F[1].findIndex(g=>g[0]==='Rotas');F[1].splice(1,0,...F[1].splice(k,1))}   // grupo logo após Tráfego
comando(['ROTA','RT','ROUTE'],()=>setTool('route'),'Rota de veículos (pista simples, dupla ou sentido único)');
comando(['TRECHO','TR'],()=>setTool('routesec'),'Trecho da rota com outro tipo de pista');
estender('load',anterior=>async id=>{routeSig='';routeLanes=[];rsDraft=null;await anterior(id);refreshRouteLanes(true)},'rotas: faixas recalculadas ao abrir');
