# Escolhe a pasta do Rodovia Studio e aplica este pacote (reorganiza instalacoes antigas).
$ErrorActionPreference = 'Stop'
try {
    Add-Type -AssemblyName System.Windows.Forms
    $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
    $dialog.Description = 'Selecione a pasta do Rodovia Studio (a que tem INICIAR.cmd ou ABRIR RODOVIA STUDIO.cmd)'
    $dialog.ShowNewFolderButton = $false
    if ($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { exit 0 }
    $pacote = Join-Path $PSScriptRoot 'pacote'
    $engine = Join-Path $pacote 'suporte\sistema\atualizar.ps1'
    & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $engine -Raiz $dialog.SelectedPath -Pacote $pacote
    if ($LASTEXITCODE -ne 0) { throw 'A atualizacao nao foi aplicada. Veja a mensagem acima.' }
    [System.Windows.Forms.MessageBox]::Show('Atualizacao concluida. Abra o arquivo da pasta principal do aplicativo (Rodovia Studio.exe ou ABRIR RODOVIA STUDIO) e pressione Ctrl+F5 no navegador.', 'Rodovia Studio') | Out-Null
} catch {
    Write-Host $_.Exception.Message
    exit 1
}
