@echo off
setlocal
title Instalar atualizacao do Rodovia Studio
cd /d "%~dp0"
echo Feche o Rodovia Studio antes de continuar.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0instalar.ps1"
pause
